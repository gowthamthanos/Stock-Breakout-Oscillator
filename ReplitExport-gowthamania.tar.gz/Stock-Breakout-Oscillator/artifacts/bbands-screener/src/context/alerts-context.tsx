import { createContext, useContext, useEffect, useRef, useState } from "react";
import { useAuth } from "@clerk/react";
import {
  getGetAlertsQueryKey,
  useClearAlertEvents,
  useCreateAlert,
  useDeleteAlert,
  useGetAlerts,
  useRetryAlertEvent,
  useToggleAlert,
} from "@workspace/api-client-react";
import type {
  AlertCreateInput,
  AlertEvent,
  AlertMonitor,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

interface AlertsContextValue {
  alerts: AlertMonitor[];
  events: AlertEvent[];
  notificationPermission: NotificationPermission | "unsupported";
  isLoading: boolean;
  loadError: string | null;
  actionError: string | null;
  addAlert: (alert: AlertCreateInput) => void;
  removeAlert: (id: string) => void;
  toggleAlert: (id: string) => void;
  retryTelegramAlert: (eventId: string) => void;
  requestNotificationPermission: () => Promise<void>;
  clearEvents: () => void;
  clearActionError: () => void;
}

const AlertsContext = createContext<AlertsContextValue | null>(null);

function errorMessage(error: unknown, fallback: string): string {
  return error instanceof Error ? error.message : fallback;
}

function notifyBrowser(event: AlertEvent): void {
  if (typeof window === "undefined" || !("Notification" in window)) return;
  if (Notification.permission !== "granted") return;

  const color = event.direction === "bullish" ? "Green" : "Red";
  const trend = event.direction === "bullish" ? "bullish" : "bearish";
  const title = event.eventType === "changed"
    ? `${event.symbol}: trend changed to ${trend}`
    : `${event.symbol}: ${trend} trend started`;
  new Notification(title, {
    body: `${color} line appeared · ${event.alertLabel} · ${event.interval}`,
    icon: `${import.meta.env.BASE_URL}favicon.svg`,
  });
}

export function AlertsProvider({ children }: { children: React.ReactNode }) {
  const { isLoaded, isSignedIn } = useAuth();
  const queryClient = useQueryClient();
  const [actionError, setActionError] = useState<string | null>(null);
  const [notificationPermission, setNotificationPermission] = useState<
    NotificationPermission | "unsupported"
  >(() => {
    if (typeof window === "undefined" || !("Notification" in window)) return "unsupported";
    return Notification.permission;
  });
  const seenEventIds = useRef<Set<string> | null>(null);

  const alertsQuery = useGetAlerts({
    query: {
      queryKey: getGetAlertsQueryKey(),
      enabled: isLoaded && Boolean(isSignedIn),
      refetchInterval: 15_000,
      refetchOnWindowFocus: true,
    },
  });
  const invalidateAlerts = () =>
    queryClient.invalidateQueries({ queryKey: getGetAlertsQueryKey() });
  const handleMutationError = (error: unknown) =>
    setActionError(errorMessage(error, "The alert could not be updated."));

  const createMutation = useCreateAlert({
    mutation: {
      onSuccess: () => {
        setActionError(null);
        void invalidateAlerts();
      },
      onError: handleMutationError,
    },
  });
  const deleteMutation = useDeleteAlert({
    mutation: {
      onSuccess: () => {
        setActionError(null);
        void invalidateAlerts();
      },
      onError: handleMutationError,
    },
  });
  const toggleMutation = useToggleAlert({
    mutation: {
      onSuccess: () => {
        setActionError(null);
        void invalidateAlerts();
      },
      onError: handleMutationError,
    },
  });
  const retryMutation = useRetryAlertEvent({
    mutation: {
      onSuccess: () => {
        setActionError(null);
        void invalidateAlerts();
      },
      onError: handleMutationError,
    },
  });
  const clearMutation = useClearAlertEvents({
    mutation: {
      onSuccess: () => {
        setActionError(null);
        void invalidateAlerts();
      },
      onError: handleMutationError,
    },
  });

  const events = alertsQuery.data?.events ?? [];
  useEffect(() => {
    if (!isLoaded || !isSignedIn) {
      seenEventIds.current = null;
      return;
    }
    const currentIds = new Set(events.map((event) => event.id));
    if (seenEventIds.current === null) {
      seenEventIds.current = currentIds;
      return;
    }

    for (const event of events) {
      if (!seenEventIds.current.has(event.id)) notifyBrowser(event);
    }
    seenEventIds.current = currentIds;
  }, [events, isLoaded, isSignedIn]);

  const requestNotificationPermission = async () => {
    if (typeof window === "undefined" || !("Notification" in window)) return;
    const permission = await Notification.requestPermission();
    setNotificationPermission(permission);
  };

  const addAlert = (alert: AlertCreateInput) => {
    setActionError(null);
    createMutation.mutate({ data: alert });
  };
  const removeAlert = (alertId: string) => {
    setActionError(null);
    deleteMutation.mutate({ alertId });
  };
  const toggleAlert = (alertId: string) => {
    const alert = alertsQuery.data?.alerts.find((item) => item.id === alertId);
    if (!alert) return;
    setActionError(null);
    toggleMutation.mutate({
      alertId,
      data: { enabled: !alert.enabled },
    });
  };
  const retryTelegramAlert = (eventId: string) => {
    setActionError(null);
    retryMutation.mutate({ eventId });
  };
  const clearEvents = () => {
    setActionError(null);
    clearMutation.mutate();
  };

  const value: AlertsContextValue = {
    alerts: alertsQuery.data?.alerts ?? [],
    events,
    notificationPermission,
    isLoading: !isLoaded || (Boolean(isSignedIn) && alertsQuery.isLoading),
    loadError: alertsQuery.isError
      ? errorMessage(alertsQuery.error, "Could not load your alerts.")
      : null,
    actionError,
    addAlert,
    removeAlert,
    toggleAlert,
    retryTelegramAlert,
    requestNotificationPermission,
    clearEvents,
    clearActionError: () => setActionError(null),
  };

  return <AlertsContext.Provider value={value}>{children}</AlertsContext.Provider>;
}

export function useAlerts() {
  const context = useContext(AlertsContext);
  if (!context) throw new Error("useAlerts must be used within AlertsProvider");
  return context;
}
