import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';

interface SummaryStatProps {
  label: string;
  value: number | string;
  icon?: LucideIcon;
  variant?: 'default' | 'bullish' | 'bearish' | 'warning' | 'neutral';
  className?: string;
}

export function SummaryStat({ label, value, icon: Icon, variant = 'default', className }: SummaryStatProps) {
  const variantStyles = {
    default: 'border-border',
    bullish: 'border-[hsl(var(--chart-1))]/30 bg-[hsl(var(--chart-1))]/5',
    bearish: 'border-[hsl(var(--chart-2))]/30 bg-[hsl(var(--chart-2))]/5',
    warning: 'border-[hsl(var(--chart-3))]/30 bg-[hsl(var(--chart-3))]/5',
    neutral: 'border-border bg-muted/30',
  };

  const textStyles = {
    default: 'text-foreground',
    bullish: 'text-[hsl(var(--chart-1))]',
    bearish: 'text-[hsl(var(--chart-2))]',
    warning: 'text-[hsl(var(--chart-3))]',
    neutral: 'text-muted-foreground',
  };

  return (
    <div className={cn('flex flex-col gap-1 p-3 rounded border', variantStyles[variant], className)}>
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-medium">
        {Icon && <Icon className="h-3.5 w-3.5" />}
        <span>{label}</span>
      </div>
      <div className={cn('text-2xl font-semibold font-mono tabular-nums', textStyles[variant])}>
        {value}
      </div>
    </div>
  );
}
