import { cn } from '@/lib/utils';

interface OscillatorGaugeProps {
  value: number;
  signal: 'bullish_breakout' | 'bearish_breakout' | 'overbought' | 'oversold' | 'neutral';
  className?: string;
}

export function OscillatorGauge({ value, signal, className }: OscillatorGaugeProps) {
  // Normalize value to 0-100 scale for display (-1 to 1 -> 0 to 100, with 50 as midpoint)
  const normalizedPosition = ((value + 1) / 2) * 100;
  const clampedPosition = Math.max(0, Math.min(100, normalizedPosition));

  const getColor = () => {
    if (signal === 'bullish_breakout') return 'bg-[hsl(var(--chart-1))]';
    if (signal === 'bearish_breakout') return 'bg-[hsl(var(--chart-2))]';
    if (signal === 'overbought' || signal === 'oversold') return 'bg-[hsl(var(--chart-3))]';
    return 'bg-muted-foreground';
  };

  return (
    <div className={cn('flex items-center gap-3', className)}>
      <div className="relative w-24 h-2 bg-secondary rounded-full overflow-hidden">
        {/* Midpoint marker */}
        <div className="absolute left-1/2 top-0 bottom-0 w-px bg-border" />
        
        {/* Value indicator */}
        <div
          className={cn(
            'absolute top-0 bottom-0 w-1 rounded-full transition-all duration-300',
            getColor()
          )}
          style={{ left: `${clampedPosition}%`, transform: 'translateX(-50%)' }}
        />
      </div>
      
      <span className={cn('text-xs font-mono font-medium tabular-nums', getColor().replace('bg-', 'text-'))}>
        {value > 0 ? '+' : ''}{value.toFixed(3)}
      </span>
    </div>
  );
}
