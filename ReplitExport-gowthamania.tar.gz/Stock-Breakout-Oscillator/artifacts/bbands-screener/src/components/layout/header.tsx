import { Link, useLocation } from 'wouter';
import { Activity, Bell, List, WalletCards } from 'lucide-react';
import { useAuth, useClerk } from '@clerk/react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export function Header() {
  const [location] = useLocation();
  const { isLoaded, isSignedIn } = useAuth();
  const { signOut } = useClerk();
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

  const navItems = [
    { path: '/', label: 'Screener', icon: Activity },
    { path: '/watchlist', label: 'Watchlist', icon: List },
    { path: '/alerts', label: 'Alerts', icon: Bell },
    { path: '/trading', label: 'Trading', icon: WalletCards },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="container flex h-14 items-center px-4 lg:px-6">
        <div className="flex items-center gap-2 mr-8">
          <div className="h-8 w-8 rounded bg-primary flex items-center justify-center">
            <Activity className="h-5 w-5 text-primary-foreground" />
          </div>
          <div className="flex flex-col -space-y-1">
            <h1 className="text-base font-bold tracking-tight">BBands BO</h1>
            <p className="text-[10px] text-muted-foreground font-medium">Screener</p>
          </div>
        </div>

        <nav className="flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            return (
              <Link
                key={item.path}
                href={item.path}
                className={cn(
                  'flex items-center gap-2 px-3 py-1.5 text-sm font-medium rounded-md transition-colors',
                  isActive
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                )}
                data-testid={`nav-link-${item.label.toLowerCase()}`}
              >
                <Icon className="h-4 w-4" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
        <div className="ml-auto">
          {isLoaded && isSignedIn ? (
            <Button
              variant="outline"
              size="sm"
              onClick={() => signOut({ redirectUrl: basePath || '/' })}
            >
              Sign out
            </Button>
          ) : isLoaded ? (
            <Button asChild variant="outline" size="sm">
              <Link href="/sign-in">Sign in</Link>
            </Button>
          ) : null}
        </div>
      </div>
    </header>
  );
}
