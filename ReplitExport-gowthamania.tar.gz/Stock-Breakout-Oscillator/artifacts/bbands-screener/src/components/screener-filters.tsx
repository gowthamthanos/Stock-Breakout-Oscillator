import { useState, useEffect, useMemo } from 'react';
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { RotateCw, Settings2 } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

export interface ScreenerFiltersState {
  preset?: string;
  interval: string;
  period: number;
  stdDev: number;
  src: 'close';
  signal?: 'bullish_breakout' | 'bearish_breakout';
}

interface ScreenerFiltersProps {
  filters: ScreenerFiltersState;
  onFiltersChange: (filters: ScreenerFiltersState) => void;
  presets: Array<{ id: string; name: string; description: string; group?: string | null }>;
  isLoading?: boolean;
  onRefresh?: () => void;
}

export function ScreenerFilters({
  filters,
  onFiltersChange,
  presets,
  isLoading,
  onRefresh,
}: ScreenerFiltersProps) {
  const [localPeriod, setLocalPeriod] = useState(filters.period);
  const [localStdDev, setLocalStdDev] = useState(filters.stdDev);

  // Group presets by their group label
  const groupedPresets = useMemo(() => {
    const groups: Record<string, typeof presets> = {};
    for (const p of presets) {
      const g = p.group ?? 'Other';
      if (!groups[g]) groups[g] = [];
      groups[g].push(p);
    }
    return groups;
  }, [presets]);

  // Update parent filters when sliders change (debounced via state)
  useEffect(() => {
    const timer = setTimeout(() => {
      if (localPeriod !== filters.period || localStdDev !== filters.stdDev) {
        onFiltersChange({ ...filters, period: localPeriod, stdDev: localStdDev });
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [localPeriod, localStdDev]);

  return (
    <div className="flex items-center gap-4 flex-wrap">
      <div className="flex items-center gap-2">
        <Label htmlFor="preset-select" className="text-xs text-muted-foreground whitespace-nowrap">
          Symbols
        </Label>
        <Select
          value={filters.preset || 'watchlist'}
          onValueChange={(value) =>
            onFiltersChange({ ...filters, preset: value === 'watchlist' ? undefined : value })
          }
        >
          <SelectTrigger id="preset-select" className="w-[180px] h-8 text-sm" data-testid="select-preset">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="max-h-80">
            <SelectItem value="watchlist">My Watchlist</SelectItem>
            {Object.entries(groupedPresets).map(([group, groupPresets]) => (
              <SelectGroup key={group}>
                <SelectLabel className="text-xs text-muted-foreground px-2 py-1">{group}</SelectLabel>
                {groupPresets.map((preset) => (
                  <SelectItem key={preset.id} value={preset.id}>
                    {preset.name}
                  </SelectItem>
                ))}
              </SelectGroup>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center gap-2">
        <Label htmlFor="interval-select" className="text-xs text-muted-foreground whitespace-nowrap">
          Interval
        </Label>
        <Select
          value={filters.interval}
          onValueChange={(value) => onFiltersChange({ ...filters, interval: value })}
        >
          <SelectTrigger id="interval-select" className="w-[100px] h-8 text-sm" data-testid="select-interval">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="5m">5 Minutes</SelectItem>
            <SelectItem value="15m">15 Minutes</SelectItem>
            <SelectItem value="1h">1 Hour</SelectItem>
            <SelectItem value="1d">1 Day</SelectItem>
            <SelectItem value="1wk">1 Week</SelectItem>
            <SelectItem value="1mo">1 Month</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center gap-2">
        <Label htmlFor="source-select" className="text-xs text-muted-foreground whitespace-nowrap">
          Source
        </Label>
        <Select
          value={filters.src}
          onValueChange={(value) => onFiltersChange({ ...filters, src: value as 'close' })}
        >
          <SelectTrigger id="source-select" className="w-[95px] h-8 text-sm" data-testid="select-source">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="close">Close</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center gap-2">
        <Label htmlFor="signal-select" className="text-xs text-muted-foreground whitespace-nowrap">
          Trend
        </Label>
        <Select
          value={filters.signal ?? 'all'}
          onValueChange={(value) =>
            onFiltersChange({
              ...filters,
              signal: value === 'all'
                ? undefined
                : value as ScreenerFiltersState['signal'],
            })
          }
        >
          <SelectTrigger id="signal-select" className="w-[150px] h-8 text-sm" data-testid="select-signal">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Bullish and bearish</SelectItem>
            <SelectItem value="bullish_breakout">Bullish only</SelectItem>
            <SelectItem value="bearish_breakout">Bearish only</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2 h-8" data-testid="button-advanced-filters">
            <Settings2 className="h-3.5 w-3.5" />
            Advanced
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80" align="start">
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium">Period</Label>
                <span className="text-sm font-mono text-muted-foreground">{localPeriod}</span>
              </div>
              <Slider
                value={[localPeriod]}
                onValueChange={([value]) => setLocalPeriod(value)}
                min={5}
                max={50}
                step={1}
                className="w-full"
                data-testid="slider-period"
              />
              <p className="text-xs text-muted-foreground">
                Number of periods for Bollinger Bands calculation
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium">Std Dev</Label>
                <span className="text-sm font-mono text-muted-foreground">{localStdDev.toFixed(1)}</span>
              </div>
              <Slider
                value={[localStdDev * 10]}
                onValueChange={([value]) => setLocalStdDev(value / 10)}
                min={10}
                max={40}
                step={1}
                className="w-full"
                data-testid="slider-stddev"
              />
              <p className="text-xs text-muted-foreground">
                Standard deviation multiplier for band width
              </p>
            </div>
          </div>
        </PopoverContent>
      </Popover>

      <Button
        variant="outline"
        size="sm"
        className="gap-2 h-8 ml-auto"
        onClick={onRefresh}
        disabled={isLoading}
        data-testid="button-refresh"
      >
        <RotateCw className={`h-3.5 w-3.5 ${isLoading ? 'animate-spin' : ''}`} />
        Refresh
      </Button>
    </div>
  );
}
