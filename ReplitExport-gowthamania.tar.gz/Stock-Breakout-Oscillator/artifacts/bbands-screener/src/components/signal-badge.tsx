import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface SignalBadgeProps {
  signal: 'bullish_breakout' | 'bearish_breakout';
  className?: string;
  showIcon?: boolean;
}

export function SignalBadge({ signal, className, showIcon = true }: SignalBadgeProps) {
  const config = {
    bullish_breakout: {
      label: 'Bullish',
      icon: TrendingUp,
      bg: 'bg-[hsl(var(--chart-1))]/10',
      text: 'text-[hsl(var(--chart-1))]',
      border: 'border-[hsl(var(--chart-1))]/20',
    },
    bearish_breakout: {
      label: 'Bearish',
      icon: TrendingDown,
      bg: 'bg-[hsl(var(--chart-2))]/10',
      text: 'text-[hsl(var(--chart-2))]',
      border: 'border-[hsl(var(--chart-2))]/20',
    },
  };

  const { label, icon: Icon, bg, text, border } = config[signal];

  return (
    <div
      className={cn(
        'inline-flex items-center gap-1.5 px-2 py-0.5 rounded border text-xs font-medium',
        bg,
        text,
        border,
        className
      )}
    >
      {showIcon && <Icon className="h-3 w-3" />}
      <span>{label}</span>
    </div>
  );
}
