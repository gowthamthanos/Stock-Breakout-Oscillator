import type {
  AlertEvent as ApiAlertEvent,
  AlertMonitor as ApiAlertMonitor,
} from "@workspace/api-client-react";

export type AlertTrendDirection = "bullish" | "bearish";
export type AlertDirection = AlertTrendDirection | "both";
export type BreakoutTrend = AlertTrendDirection | null;
export type AlertEventType = "started" | "changed" | "ended";

export type ScreenerAlert = ApiAlertMonitor;
export type AlertEvent = ApiAlertEvent;

export function intervalLabel(interval: string): string {
  return {
    "5m": "5 minutes",
    "15m": "15 minutes",
    "1h": "1 hour",
    "1d": "1 day",
    "1wk": "1 week",
    "1mo": "1 month",
  }[interval] ?? interval;
}

export function directionLabel(direction: AlertDirection): string {
  if (direction === "bullish") return "Bullish";
  if (direction === "bearish") return "Bearish";
  return "Bullish and bearish";
}

export function eventLabel(eventType: AlertEventType): string {
  return eventType === "started"
    ? "started"
    : eventType === "changed"
      ? "changed"
      : "ended";
}

export function formatSignalTime(
  timestamp?: string | null,
  interval?: string,
): string {
  if (!timestamp) return "—";
  const options: Intl.DateTimeFormatOptions = {
    timeZone: "Asia/Kolkata",
    dateStyle: "medium",
  };
  if (!interval || ["5m", "15m", "1h"].includes(interval)) {
    options.timeStyle = "short";
  }
  return new Intl.DateTimeFormat("en-IN", options).format(new Date(timestamp));
}
