import { useEffect, useRef } from "react";
import {
  ClerkProvider,
  SignIn,
  SignUp,
  useAuth,
  useClerk,
} from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Route, Switch, Router as WouterRouter, useLocation, Link } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Header } from "@/components/layout/header";
import ScreenerPage from "@/pages/screener";
import WatchlistPage from "@/pages/watchlist";
import AlertsPage from "@/pages/alerts";
import { AlertsProvider } from "@/context/alerts-context";
import NotFound from "@/pages/not-found";
import TradingPage from "@/pages/trading";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30000, // 30 seconds
      refetchOnWindowFocus: false,
    },
  },
});

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY.");
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "#26a269",
    colorForeground: "#e2e8f0",
    colorMutedForeground: "#9aa7b8",
    colorDanger: "#f87171",
    colorBackground: "#111821",
    colorInput: "#0b1219",
    colorInputForeground: "#e2e8f0",
    colorNeutral: "#34404f",
    fontFamily: "'Space Grotesk', system-ui, sans-serif",
    borderRadius: "0.75rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-[#111821] border border-slate-700 rounded-2xl w-[440px] max-w-full overflow-hidden",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-slate-100",
    headerSubtitle: "text-slate-300",
    socialButtonsBlockButtonText: "text-slate-100",
    formFieldLabel: "text-slate-200",
    footerActionLink: "text-emerald-400",
    footerActionText: "text-slate-300",
    dividerText: "text-slate-300",
    identityPreviewEditButton: "text-emerald-400",
    formFieldSuccessText: "text-emerald-400",
    alertText: "text-red-300",
    logoBox: "mx-auto",
    logoImage: "h-10 w-10",
    socialButtonsBlockButton: "border-slate-700 bg-slate-900",
    formButtonPrimary: "bg-emerald-600 text-white hover:bg-emerald-500",
    formFieldInput: "bg-slate-950 border-slate-700 text-slate-100",
    footerAction: "border-t border-slate-700",
    dividerLine: "bg-slate-700",
    alert: "bg-red-950 border-red-800",
    otpCodeFieldInput: "bg-slate-950 border-slate-700 text-slate-100",
    formFieldRow: "mb-4",
    main: "bg-transparent",
  },
};

function SignInPage() {
  return (
    <div className="flex min-h-[100dvh] flex-col items-center justify-center gap-6 bg-background px-4 py-8">
      <Link href="/" className="flex items-center gap-3 text-foreground">
        <img src={`${basePath}/logo.svg`} alt="" className="h-10 w-10" />
        <span>
          <span className="block text-lg font-bold">BBands BO</span>
          <span className="block text-xs text-muted-foreground">Private trend alerts</span>
        </span>
      </Link>
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
        forceRedirectUrl={`${basePath}/alerts`}
      />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-[100dvh] flex-col items-center justify-center gap-6 bg-background px-4 py-8">
      <Link href="/" className="flex items-center gap-3 text-foreground">
        <img src={`${basePath}/logo.svg`} alt="" className="h-10 w-10" />
        <span>
          <span className="block text-lg font-bold">BBands BO</span>
          <span className="block text-xs text-muted-foreground">Private trend alerts</span>
        </span>
      </Link>
      <SignUp
        routing="path"
        path={`${basePath}/sign-up`}
        signInUrl={`${basePath}/sign-in`}
        forceRedirectUrl={`${basePath}/alerts`}
      />
    </div>
  );
}

function PrivateAlertsRoute() {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) {
    return (
      <div className="container mx-auto max-w-3xl px-4 py-16 text-center text-sm text-muted-foreground">
        Checking your sign-in…
      </div>
    );
  }
  if (!isSignedIn) {
    return (
      <div className="container mx-auto max-w-2xl px-4 py-16">
        <Card>
          <CardHeader>
            <CardTitle>Sign in to view your private alerts</CardTitle>
            <CardDescription>
              Alert settings, trend history, and Telegram links are private to your account.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-3">
            <Button asChild>
              <Link href="/sign-in">Sign in</Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/sign-up">Create account</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  return <AlertsPage />;
}

function MainAppRoutes() {
  return (
    <>
      <Header />
      <Switch>
        <Route path="/" component={ScreenerPage} />
        <Route path="/watchlist" component={WatchlistPage} />
        <Route path="/alerts" component={PrivateAlertsRoute} />
        <Route path="/trading" component={TradingPage} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function AppRoutes() {
  return (
    <Switch>
      <Route path="/sign-in/*?" component={SignInPage} />
      <Route path="/sign-up/*?" component={SignUpPage} />
      <Route component={MainAppRoutes} />
    </Switch>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const previousUserId = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (previousUserId.current !== undefined && previousUserId.current !== userId) {
        client.clear();
      }
      previousUserId.current = userId;
    });
    return unsubscribe;
  }, [addListener, client]);

  return null;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "Welcome back",
            subtitle: "Sign in to manage your private alerts",
          },
        },
        signUp: {
          start: {
            title: "Create your BBands BO account",
            subtitle: "Save private alerts and connect your Telegram chat",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <AlertsProvider>
            <ClerkQueryClientCacheInvalidator />
            <AppRoutes />
            <Toaster />
          </AlertsProvider>
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
