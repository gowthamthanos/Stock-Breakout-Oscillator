import { useMemo, useState } from "react";
import {
  getGetTelegramStatusQueryKey,
  useGetScreenerPresets,
  useGetTelegramStatus,
  useSendTelegramTest,
  useStartTelegramLink,
} from "@workspace/api-client-react";
import type { AlertCreateInput } from "@workspace/api-client-react";
import { Bell, BellRing, CheckCircle2, CircleOff, Plus, RefreshCw, Send, Trash2, X } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useAlerts } from "@/context/alerts-context";
import { directionLabel, eventLabel, formatSignalTime, intervalLabel, type AlertDirection } from "@/lib/alerts";

const intervals = [
  { value: "5m", label: "5 minutes" },
  { value: "15m", label: "15 minutes" },
  { value: "1h", label: "1 hour" },
  { value: "1d", label: "1 day" },
  { value: "1wk", label: "1 week" },
  { value: "1mo", label: "1 month" },
];

export default function AlertsPage() {
  const { data: presets = [] } = useGetScreenerPresets();
  const queryClient = useQueryClient();
  const telegramQuery = useGetTelegramStatus({
    query: {
      queryKey: getGetTelegramStatusQueryKey(),
      refetchInterval: 5_000,
      refetchOnWindowFocus: true,
    },
  });
  const telegramStatus = telegramQuery.data ?? null;
  const telegramLoading = telegramQuery.isLoading;
  const startLinkMutation = useStartTelegramLink();
  const testTelegramMutation = useSendTelegramTest();
  const {
    alerts,
    events,
    notificationPermission,
    isLoading: alertsLoading,
    loadError,
    actionError,
    clearActionError,
    addAlert,
    removeAlert,
    toggleAlert,
    retryTelegramAlert,
    requestNotificationPermission,
    clearEvents,
  } = useAlerts();
  const [source, setSource] = useState("nifty_50");
  const [customSymbol, setCustomSymbol] = useState("");
  const [interval, setInterval] = useState("1d");
  const [direction, setDirection] = useState<"bullish" | "bearish" | "both">("both");
  const [period, setPeriod] = useState(14);
  const [stdDev, setStdDev] = useState(1);
  const [telegramEnabled, setTelegramEnabled] = useState(true);
  const [telegramCode, setTelegramCode] = useState<string | null>(null);
  const [telegramCodeExpiry, setTelegramCodeExpiry] = useState<string | null>(null);
  const [telegramCodeBot, setTelegramCodeBot] = useState<string | null>(null);
  const [telegramAction, setTelegramAction] = useState<"refresh" | "link" | "test" | null>(null);
  const [telegramMessage, setTelegramMessage] = useState("");

  const selectedPreset = useMemo(
    () => presets.find((preset) => preset.id === source),
    [presets, source],
  );

  const refreshTelegramStatus = () => {
    setTelegramAction("refresh");
    setTelegramMessage("");
    void queryClient.invalidateQueries({
      queryKey: getGetTelegramStatusQueryKey(),
    }).finally(() => setTelegramAction(null));
  };

  const handleTelegramTest = () => {
    setTelegramAction("test");
    setTelegramMessage("");
    testTelegramMutation.mutate(undefined, {
      onSuccess: (result) => setTelegramMessage(result.message),
      onError: (error) => setTelegramMessage(error.message),
      onSettled: () => setTelegramAction(null),
    });
  };

  const handleTelegramLink = () => {
    setTelegramAction("link");
    setTelegramMessage("");
    startLinkMutation.mutate(undefined, {
      onSuccess: (result) => {
        setTelegramCode(result.code);
        setTelegramCodeExpiry(result.expiresAt);
        setTelegramCodeBot(result.botUsername);
        setTelegramMessage("Send the one-time command below from the Telegram chat you want to use.");
      },
      onError: (error) => setTelegramMessage(error.message),
      onSettled: () => setTelegramAction(null),
    });
  };

  const handleCreate = () => {
    clearActionError();
    const symbol = source === "custom"
      ? customSymbol.trim().toUpperCase()
      : undefined;
    if (source === "custom" && !symbol) return;

    addAlert({
      label: source === "custom"
        ? symbol!
        : selectedPreset?.name ?? "Indian market",
      symbol: symbol ?? undefined,
      preset: source === "custom" ? undefined : source,
      presetName: source === "custom" ? undefined : selectedPreset?.name,
      interval: interval as AlertCreateInput["interval"],
      direction,
      period,
      stdDev,
      telegramEnabled,
    });
    setCustomSymbol("");
  };
  const alertSettingsValid =
    Number.isInteger(period) && period >= 2 && period <= 100 &&
    Number.isFinite(stdDev) && stdDev >= 0.1 && stdDev <= 5;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto max-w-5xl space-y-6 px-4 py-6 lg:px-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="mb-1 text-xs font-semibold uppercase tracking-[0.18em] text-primary">
              Private signal monitoring
            </p>
            <h1 className="text-2xl font-bold tracking-tight">Breakout alerts</h1>
            <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
              Your alerts run on the server, even when this page is closed. Each account has its own alerts and Telegram chat.
            </p>
          </div>
          {notificationPermission !== "granted" && notificationPermission !== "unsupported" && (
            <Button variant="outline" className="gap-2" onClick={requestNotificationPermission}>
              <Bell className="h-4 w-4" />
              Enable browser notifications
            </Button>
          )}
          {notificationPermission === "granted" && (
            <Badge variant="outline" className="gap-2 border-emerald-500/40 text-emerald-400">
              <BellRing className="h-3.5 w-3.5" />
              Browser notifications enabled
            </Badge>
          )}
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Plus className="h-4 w-4 text-primary" />
              Create an alert
            </CardTitle>
            <CardDescription>
              The server checks closed candles and sends an alert when a green or red line first appears.
              The trend stays active until the opposite line appears.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-[1.4fr_1fr_1fr_auto] md:items-end">
              <div className="space-y-2">
                <Label>Stocks or category</Label>
                <Select value={source} onValueChange={setSource}>
                  <SelectTrigger data-testid="select-alert-source">
                    <SelectValue placeholder="Choose a basket" />
                  </SelectTrigger>
                  <SelectContent className="max-h-80">
                    <SelectItem value="custom">Single NSE/BSE symbol</SelectItem>
                    {presets.map((preset) => (
                      <SelectItem key={preset.id} value={preset.id}>
                        {preset.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {source === "custom" && (
                  <Input
                    value={customSymbol}
                    onChange={(event) => setCustomSymbol(event.target.value.toUpperCase())}
                    placeholder="RELIANCE or RELIANCE.NS"
                    data-testid="input-alert-symbol"
                  />
                )}
              </div>

              <div className="space-y-2">
                <Label>Timeframe</Label>
                <Select value={interval} onValueChange={setInterval}>
                  <SelectTrigger data-testid="select-alert-interval">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {intervals.map((item) => (
                      <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Signal</Label>
                   <Select value={direction} onValueChange={(value) => setDirection(value as AlertDirection)}>
                  <SelectTrigger data-testid="select-alert-direction">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="both">Both green and red lines</SelectItem>
                    <SelectItem value="bullish">Green line — bullish</SelectItem>
                    <SelectItem value="bearish">Red line — bearish</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button className="gap-2" onClick={handleCreate} disabled={(source === "custom" && !customSymbol.trim()) || !alertSettingsValid}>
                <Bell className="h-4 w-4" />
                Create alert
              </Button>
            </div>
            <details className="mt-4 rounded-md border p-3">
              <summary className="cursor-pointer text-sm font-medium">
                Advanced settings for this timeframe
              </summary>
              <p className="mt-2 text-xs text-muted-foreground">
                These indicator and Telegram settings apply only to this alert and its selected timeframe.
                Create another alert to use different settings on another timeframe.
              </p>
              <div className="mt-3 grid gap-4 sm:grid-cols-3 sm:items-end">
                <div className="space-y-2">
                  <Label htmlFor="alert-period">BBands period</Label>
                  <Input
                    id="alert-period"
                    type="number"
                    min={2}
                    max={100}
                    step={1}
                    value={period}
                    onChange={(event) => setPeriod(Number(event.target.value))}
                    data-testid="input-alert-period"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="alert-stddev">Deviation multiplier</Label>
                  <Input
                    id="alert-stddev"
                    type="number"
                    min={0.1}
                    max={5}
                    step={0.1}
                    value={stdDev}
                    onChange={(event) => setStdDev(Number(event.target.value))}
                    data-testid="input-alert-stddev"
                  />
                </div>
                <label className="flex min-h-9 items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={telegramEnabled}
                    onChange={(event) => setTelegramEnabled(event.target.checked)}
                    className="h-4 w-4 accent-primary"
                    data-testid="checkbox-alert-telegram"
                  />
                  Send this alert to Telegram
                </label>
              </div>
              {!alertSettingsValid && (
                <p className="mt-2 text-xs text-destructive">
                  Use a period from 2–100 and a deviation multiplier from 0.1–5.
                </p>
              )}
            </details>
            {actionError && (
              <p className="mt-3 text-sm text-destructive" role="alert">
                {actionError}
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex-row items-start justify-between gap-4 space-y-0">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <Send className="h-4 w-4 text-primary" />
                Telegram notifications
              </CardTitle>
              <CardDescription>
              Telegram delivery can be enabled or disabled separately for each timeframe alert.
              Messages are sent after that timeframe’s candle is confirmed closed.
              </CardDescription>
            </div>
            {telegramStatus?.connected ? (
              <Badge variant="outline" className="shrink-0 gap-2 border-emerald-500/40 text-emerald-400">
                <CheckCircle2 className="h-3.5 w-3.5" />
                Connected
              </Badge>
            ) : (
              <Badge variant="secondary" className="shrink-0">
                {telegramLoading ? "Checking" : "Not connected"}
              </Badge>
            )}
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              {telegramStatus?.connected
                ? `Sending to ${telegramStatus.chatLabel ?? "your Telegram chat"} via ${telegramStatus.botUsername ? `@${telegramStatus.botUsername}` : "your bot"}.`
                : telegramStatus?.configured
                  ? `Generate a one-time code, open ${telegramStatus.botUsername ? `@${telegramStatus.botUsername}` : "your Telegram bot"}, and send /link CODE from the chat you want to receive alerts.`
                  : telegramLoading
                    ? "Checking the Telegram connection…"
                    : "Telegram is not configured for this app."}
            </p>
            {telegramCode && (
              <div className="rounded-md border border-primary/30 bg-primary/5 p-3">
                <p className="text-xs text-muted-foreground">
                  Send this command from your personal Telegram chat:
                </p>
                <code className="mt-1 block select-all text-sm font-semibold text-primary">
                  /link {telegramCode}
                </code>
                <p className="mt-1 text-xs text-muted-foreground">
                  {telegramCodeBot ? `Bot: @${telegramCodeBot} · ` : ""}
                  Expires {telegramCodeExpiry ? new Date(telegramCodeExpiry).toLocaleTimeString() : "soon"}.
                  This page checks for the link automatically.
                </p>
              </div>
            )}
            {telegramMessage && (
              <p className="text-sm text-primary">{telegramMessage}</p>
            )}
            {telegramQuery.isError && (
              <p className="text-sm text-destructive">
                {telegramQuery.error.message || "Could not check the Telegram connection."}
              </p>
            )}
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                className="gap-2"
                onClick={refreshTelegramStatus}
                disabled={telegramAction !== null}
              >
                <RefreshCw className={`h-4 w-4 ${telegramAction === "refresh" ? "animate-spin" : ""}`} />
                Refresh connection
              </Button>
              <Button
                variant="outline"
                className="gap-2"
                onClick={handleTelegramLink}
                disabled={!telegramStatus?.configured || telegramAction !== null}
              >
                <Send className="h-4 w-4" />
                {telegramStatus?.connected ? "Link another chat" : "Generate link code"}
              </Button>
              <Button
                className="gap-2"
                onClick={handleTelegramTest}
                disabled={!telegramStatus?.connected || telegramAction !== null}
              >
                <Send className="h-4 w-4" />
                Send test message
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="text-base">Active alerts</CardTitle>
                <CardDescription>{alerts.length} configured monitor{alerts.length === 1 ? "" : "s"}</CardDescription>
              </div>
              {alerts.length > 0 && <Badge variant="secondary">{alerts.filter((alert) => alert.enabled).length} running</Badge>}
            </CardHeader>
            <CardContent className="space-y-3">
              {alertsLoading && (
                <p className="text-sm text-muted-foreground">Loading your private alerts…</p>
              )}
              {loadError && (
                <p className="text-sm text-destructive" role="alert">{loadError}</p>
              )}
              {alerts.length === 0 ? (
                <div className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">
                  <Bell className="mx-auto mb-3 h-8 w-8 opacity-40" />
                  Create an alert to start monitoring BBands BO signals.
                </div>
              ) : alerts.map((alert) => (
                <div key={alert.id} className="flex items-center justify-between gap-3 rounded-lg border bg-muted/20 p-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold">{alert.label}</span>
                      <Badge variant={alert.direction === "bullish" ? "default" : "destructive"}>
                        {directionLabel(alert.direction)}
                      </Badge>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {intervalLabel(alert.interval)} · Period {alert.period} · Deviation {alert.stdDev}
                      {" · "}{alert.telegramEnabled ? "Telegram on" : "Telegram off"}
                      {" · "}{alert.enabled ? "Monitoring" : "Paused"}
                      {alert.lastTriggeredSymbol ? ` · Last: ${alert.lastTriggeredSymbol}` : ""}
                    </p>
                    {alert.lastScanError && (
                      <p className="mt-1 text-xs text-destructive">
                        Data issue: {alert.lastScanError}
                      </p>
                    )}
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <Button variant="ghost" size="icon" onClick={() => toggleAlert(alert.id)} title={alert.enabled ? "Pause alert" : "Resume alert"}>
                      {alert.enabled ? <CircleOff className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => removeAlert(alert.id)} title="Delete alert">
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div>
                <CardTitle className="text-base">Recent notifications</CardTitle>
                <CardDescription>Signals detected by your monitors</CardDescription>
              </div>
              {events.length > 0 && (
                <Button variant="ghost" size="icon" onClick={clearEvents} title="Clear notifications">
                  <X className="h-4 w-4" />
                </Button>
              )}
            </CardHeader>
            <CardContent className="space-y-2">
              {events.length === 0 ? (
                <div className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">
                  No breakout notifications yet.
                </div>
              ) : events.slice(0, 8).map((event) => (
                <div key={event.id} className="flex items-center gap-3 rounded-lg border p-3">
                  <div className={`rounded-full p-2 ${event.direction === "bullish" ? "bg-emerald-500/15 text-emerald-400" : "bg-red-500/15 text-red-400"}`}>
                    {event.direction === "bullish" ? <BellRing className="h-4 w-4" /> : <Bell className="h-4 w-4" />}
                  </div>
                  <div className="min-w-0 flex-1">
                     <p className="text-sm font-semibold">
                       {event.symbol} · {event.eventType === "changed"
                         ? `Trend changed to ${directionLabel(event.direction)}`
                         : `${directionLabel(event.direction)} ${eventLabel(event.eventType)}`}
                     </p>
                    <p className="text-xs text-muted-foreground">
                       {event.alertLabel} · oscillator {event.oscillatorValue.toFixed(3)} · {intervalLabel(event.interval)}
                       {" · "}period {event.period}, deviation {event.stdDev}
                      {(event.breakoutStartAt ?? event.breakoutAt)
                        ? ` · Start: ${formatSignalTime(event.breakoutStartAt ?? event.breakoutAt, event.interval)}`
                        : ""}
                      {event.breakoutEndAt
                        ? ` · End: ${formatSignalTime(event.breakoutEndAt, event.interval)}`
                        : " · Active"}
                    </p>
                    {event.telegramStatus && (
                      <p className={`mt-1 text-[10px] ${
                        event.telegramStatus === "failed"
                          ? "text-destructive"
                          : event.telegramStatus === "sent"
                            ? "text-emerald-400"
                            : "text-muted-foreground"
                      }`}>
                        Telegram {event.telegramStatus}
                        {event.telegramError ? `: ${event.telegramError}` : ""}
                      </p>
                    )}
                  </div>
                  {event.telegramStatus === "failed" && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="shrink-0"
                      onClick={() => retryTelegramAlert(event.id)}
                    >
                      Retry
                    </Button>
                  )}
                  <time className="text-[10px] text-muted-foreground">
                    {new Date(event.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </time>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
