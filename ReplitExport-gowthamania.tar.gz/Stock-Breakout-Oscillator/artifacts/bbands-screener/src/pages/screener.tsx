import { useState, useMemo } from 'react';
import { Link } from 'wouter';
import { useRunScreener, useGetScreenerSummary, useGetScreenerPresets, getRunScreenerQueryKey, getGetScreenerSummaryQueryKey } from '@workspace/api-client-react';
import type { RunScreenerParams, GetScreenerSummaryParams } from '@workspace/api-client-react';
import { ScreenerFilters, ScreenerFiltersState } from '@/components/screener-filters';
import { SummaryStat } from '@/components/summary-stat';
import { SignalBadge } from '@/components/signal-badge';
import { TrendingUp, TrendingDown, Activity, ArrowUpRight } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { cn } from '@/lib/utils';
import { formatSignalTime } from '@/lib/alerts';

export default function ScreenerPage() {
  const [filters, setFilters] = useState<ScreenerFiltersState>({
    preset: 'nifty_50',
    interval: '1d',
    period: 14,
    stdDev: 1.0,
    src: 'close',
  });

  // Build query params
  const runQueryParams = useMemo<RunScreenerParams>(() => ({
    preset: filters.preset as RunScreenerParams['preset'],
    interval: filters.interval as RunScreenerParams['interval'],
    period: filters.period,
    stdDev: filters.stdDev,
    src: filters.src,
    signal: filters.signal,
  }), [filters]);

  const summaryQueryParams = useMemo<GetScreenerSummaryParams>(() => ({
    preset: filters.preset as GetScreenerSummaryParams['preset'],
    interval: filters.interval as GetScreenerSummaryParams['interval'],
    period: filters.period,
    stdDev: filters.stdDev,
    src: filters.src,
    signal: filters.signal,
  }), [filters]);

  // Fetch data
  const { data: presets = [], isLoading: presetsLoading } = useGetScreenerPresets();
  
  const { data: results = [], isLoading: resultsLoading, error: resultsError, refetch: refetchResults } = useRunScreener(
    runQueryParams,
    { query: { queryKey: getRunScreenerQueryKey(runQueryParams) } }
  );

  const { data: summary, isLoading: summaryLoading } = useGetScreenerSummary(
    summaryQueryParams,
    { query: { queryKey: getGetScreenerSummaryQueryKey(summaryQueryParams) } }
  );

  const isLoading = resultsLoading || summaryLoading;
  const activeTrendResults = useMemo(
    () =>
      [...results]
        .filter((result) => result.trend === 'bullish' || result.trend === 'bearish')
        .sort((a, b) => {
          const aTime = a.breakoutStartAt ? Date.parse(a.breakoutStartAt) : Number.NEGATIVE_INFINITY;
          const bTime = b.breakoutStartAt ? Date.parse(b.breakoutStartAt) : Number.NEGATIVE_INFINITY;
          const difference = bTime - aTime;
          return Number.isNaN(difference) || difference === 0
            ? a.symbol.localeCompare(b.symbol)
            : difference;
        }),
    [results],
  );

  const formatNumber = (num: number | null | undefined) => {
    if (num === null || num === undefined) return '—';
    if (num >= 1e9) return `${(num / 1e9).toFixed(2)}B`;
    if (num >= 1e6) return `${(num / 1e6).toFixed(2)}M`;
    if (num >= 1e3) return `${(num / 1e3).toFixed(2)}K`;
    return num.toFixed(2);
  };

  const formatPrice = (price: number, symbol?: string) => {
    // Indian stocks on NSE (.NS) or BSE (.BO) are priced in INR
    const s = symbol ?? '';
    const isIndian = s.endsWith('.NS') || s.endsWith('.BO') ||
      s.startsWith('^NSE') || s.startsWith('^BSE') ||
      s.startsWith('^CNX') || s.startsWith('^NSM');
    return new Intl.NumberFormat(isIndian ? 'en-IN' : 'en-US', {
      style: 'currency',
      currency: isIndian ? 'INR' : 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(price);
  };

  const formatPercent = (pct: number) => {
    const sign = pct >= 0 ? '+' : '';
    return `${sign}${pct.toFixed(2)}%`;
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 lg:px-6 py-6 space-y-6">
        {/* Filters */}
        <Card className="p-4">
          <ScreenerFilters
            filters={filters}
            onFiltersChange={setFilters}
            presets={presets}
            isLoading={isLoading}
            onRefresh={() => refetchResults()}
          />
        </Card>

        {/* Summary Stats */}
        {summaryLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-20" />
            ))}
          </div>
        ) : summary ? (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <SummaryStat label="Active trends" value={summary.totalScanned} icon={Activity} />
            <SummaryStat
              label="Bullish stocks"
              value={summary.bullishBreakouts}
              icon={TrendingUp}
              variant="bullish"
            />
            <SummaryStat
              label="Bearish stocks"
              value={summary.bearishBreakouts}
              icon={TrendingDown}
              variant="bearish"
            />
          </div>
        ) : null}

        {summary && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            <Card className="p-4">
              <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold text-[hsl(var(--chart-1))]">
                <TrendingUp className="h-4 w-4" />
                Latest bullish changes
              </h2>
              {summary.topBullish.length === 0 ? (
                <p className="text-sm text-muted-foreground">No active bullish trends.</p>
              ) : (
                <div className="space-y-2">
                  {summary.topBullish.map((item) => (
                    <div key={item.symbol} className="flex items-center justify-between gap-3 text-sm">
                      <span className="font-mono font-semibold">{item.symbol}</span>
                      <time className="text-xs text-muted-foreground">
                        {item.breakoutStartAt
                          ? formatSignalTime(item.breakoutStartAt, filters.interval)
                          : "Before available history"}
                      </time>
                    </div>
                  ))}
                </div>
              )}
            </Card>
            <Card className="p-4">
              <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold text-[hsl(var(--chart-2))]">
                <TrendingDown className="h-4 w-4" />
                Latest bearish changes
              </h2>
              {summary.topBearish.length === 0 ? (
                <p className="text-sm text-muted-foreground">No active bearish trends.</p>
              ) : (
                <div className="space-y-2">
                  {summary.topBearish.map((item) => (
                    <div key={item.symbol} className="flex items-center justify-between gap-3 text-sm">
                      <span className="font-mono font-semibold">{item.symbol}</span>
                      <time className="text-xs text-muted-foreground">
                        {item.breakoutStartAt
                          ? formatSignalTime(item.breakoutStartAt, filters.interval)
                          : "Before available history"}
                      </time>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        )}

        {/* Results Table */}
        <Card className="overflow-hidden">
          {resultsError ? (
            <Alert variant="destructive" className="m-4">
              <AlertDescription>
                Failed to load screener results. Please try again.
              </AlertDescription>
            </Alert>
          ) : resultsLoading ? (
            <div className="p-4 space-y-3">
              {Array.from({ length: 10 }).map((_, i) => (
                <Skeleton key={i} className="h-16" />
              ))}
            </div>
          ) : activeTrendResults.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground">
              <Activity className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p className="text-sm">No results found. Adjust your filters and try again.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="text-left text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Symbol
                    </th>
                    <th className="text-left text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Name
                    </th>
                    <th className="text-right text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Price
                    </th>
                    <th className="text-right text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Change
                    </th>
                    <th className="text-left text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Trend
                    </th>
                    <th className="text-left text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Trend changed (IST)
                    </th>
                    <th className="text-right text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Volume
                    </th>
                    <th className="text-right text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Market Cap
                    </th>
                    <th className="text-right text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Trade
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {activeTrendResults.map((result, idx) => (
                    <tr
                      key={`${result.symbol}-${idx}`}
                      className="border-b hover-elevate transition-colors"
                      data-testid={`row-screener-result-${result.symbol}`}
                    >
                      <td className="p-3">
                        <span className="font-bold font-mono text-sm" data-testid={`text-symbol-${result.symbol}`}>
                          {result.symbol}
                        </span>
                      </td>
                      <td className="p-3">
                        <span className="text-sm text-muted-foreground truncate max-w-[200px] block">
                          {result.name}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <span className="font-mono font-medium text-sm" data-testid={`text-price-${result.symbol}`}>
                          {formatPrice(result.price, result.symbol)}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <span
                          className={cn(
                            'font-mono font-medium text-sm tabular-nums',
                            result.changePercent >= 0
                              ? 'text-[hsl(var(--chart-1))]'
                              : 'text-[hsl(var(--chart-2))]'
                          )}
                          data-testid={`text-change-${result.symbol}`}
                        >
                          {formatPercent(result.changePercent)}
                        </span>
                      </td>
                      <td className="p-3">
                        <SignalBadge
                          signal={result.trend === 'bullish' ? 'bullish_breakout' : 'bearish_breakout'}
                        />
                      </td>
                      <td className="p-3">
                        <time
                          dateTime={result.breakoutStartAt ?? undefined}
                          title={result.breakoutStartAt ?? undefined}
                          className="whitespace-nowrap text-xs text-muted-foreground"
                        >
                          {result.breakoutStartAt
                            ? formatSignalTime(result.breakoutStartAt, filters.interval)
                            : "Before available history"}
                        </time>
                      </td>
                      <td className="p-3 text-right">
                        <span className="font-mono text-sm text-muted-foreground">
                          {formatNumber(result.volume)}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <span className="font-mono text-sm text-muted-foreground">
                          {formatNumber(result.marketCap)}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <Button variant="outline" size="sm" asChild>
                          <Link
                            href={`/trading?symbol=${encodeURIComponent(result.symbol)}&signal=${encodeURIComponent(result.signal)}&price=${result.price}&side=${result.trend === 'bearish' ? 'SELL' : 'BUY'}`}
                          >
                            <ArrowUpRight className="mr-1 h-3.5 w-3.5" />
                            Trade
                          </Link>
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
