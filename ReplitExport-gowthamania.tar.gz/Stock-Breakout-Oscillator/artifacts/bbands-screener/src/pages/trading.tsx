import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, CheckCircle2, Loader2, ShieldCheck, XCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";

type OrderType = "MARKET" | "LIMIT" | "SL" | "SL-M";
type TransactionType = "BUY" | "SELL";

interface Preview {
  environment: string;
  symbol: string;
  instrumentToken: string;
  quantity: number;
  transactionType: TransactionType;
  orderType: OrderType;
  product: "D" | "I";
  validity: "DAY" | "IOC";
  price: number;
  triggerPrice: number;
  tag: string;
  message: string;
}

interface ApiStatus {
  configured: boolean;
  environment: string;
  liveTradingEnabled: boolean;
}

function readQueryValue(name: string): string {
  if (typeof window === "undefined") return "";
  return new URLSearchParams(window.location.search).get(name) ?? "";
}

export default function TradingPage() {
  const initialSymbol = readQueryValue("symbol").toUpperCase();
  const signal = readQueryValue("signal");
  const initialPrice = readQueryValue("price");
  const initialSide = readQueryValue("side") === "SELL" ? "SELL" : "BUY";

  const [status, setStatus] = useState<ApiStatus | null>(null);
  const [symbol, setSymbol] = useState(initialSymbol);
  const [transactionType, setTransactionType] = useState<TransactionType>(initialSide);
  const [quantity, setQuantity] = useState("1");
  const [orderType, setOrderType] = useState<OrderType>("MARKET");
  const [product, setProduct] = useState<"D" | "I">("D");
  const [validity, setValidity] = useState<"DAY" | "IOC">("DAY");
  const [price, setPrice] = useState(initialPrice);
  const [triggerPrice, setTriggerPrice] = useState("");
  const [preview, setPreview] = useState<Preview | null>(null);
  const [order, setOrder] = useState<unknown>(null);
  const [orderId, setOrderId] = useState("");
  const [loading, setLoading] = useState<"preview" | "place" | "refresh" | "cancel" | null>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const needsPrice = orderType === "LIMIT" || orderType === "SL";
  const needsTrigger = orderType === "SL" || orderType === "SL-M";

  useEffect(() => {
    fetch("/api/upstox/status")
      .then(async (response) => {
        if (!response.ok) throw new Error("Could not read Upstox sandbox status");
        return response.json() as Promise<ApiStatus>;
      })
      .then(setStatus)
      .catch((reason: unknown) => setError(reason instanceof Error ? reason.message : "Could not read sandbox status"));
  }, []);

  const payload = useMemo(() => ({
    symbol,
    transactionType,
    quantity: Number(quantity),
    orderType,
    product,
    validity,
    price: needsPrice ? Number(price) : undefined,
    triggerPrice: needsTrigger ? Number(triggerPrice) : undefined,
    tag: signal ? `bbands-${signal.replace("_", "-")}` : "bbands-bo",
  }), [symbol, transactionType, quantity, orderType, product, validity, price, triggerPrice, needsPrice, needsTrigger, signal]);

  const requestPreview = async () => {
    setLoading("preview");
    setError("");
    setMessage("");
    setPreview(null);
    try {
      const response = await fetch("/api/upstox/orders/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const body = await response.json() as Preview & { error?: string };
      if (!response.ok) throw new Error(body.error ?? "Could not build order preview");
      setPreview(body);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not build order preview");
    } finally {
      setLoading(null);
    }
  };

  const placeOrder = async () => {
    if (!preview) {
      await requestPreview();
      return;
    }
    if (!window.confirm(`Place this ${preview.transactionType} order for ${preview.quantity} ${preview.symbol} in Upstox Sandbox?`)) {
      return;
    }

    setLoading("place");
    setError("");
    setMessage("");
    try {
      const response = await fetch("/api/upstox/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const body = await response.json() as { response?: { data?: { order_id?: string } }; error?: string };
      if (!response.ok) throw new Error(body.error ?? "Sandbox order was rejected");
      const id = body.response?.data?.order_id ?? "";
      setOrder(body);
      setOrderId(id);
      setMessage(id ? `Sandbox order placed: ${id}` : "Sandbox order placed.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Sandbox order failed");
    } finally {
      setLoading(null);
    }
  };

  const refreshOrder = async () => {
    if (!orderId) return;
    setLoading("refresh");
    setError("");
    try {
      const response = await fetch(`/api/upstox/orders/${encodeURIComponent(orderId)}`);
      const body = await response.json() as { error?: string };
      if (!response.ok) throw new Error(body.error ?? "Could not refresh order");
      setOrder(body);
      setMessage("Sandbox order status refreshed.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not refresh order");
    } finally {
      setLoading(null);
    }
  };

  const cancelOrder = async () => {
    if (!orderId || !window.confirm(`Cancel sandbox order ${orderId}?`)) return;
    setLoading("cancel");
    setError("");
    try {
      const response = await fetch(`/api/upstox/orders/${encodeURIComponent(orderId)}`, { method: "DELETE" });
      const body = await response.json() as { error?: string };
      if (!response.ok) throw new Error(body.error ?? "Could not cancel order");
      setOrder(body);
      setMessage("Sandbox order cancellation requested.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not cancel order");
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto max-w-6xl space-y-6 px-4 py-6 lg:px-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <Link href="/" className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
              <ArrowLeft className="h-4 w-4" /> Back to screener
            </Link>
            <p className="mb-1 text-xs font-semibold uppercase tracking-[0.18em] text-primary">Paper execution</p>
            <h1 className="text-2xl font-bold tracking-tight">Upstox Sandbox Trading</h1>
            <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
              Turn a BBands breakout signal into a reviewable test order without sending anything to the live market.
            </p>
          </div>
          <Badge className="gap-2 border-emerald-500/40 bg-emerald-500/10 text-emerald-400" variant="outline">
            <ShieldCheck className="h-4 w-4" /> Sandbox only
          </Badge>
        </div>

        {signal && (
          <Alert>
            <CheckCircle2 className="h-4 w-4" />
            <AlertDescription>
              This ticket was opened from a <strong>{signal.replaceAll("_", " ")}</strong> screener signal.
            </AlertDescription>
          </Alert>
        )}
        {error && (
          <Alert variant="destructive">
            <XCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        {message && <Alert><AlertDescription>{message}</AlertDescription></Alert>}

        <div className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Order ticket</CardTitle>
              <CardDescription>Review every field before creating a sandbox order.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="trade-symbol">NSE symbol</Label>
                <Input id="trade-symbol" value={symbol} onChange={(event) => setSymbol(event.target.value.toUpperCase())} placeholder="RELIANCE.NS" />
                <p className="text-xs text-muted-foreground">Use an NSE equity symbol from the screener, such as RELIANCE.NS.</p>
              </div>
              <div className="space-y-2">
                <Label>Side</Label>
                <Select value={transactionType} onValueChange={(value) => setTransactionType(value as TransactionType)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="BUY">Buy</SelectItem><SelectItem value="SELL">Sell</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="trade-quantity">Quantity</Label>
                <Input id="trade-quantity" type="number" min="1" step="1" value={quantity} onChange={(event) => setQuantity(event.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Order type</Label>
                <Select value={orderType} onValueChange={(value) => setOrderType(value as OrderType)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="MARKET">Market</SelectItem>
                    <SelectItem value="LIMIT">Limit</SelectItem>
                    <SelectItem value="SL">Stop loss limit</SelectItem>
                    <SelectItem value="SL-M">Stop loss market</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Product</Label>
                <Select value={product} onValueChange={(value) => setProduct(value as "D" | "I")}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="D">Delivery</SelectItem><SelectItem value="I">Intraday</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Validity</Label>
                <Select value={validity} onValueChange={(value) => setValidity(value as "DAY" | "IOC")}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="DAY">Day</SelectItem><SelectItem value="IOC">Immediate or cancel</SelectItem></SelectContent>
                </Select>
              </div>
              {needsPrice && (
                <div className="space-y-2">
                  <Label htmlFor="trade-price">Price</Label>
                  <Input id="trade-price" type="number" min="0" step="0.05" value={price} onChange={(event) => setPrice(event.target.value)} />
                </div>
              )}
              {needsTrigger && (
                <div className="space-y-2">
                  <Label htmlFor="trade-trigger">Trigger price</Label>
                  <Input id="trade-trigger" type="number" min="0" step="0.05" value={triggerPrice} onChange={(event) => setTriggerPrice(event.target.value)} />
                </div>
              )}
              <div className="flex flex-wrap gap-2 pt-2 sm:col-span-2">
                <Button variant="outline" onClick={requestPreview} disabled={loading !== null || !symbol}>
                  {loading === "preview" && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Preview order
                </Button>
                <Button onClick={placeOrder} disabled={loading !== null || !preview}>
                  {loading === "place" && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Place sandbox order
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Connection</CardTitle>
                <CardDescription>Only the configured sandbox token is used here.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-center justify-between"><span className="text-muted-foreground">Environment</span><Badge variant="outline">Upstox Sandbox</Badge></div>
                <div className="flex items-center justify-between"><span className="text-muted-foreground">Token</span><span>{status?.configured ? "Configured" : "Missing"}</span></div>
                <div className="flex items-center justify-between"><span className="text-muted-foreground">Live orders</span><span className="text-emerald-400">Disabled</span></div>
              </CardContent>
            </Card>

            {preview && (
              <Card>
                <CardHeader><CardTitle className="text-base">Order preview</CardTitle><CardDescription>{preview.message}</CardDescription></CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Instrument</span><span className="font-mono">{preview.instrumentToken}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Action</span><span>{preview.transactionType} {preview.quantity} × {preview.symbol}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Order</span><span>{preview.orderType} / {preview.product}</span></div>
                  {(preview.price > 0) && <div className="flex justify-between"><span className="text-muted-foreground">Price</span><span>{preview.price}</span></div>}
                  {preview.triggerPrice > 0 && <div className="flex justify-between"><span className="text-muted-foreground">Trigger</span><span>{preview.triggerPrice}</span></div>}
                </CardContent>
              </Card>
            )}

            {orderId && (
              <Card>
                <CardHeader><CardTitle className="text-base">Sandbox order</CardTitle><CardDescription className="font-mono">{orderId}</CardDescription></CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                  <Button variant="outline" onClick={refreshOrder} disabled={loading !== null}>
                    {loading === "refresh" && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Refresh status
                  </Button>
                  <Button variant="destructive" onClick={cancelOrder} disabled={loading !== null}>
                    {loading === "cancel" && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Cancel order
                  </Button>
                  {order !== null && <pre className="max-h-48 w-full overflow-auto rounded-md bg-muted p-3 text-xs">{JSON.stringify(order, null, 2)}</pre>}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}