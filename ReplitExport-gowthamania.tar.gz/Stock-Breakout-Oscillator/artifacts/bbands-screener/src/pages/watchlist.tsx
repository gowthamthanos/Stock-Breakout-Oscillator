import { useState } from 'react';
import { useGetWatchlist, useAddToWatchlist, useRemoveFromWatchlist, getGetWatchlistQueryKey } from '@workspace/api-client-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { Trash2, Plus, Activity, ExternalLink } from 'lucide-react';
import { Link } from 'wouter';
import { format } from 'date-fns';

export default function WatchlistPage() {
  const [symbolInput, setSymbolInput] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: watchlist = [], isLoading, error } = useGetWatchlist();
  const addMutation = useAddToWatchlist();
  const removeMutation = useRemoveFromWatchlist();

  const handleAdd = async () => {
    const symbol = symbolInput.trim().toUpperCase();
    if (!symbol) {
      toast({
        title: 'Invalid symbol',
        description: 'Please enter a valid stock symbol.',
        variant: 'destructive',
      });
      return;
    }

    addMutation.mutate(
      { data: { symbol } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetWatchlistQueryKey() });
          setSymbolInput('');
          toast({
            title: 'Symbol added',
            description: `${symbol} has been added to your watchlist.`,
          });
        },
        onError: () => {
          toast({
            title: 'Failed to add symbol',
            description: 'This symbol may already exist in your watchlist or is invalid.',
            variant: 'destructive',
          });
        },
      }
    );
  };

  const handleRemove = async (symbol: string) => {
    removeMutation.mutate(
      { symbol },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetWatchlistQueryKey() });
          toast({
            title: 'Symbol removed',
            description: `${symbol} has been removed from your watchlist.`,
          });
        },
        onError: () => {
          toast({
            title: 'Failed to remove symbol',
            description: 'Please try again.',
            variant: 'destructive',
          });
        },
      }
    );
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleAdd();
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 lg:px-6 py-6 space-y-6 max-w-4xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Watchlist</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Manage your tracked symbols for screening
            </p>
          </div>
          <Link href="/?preset=watchlist">
            <Button className="gap-2" data-testid="button-run-screener">
              <Activity className="h-4 w-4" />
              Run Screener
              <ExternalLink className="h-3.5 w-3.5" />
            </Button>
          </Link>
        </div>

        {/* Add Symbol */}
        <Card className="p-4">
          <div className="flex gap-2">
            <Input
              placeholder="Enter NSE symbol (e.g., RELIANCE or RELIANCE.NS)"
              value={symbolInput}
              onChange={(e) => setSymbolInput(e.target.value.toUpperCase())}
              onKeyDown={handleKeyDown}
              className="flex-1"
              data-testid="input-add-symbol"
            />
            <Button
              onClick={handleAdd}
              disabled={addMutation.isPending || !symbolInput.trim()}
              className="gap-2"
              data-testid="button-add-symbol"
            >
              <Plus className="h-4 w-4" />
              Add Symbol
            </Button>
          </div>
        </Card>

        {/* Watchlist */}
        <Card className="overflow-hidden">
          {error ? (
            <Alert variant="destructive" className="m-4">
              <AlertDescription>
                Failed to load watchlist. Please refresh the page.
              </AlertDescription>
            </Alert>
          ) : isLoading ? (
            <div className="p-4 space-y-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-16" />
              ))}
            </div>
          ) : watchlist.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground">
              <Activity className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p className="text-sm font-medium mb-1">Your watchlist is empty</p>
              <p className="text-xs">Add symbols above to start tracking them.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="text-left text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Symbol
                    </th>
                    <th className="text-left text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Name
                    </th>
                    <th className="text-left text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Added
                    </th>
                    <th className="text-right text-xs font-semibold text-muted-foreground p-3 uppercase tracking-wide">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {watchlist.map((entry) => (
                    <tr
                      key={entry.id}
                      className="border-b hover-elevate transition-colors"
                      data-testid={`row-watchlist-${entry.symbol}`}
                    >
                      <td className="p-3">
                        <span className="font-bold font-mono text-sm" data-testid={`text-symbol-${entry.symbol}`}>
                          {entry.symbol}
                        </span>
                      </td>
                      <td className="p-3">
                        <span className="text-sm text-muted-foreground">{entry.name}</span>
                      </td>
                      <td className="p-3">
                        <span className="text-sm text-muted-foreground">
                          {format(new Date(entry.addedAt), 'MMM d, yyyy')}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemove(entry.symbol)}
                          disabled={removeMutation.isPending}
                          className="gap-2 text-destructive hover:text-destructive"
                          data-testid={`button-remove-${entry.symbol}`}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          Remove
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        {watchlist.length > 0 && (
          <p className="text-xs text-muted-foreground text-center">
            {watchlist.length} {watchlist.length === 1 ? 'symbol' : 'symbols'} in watchlist
          </p>
        )}
      </div>
    </div>
  );
}
