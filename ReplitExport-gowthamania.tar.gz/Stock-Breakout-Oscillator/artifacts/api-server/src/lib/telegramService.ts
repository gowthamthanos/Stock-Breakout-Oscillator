import { randomBytes } from "node:crypto";
import { and, eq, gt, isNull } from "drizzle-orm";
import {
  db,
  pool,
  telegramLinkCodesTable,
  telegramPollingStateTable,
  userTelegramChatsTable,
} from "@workspace/db";
import { logger } from "./logger";

export interface TelegramStatus {
  configured: boolean;
  connected: boolean;
  botName?: string;
  botUsername?: string;
  chatLabel?: string;
}

export interface TelegramAlertInput {
  symbol: string;
  alertLabel: string;
  direction: "bullish" | "bearish";
  eventType: "started" | "changed" | "ended";
  signal: string;
  oscillatorValue: number;
  interval: string;
  period: number;
  stdDev: number;
  breakoutAt: string | Date | null;
  breakoutStartAt: string | Date | null;
  breakoutEndAt: string | Date | null;
}

interface TelegramChat {
  id: number;
  type: string;
  title?: string;
  username?: string;
  first_name?: string;
}

interface TelegramBot {
  first_name: string;
  username?: string;
}

interface TelegramUpdate {
  update_id: number;
  message?: {
    text?: string;
    chat?: TelegramChat;
  };
}

interface TelegramApiResponse<T> {
  ok?: boolean;
  result?: T;
  description?: string;
}

export class TelegramError extends Error {
  constructor(
    message: string,
    public readonly kind: "not_configured" | "chat_not_found" | "api_error",
  ) {
    super(message);
    this.name = "TelegramError";
  }
}

let telegramSendQueue: Promise<void> = Promise.resolve();
let pollingTimer: NodeJS.Timeout | undefined;
let pollingInProgress = false;
const TELEGRAM_POLL_LOCK_ID = 581_204_731;

function getToken(): string | undefined {
  return process.env.TELEGRAM_BOT_TOKEN?.trim() || undefined;
}

async function telegramApi<T>(
  method: string,
  body?: Record<string, unknown>,
): Promise<T> {
  const token = getToken();
  if (!token) {
    throw new TelegramError("Telegram bot is not configured.", "not_configured");
  }

  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body ?? {}),
    signal: AbortSignal.timeout(8_000),
  });
  const payload = (await response.json()) as TelegramApiResponse<T>;
  if (!response.ok || !payload.ok || payload.result === undefined) {
    throw new TelegramError(
      payload.description ?? "Telegram rejected the request.",
      "api_error",
    );
  }
  return payload.result;
}

function labelForChat(chat: TelegramChat): string {
  if (chat.username) return `@${chat.username}`;
  if (chat.title) return chat.title;
  if (chat.first_name) return chat.first_name;
  return "Telegram chat";
}

async function getUserChat(userId: string) {
  const [chat] = await db
    .select()
    .from(userTelegramChatsTable)
    .where(eq(userTelegramChatsTable.userId, userId))
    .limit(1);
  return chat;
}

async function sendTextToChat(chatId: string, text: string): Promise<void> {
  const send = telegramSendQueue.then(async () => {
    await telegramApi("sendMessage", { chat_id: chatId, text });
  });
  telegramSendQueue = send.catch(() => undefined);
  await send;
}

export async function getTelegramStatus(userId: string): Promise<TelegramStatus> {
  if (!getToken()) return { configured: false, connected: false };

  const [bot, chat] = await Promise.all([
    telegramApi<TelegramBot>("getMe"),
    getUserChat(userId),
  ]);
  return {
    configured: true,
    connected: Boolean(chat),
    botName: bot.first_name,
    botUsername: bot.username,
    chatLabel: chat?.chatLabel ?? undefined,
  };
}

export async function startTelegramLink(userId: string): Promise<{
  code: string;
  expiresAt: string;
  botUsername: string | null;
}> {
  const bot = await telegramApi<TelegramBot>("getMe");
  await db
    .delete(telegramLinkCodesTable)
    .where(
      and(
        eq(telegramLinkCodesTable.userId, userId),
        isNull(telegramLinkCodesTable.claimedAt),
      ),
    );

  const code = randomBytes(6).toString("hex").toUpperCase();
  const expiresAt = new Date(Date.now() + 10 * 60_000);
  await db.insert(telegramLinkCodesTable).values({
    code,
    userId,
    expiresAt,
  });

  return {
    code,
    expiresAt: expiresAt.toISOString(),
    botUsername: bot.username ?? null,
  };
}

export async function sendTelegramTest(userId: string): Promise<void> {
  const chat = await getUserChat(userId);
  if (!chat) {
    throw new TelegramError(
      "Link your Telegram chat before sending a test message.",
      "chat_not_found",
    );
  }
  await sendTextToChat(
    chat.chatId,
    "BBands BO Screener is connected. Closed-candle trend alerts will arrive here.",
  );
}

export async function sendTelegramAlert(
  userId: string,
  input: TelegramAlertInput,
): Promise<void> {
  const chat = await getUserChat(userId);
  if (!chat) {
    throw new TelegramError(
      "Link your Telegram chat before enabling Telegram alerts.",
      "chat_not_found",
    );
  }

  const lineColor = input.direction === "bullish" ? "Green" : "Red";
  const direction = input.direction;
  const eventDescription = input.eventType === "changed"
    ? `Trend changed: ${lineColor} line appeared (${direction})`
    : `${lineColor} line appeared (${direction} trend)`;
  const formatTime = (value: string | Date | null): string =>
    value
      ? new Intl.DateTimeFormat("en-IN", {
          dateStyle: "medium",
          timeStyle: "short",
          timeZone: "Asia/Kolkata",
        }).format(new Date(value))
      : "Unavailable";
  const breakoutStart = formatTime(input.breakoutStartAt ?? input.breakoutAt);
  const text = [
    `BBands BO alert: ${input.symbol}`,
    eventDescription,
    input.alertLabel,
    `Oscillator: ${input.oscillatorValue.toFixed(3)}`,
    `Timeframe: ${input.interval}`,
    `BBands settings: period ${input.period}, deviation ${input.stdDev}`,
    `Line time: ${breakoutStart} IST`,
  ].join("\n");

  await sendTextToChat(chat.chatId, text);
}

async function processLinkCommand(update: TelegramUpdate): Promise<void> {
  const message = update.message;
  const chat = message?.chat;
  const text = message?.text?.trim();
  if (!chat || !text) return;

  if (/^\/start(?:@\w+)?(?:\s|$)/i.test(text)) {
    await sendTextToChat(
      String(chat.id),
      "To link this chat, generate a code in BBands BO Alerts and send /link YOUR_CODE here.",
    );
    return;
  }

  const match = text.match(/^\/link(?:@\w+)?\s+([a-f0-9]{12})$/i);
  if (!match) return;

  const now = new Date();
  const code = match[1]!.toUpperCase();
  const [link] = await db
    .select()
    .from(telegramLinkCodesTable)
    .where(
      and(
        eq(telegramLinkCodesTable.code, code),
        isNull(telegramLinkCodesTable.claimedAt),
        gt(telegramLinkCodesTable.expiresAt, now),
      ),
    )
    .limit(1);

  if (!link) {
    await sendTextToChat(
      String(chat.id),
      "That linking code is invalid or expired. Generate a new code in BBands BO Alerts.",
    );
    return;
  }

  await db.transaction(async (tx) => {
    const [claimed] = await tx
      .update(telegramLinkCodesTable)
      .set({ claimedAt: now })
      .where(
        and(
          eq(telegramLinkCodesTable.code, code),
          isNull(telegramLinkCodesTable.claimedAt),
          gt(telegramLinkCodesTable.expiresAt, now),
        ),
      )
      .returning();
    if (!claimed) return;

    await tx
      .insert(userTelegramChatsTable)
      .values({
        userId: link.userId,
        chatId: String(chat.id),
        chatLabel: labelForChat(chat),
        username: chat.username ?? null,
        linkedAt: now,
      })
      .onConflictDoUpdate({
        target: userTelegramChatsTable.userId,
        set: {
          chatId: String(chat.id),
          chatLabel: labelForChat(chat),
          username: chat.username ?? null,
          linkedAt: now,
        },
      });
  });

  await sendTextToChat(
    String(chat.id),
    "Telegram is linked to your BBands BO account. Your private trend alerts will arrive here.",
  );
}

async function pollUpdatesOnce(): Promise<void> {
  const client = await pool.connect();
  let hasLock = false;
  try {
    const lockResult = await client.query<{ locked: boolean }>(
      "SELECT pg_try_advisory_lock($1) AS locked",
      [TELEGRAM_POLL_LOCK_ID],
    );
    hasLock = lockResult.rows[0]?.locked === true;
    if (!hasLock) return;

    await db
      .insert(telegramPollingStateTable)
      .values({ id: 1, nextUpdateId: 0 })
      .onConflictDoNothing();
    const [state] = await db
      .select()
      .from(telegramPollingStateTable)
      .where(eq(telegramPollingStateTable.id, 1))
      .limit(1);

    const updates = await telegramApi<TelegramUpdate[]>("getUpdates", {
      offset: state?.nextUpdateId || undefined,
      limit: 100,
      timeout: 0,
      allowed_updates: ["message"],
    });
    for (const update of updates) {
      await processLinkCommand(update);
      await db
        .insert(telegramPollingStateTable)
        .values({ id: 1, nextUpdateId: update.update_id + 1 })
        .onConflictDoUpdate({
          target: telegramPollingStateTable.id,
          set: { nextUpdateId: update.update_id + 1 },
        });
    }
  } finally {
    if (hasLock) {
      try {
        await client.query("SELECT pg_advisory_unlock($1)", [
          TELEGRAM_POLL_LOCK_ID,
        ]);
      } catch (error) {
        logger.warn({ err: error }, "Could not release Telegram polling lock");
      }
    }
    client.release();
  }
}

export function startTelegramUpdatePolling(): void {
  if (pollingTimer || !getToken()) return;

  const poll = async () => {
    if (pollingInProgress) return;
    pollingInProgress = true;
    try {
      await pollUpdatesOnce();
    } catch (error) {
      logger.warn({ err: error }, "Telegram update polling failed");
    } finally {
      pollingInProgress = false;
    }
  };

  void poll();
  pollingTimer = setInterval(() => void poll(), 5_000);
  pollingTimer.unref();
  logger.info("Telegram account-link polling started");
}
