/**
 * Yahoo Finance data fetcher using yahoo-finance2 library.
 */
import YahooFinance from "yahoo-finance2";
import { logger } from "./logger";
import {
  exchangeDateKey,
  exchangeMonthKey,
  exchangeWeekKey,
  isCandleClosed,
} from "./candleCompletion";

const yahooFinance = new YahooFinance({ suppressNotices: ["yahooSurvey"] });

export interface QuoteData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  avgVolume: number | null;
  marketCap: number | null;
  closes: number[];
  timestamps: string[];
}

interface QuoteMetadata {
  shortName?: string;
  longName?: string;
  regularMarketVolume?: number;
  averageDailyVolume3Month?: number;
  marketCap?: number;
  regularMarketPrice?: number;
  regularMarketTime?: Date | string | number;
}

/** Intervals supported by the screener */
export type YInterval = "5m" | "15m" | "1h" | "1d" | "1wk" | "1mo";

/** Valid Yahoo Finance chart intervals */
type YFChartInterval = "5m" | "15m" | "1h" | "1d" | "1wk" | "1mo";

/** Map our interval IDs directly to Yahoo Finance chart intervals */
const YF_INTERVAL_MAP: Record<YInterval, YFChartInterval> = {
  "5m":  "5m",
  "15m": "15m",
  "1h":  "1h",
  "1d":  "1d",
  "1wk": "1wk",
  "1mo": "1mo",
};

/**
 * How many days of history to fetch per interval for at least `2*period+10` bars.
 * Yahoo Finance limits intraday history:
 *   5m  → max 60 days  (but only last ~7 days reliably)
 *   15m → max 60 days
 *   1h  → max 730 days
 *   1d/1wk/1mo → unlimited
 */
function daysBack(interval: YInterval, period: number): number {
  // BBands BO needs one band window for each of its period rolling excursion
  // values, plus a small buffer for establishing the active trend.
  const barsNeeded = period * 2 + 10;
  switch (interval) {
    // Use the full reliable intraday window so weekends and holidays do not
    // leave the 5-minute calculation with too few candles.
    case "5m":  return 7;                                          // ~78 bars/day
    // Yahoo supports up to 60 days for 15-minute candles; use the full window
    // so the current latched trend is more likely to include its color change.
    case "15m": return 60;                                         // ~26 bars/day
    // Use a year of hourly data to cover longer-lived trends.
    case "1h":  return 365;                                        // ~6.5 bars/day
    // A trend can persist well beyond the calculation warm-up window. Fetch a
    // multi-year buffer so the last green/red transition can be located.
    case "1d":  return Math.max(365 * 5, barsNeeded * 2);           // calendar days
    case "1wk": return Math.max(365 * 10, barsNeeded * 14);         // weeks → days
    case "1mo": return Math.max(365 * 30, barsNeeded * 60);          // months → days
  }
}

function timestampMs(value: Date | string | number | undefined): number | undefined {
  if (value === undefined) return undefined;
  if (value instanceof Date) {
    const time = value.getTime();
    return Number.isFinite(time) ? time : undefined;
  }
  if (typeof value === "number") {
    const milliseconds = value < 1_000_000_000_000 ? value * 1000 : value;
    return Number.isFinite(milliseconds) ? milliseconds : undefined;
  }
  const time = Date.parse(value);
  return Number.isFinite(time) ? time : undefined;
}

function isCurrentChartPeriod(
  latestCandleTime: number,
  marketTime: number,
  interval: YInterval,
): boolean {
  if (interval === "1d") {
    return exchangeDateKey(latestCandleTime) === exchangeDateKey(marketTime);
  }
  if (interval === "1wk") {
    return exchangeWeekKey(latestCandleTime) === exchangeWeekKey(marketTime);
  }
  if (interval === "1mo") {
    return exchangeMonthKey(latestCandleTime) === exchangeMonthKey(marketTime);
  }

  const intervalMs: Record<"5m" | "15m" | "1h", number> = {
    "5m": 5 * 60 * 1000,
    "15m": 15 * 60 * 1000,
    "1h": 60 * 60 * 1000,
  };
  return marketTime - latestCandleTime <= intervalMs[interval] + 60 * 1000;
}

function intradayCandleStart(
  marketTime: number,
  interval: "5m" | "15m" | "1h",
): number | null {
  const intervalMs: Record<"5m" | "15m" | "1h", number> = {
    "5m": 5 * 60 * 1000,
    "15m": 15 * 60 * 1000,
    "1h": 60 * 60 * 1000,
  };
  const indiaOffsetMs = 5.5 * 60 * 60 * 1000;
  const localTime = marketTime + indiaOffsetMs;
  const localMidnight = Math.floor(localTime / (24 * 60 * 60 * 1000)) *
    24 * 60 * 60 * 1000;
  const sessionOpen = localMidnight + (9 * 60 + 15) * 60 * 1000;
  if (localTime < sessionOpen) return null;

  const bucket = Math.floor(
    (localTime - sessionOpen) / intervalMs[interval],
  );
  return sessionOpen + bucket * intervalMs[interval] - indiaOffsetMs;
}

/**
 * Fetch recent closing prices for a symbol.
 * Returns null if the symbol is invalid / data unavailable.
 */
export async function fetchQuote(
  symbol: string,
  period: number,
  interval: YInterval = "1d",
  metadata?: QuoteMetadata,
  closedCandlesOnly = false,
): Promise<QuoteData | null> {
  const startDate = new Date(Date.now() - daysBack(interval, period) * 24 * 60 * 60 * 1000);

  try {
    const chartResult = await fetchChartWithRetry(symbol, startDate, interval);

    const quotes = chartResult?.quotes ?? [];
    if (quotes.length < 2) return null;

    const latestRawQuote = quotes[quotes.length - 1] as { volume?: number | null };
    const candles = quotes
      .map((q) => {
        const candle = q as { close?: number | null; date?: Date | string };
        const close = candle.close ?? null;
        if (close === null || !isFinite(close) || candle.date === undefined) return null;
        return {
          close,
          timestamp: new Date(candle.date).toISOString(),
        };
      })
      .filter((c): c is { close: number; timestamp: string } => c !== null);
    if (
      closedCandlesOnly &&
      candles.length > 0 &&
      !isCandleClosed(candles[candles.length - 1].timestamp, interval)
    ) {
      candles.pop();
    }
    const closes = candles.map((candle) => candle.close);
    const timestamps = candles.map((candle) => candle.timestamp);

    if (closes.length < period) return null;

    const latestCandleTime = timestampMs(timestamps[timestamps.length - 1]);
    const marketTime = timestampMs(metadata?.regularMarketTime);
    const marketPrice = metadata?.regularMarketPrice;
    const hasFreshMarketPrice =
      marketPrice !== undefined &&
      Number.isFinite(marketPrice) &&
      (marketTime === undefined ||
        latestCandleTime === undefined ||
        marketTime >= latestCandleTime - 60 * 1000);

    // Merge the live price only into its actual candle bucket. Never append a
    // quote several bars after Yahoo's latest candle: that invents a timestamp
    // and can make a breakout appear hours later than its source candle.
    if (
      !closedCandlesOnly &&
      hasFreshMarketPrice &&
      marketTime !== undefined &&
      latestCandleTime !== undefined
    ) {
      if (interval === "5m" || interval === "15m" || interval === "1h") {
        const currentCandleStart = intradayCandleStart(marketTime, interval);
        const intervalMs = interval === "5m"
          ? 5 * 60 * 1000
          : interval === "15m"
            ? 15 * 60 * 1000
            : 60 * 60 * 1000;

        if (currentCandleStart === latestCandleTime) {
          closes[closes.length - 1] = marketPrice;
        } else if (
          currentCandleStart !== null &&
          currentCandleStart > latestCandleTime &&
          currentCandleStart - latestCandleTime <= intervalMs
        ) {
          closes.push(marketPrice);
          timestamps.push(new Date(currentCandleStart).toISOString());
        }
      } else if (isCurrentChartPeriod(latestCandleTime, marketTime, interval)) {
        closes[closes.length - 1] = marketPrice;
      }
    }

    if (closes.length === 0) return null;
    const latestClose =
      !closedCandlesOnly && hasFreshMarketPrice
        ? marketPrice
        : closes[closes.length - 1];
    const prevClose = closes[closes.length - 2];
    const change = latestClose - prevClose;
    const changePercent = prevClose !== 0 ? (change / prevClose) * 100 : 0;

    const name = metadata?.shortName ?? metadata?.longName ?? symbol;

    const volume = metadata?.regularMarketVolume ?? latestRawQuote.volume ?? 0;
    const avgVolume = metadata?.averageDailyVolume3Month ?? null;
    const marketCap = metadata?.marketCap ?? null;

    return {
      symbol: symbol.toUpperCase(),
      name,
      price: Math.round(latestClose * 100) / 100,
      change: Math.round(change * 100) / 100,
      changePercent: Math.round(changePercent * 100) / 100,
      volume,
      avgVolume,
      marketCap,
      closes,
      timestamps,
    };
  } catch (err) {
    logger.warn({ symbol, err }, "Failed to fetch quote");
    return null;
  }
}

async function fetchChartWithRetry(
  symbol: string,
  startDate: Date,
  interval: YInterval,
): Promise<{ quotes?: Array<{ close?: number | null; date?: Date | string; volume?: number | null }> }> {
  let lastError: unknown;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      return await yahooFinance.chart(symbol, {
        period1: startDate,
        interval: YF_INTERVAL_MAP[interval],
      });
    } catch (err) {
      lastError = err;
      const message = err instanceof Error ? err.message : String(err);
      const code = (err as { code?: number | string }).code;
      const rateLimited = code === 429 || message.includes("Too Many Requests");
      if (!rateLimited || attempt === 2) throw err;
      await new Promise((resolve) => setTimeout(resolve, 700 * (attempt + 1)));
    }
  }
  throw lastError;
}

async function fetchQuoteMetadata(symbols: string[]): Promise<Map<string, QuoteMetadata>> {
  const metadata = new Map<string, QuoteMetadata>();

  // Quote accepts arrays, so avoid one metadata request per stock.
  for (let i = 0; i < symbols.length; i += 50) {
    const batch = symbols.slice(i, i + 50);
    try {
      const quotes = (await yahooFinance.quote(batch, {}, { validateResult: false })) as Array<
        QuoteMetadata & { symbol?: string }
      >;
      for (const quote of quotes) {
        if (quote.symbol) metadata.set(quote.symbol.toUpperCase(), quote);
      }
    } catch (err) {
      logger.warn({ err, symbols: batch }, "Failed to fetch quote metadata; using chart data");
    }
  }

  return metadata;
}

const quoteCache = new Map<string, { expiresAt: number; value: QuoteData[] }>();
const quoteRequests = new Map<string, Promise<QuoteData[]>>();
const QUOTE_CACHE_TTL_MS = 30_000;

async function fetchQuotesUncached(
  symbols: string[],
  period: number,
  interval: YInterval,
  concurrency: number,
  closedCandlesOnly: boolean,
): Promise<QuoteData[]> {
  const metadata = await fetchQuoteMetadata(symbols);
  const results: QuoteData[] = [];

  for (let i = 0; i < symbols.length; i += concurrency) {
    const batch = symbols.slice(i, i + concurrency);
    const fetched = await Promise.all(
      batch.map((symbol) =>
        fetchQuote(symbol, period, interval, metadata.get(symbol), closedCandlesOnly),
      ),
    );
    for (const quote of fetched) {
      if (quote) results.push(quote);
    }
  }

  return results;
}

/**
 * Fetch quotes for multiple symbols with request sharing and a short cache.
 * The scan and summary endpoints request the same basket together; sharing the
 * in-flight promise prevents two full Yahoo scans from running at once.
 */
export async function fetchQuotes(
  symbols: string[],
  period: number,
  interval: YInterval = "1d",
  concurrency = 3,
  closedCandlesOnly = false,
): Promise<QuoteData[]> {
  const uniqueSymbols = [...new Set(symbols)];
  const cacheKey = `${interval}:${period}:${closedCandlesOnly ? "closed" : "live"}:${uniqueSymbols.join(",")}`;
  const cached = quoteCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return cached.value;

  const pending = quoteRequests.get(cacheKey);
  if (pending) return pending;

  const request = fetchQuotesUncached(
    uniqueSymbols,
    period,
    interval,
    concurrency,
    closedCandlesOnly,
  )
    .then((value) => {
      quoteCache.set(cacheKey, {
        value,
        expiresAt: Date.now() + QUOTE_CACHE_TTL_MS,
      });
      return value;
    })
    .finally(() => {
      quoteRequests.delete(cacheKey);
    });

  quoteRequests.set(cacheKey, request);
  return request;
}
