import { randomUUID } from "node:crypto";
import { and, eq, isNull } from "drizzle-orm";
import {
  alertEventsTable,
  alertMonitorsTable,
  db,
  pool,
  type AlertTrend,
} from "@workspace/db";
import { calcBBandsBO } from "./bbands";
import { fetchQuotes, type YInterval } from "./yahooFinance";
import { resolveAlertSymbols } from "./symbols";
import { classifyTrendTransition } from "./alertTransition";
import { sendTelegramAlert } from "./telegramService";
import { logger } from "./logger";

const MONITOR_LOCK_ID = 581_204_730;
const MONITOR_INTERVAL_MS = 60_000;
const MAX_SYMBOLS_PER_ALERT = 100;

let monitorTimer: NodeJS.Timeout | undefined;
let monitorInProgress = false;

interface AlertEventMessage {
  id: string;
  alertId: string;
  alertLabel: string;
  symbol: string;
  direction: "bullish" | "bearish";
  eventType: "started" | "changed" | "ended";
  signal: string;
  oscillatorValue: number;
  interval: string;
  period: number;
  stdDev: number;
  breakoutAt: string | null;
  breakoutStartAt: string | null;
  breakoutEndAt: string | null;
  telegramStatus: "pending" | "sent" | "failed" | null;
}

function toDateOrNull(value: string | Date | null | undefined): Date | null {
  if (!value) return null;
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function alertEventToTelegramInput(event: AlertEventMessage) {
  return {
    symbol: event.symbol,
    alertLabel: event.alertLabel,
    direction: event.direction,
    eventType: event.eventType,
    signal: event.signal,
    oscillatorValue: event.oscillatorValue,
    interval: event.interval,
    period: event.period,
    stdDev: event.stdDev,
    breakoutAt: event.breakoutAt,
    breakoutStartAt: event.breakoutStartAt,
    breakoutEndAt: event.breakoutEndAt,
  };
}

async function deliverPendingEvent(
  event: AlertEventMessage,
  userId: string,
): Promise<void> {
  try {
    await sendTelegramAlert(userId, alertEventToTelegramInput(event));
    await db
      .update(alertEventsTable)
      .set({ telegramStatus: "sent", telegramError: null })
      .where(
        and(
          eq(alertEventsTable.id, event.id),
          eq(alertEventsTable.userId, userId),
        ),
      );
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Telegram delivery failed.";
    await db
      .update(alertEventsTable)
      .set({ telegramStatus: "failed", telegramError: message })
      .where(
        and(
          eq(alertEventsTable.id, event.id),
          eq(alertEventsTable.userId, userId),
        ),
      );
    logger.warn(
      { err: error, alertId: event.alertId, eventId: event.id },
      "Telegram alert delivery failed",
    );
  }
}

async function scanAlert(alert: typeof alertMonitorsTable.$inferSelect): Promise<void> {
  const scannedAt = new Date();
  let symbols: string[];
  try {
    symbols = await resolveAlertSymbols({
      symbol: alert.symbol,
      preset: alert.preset,
    });
    if (symbols.length > MAX_SYMBOLS_PER_ALERT) {
      throw new Error(
        `This category now contains ${symbols.length} symbols; alert monitors support up to ${MAX_SYMBOLS_PER_ALERT}.`,
      );
    }
  } catch (error) {
    await db
      .update(alertMonitorsTable)
      .set({
        lastScanAt: scannedAt,
        lastScanError: error instanceof Error ? error.message : "Invalid alert scope.",
      })
      .where(eq(alertMonitorsTable.id, alert.id));
    return;
  }

  try {
    const quotes = await fetchQuotes(
      symbols,
      alert.period,
      alert.interval as YInterval,
      3,
      true,
    );
    if (quotes.length === 0) {
      await db
        .update(alertMonitorsTable)
        .set({
          lastScanAt: scannedAt,
          lastScanError: "No closed-candle market data was returned.",
        })
        .where(eq(alertMonitorsTable.id, alert.id));
      return;
    }

    const missingSymbols = symbols.filter(
      (symbol) => !quotes.some((quote) => quote.symbol === symbol),
    );
    const nextTrends: Record<string, AlertTrend> = {
      ...(alert.trendStates ?? {}),
    };
    const transitions: Array<{
      symbol: string;
      previous: AlertTrend;
      current: Exclude<AlertTrend, null>;
      eventType: "started" | "changed";
      oscillatorValue: number;
      signal: string;
      breakoutAt: Date | null;
      breakoutStartAt: Date | null;
      breakoutEndAt: Date | null;
    }> = [];

    for (const quote of quotes) {
      const result = calcBBandsBO(
        quote.closes,
        alert.period,
        alert.stdDev,
        quote.timestamps,
        "close",
      );
      if (!result) continue;

      const hasPrevious = Object.prototype.hasOwnProperty.call(
        nextTrends,
        quote.symbol,
      );
      const previous = nextTrends[quote.symbol] ?? null;
      const current = result.trend as AlertTrend;

      // First observation is a baseline only. It must not send an alert for
      // a trend that was already active before this monitor was created.
      if (!hasPrevious) {
        nextTrends[quote.symbol] = current;
        continue;
      }

      // A missing colored line is not a state change. Keep the last green/red
      // state until the opposite line is actually confirmed by a closed candle.
      const eventType = classifyTrendTransition(previous, current);
      if (!eventType) continue;

      nextTrends[quote.symbol] = current;
      transitions.push({
        symbol: quote.symbol,
        previous,
        current,
        eventType,
        oscillatorValue: result.oscillatorValue,
        signal: `${current}_breakout`,
        breakoutAt: toDateOrNull(result.breakoutAt),
        breakoutStartAt: toDateOrNull(result.breakoutStartAt ?? result.breakoutAt),
        breakoutEndAt: toDateOrNull(result.breakoutEndAt),
      });
    }

    const emittedEvents: AlertEventMessage[] = [];
    const eventCreatedAt = new Date();
    await db.transaction(async (tx) => {
      for (const transition of transitions) {
        if (transition.previous) {
          await tx
            .update(alertEventsTable)
            .set({
              breakoutEndAt: transition.breakoutStartAt ?? eventCreatedAt,
            })
            .where(
              and(
                eq(alertEventsTable.alertId, alert.id),
                eq(alertEventsTable.userId, alert.userId),
                eq(alertEventsTable.symbol, transition.symbol),
                eq(alertEventsTable.direction, transition.previous),
                isNull(alertEventsTable.breakoutEndAt),
              ),
            );
        }

        const directionMatches =
          alert.direction === "both" || alert.direction === transition.current;
        if (!directionMatches) continue;

        const event = {
          id: randomUUID(),
          userId: alert.userId,
          alertId: alert.id,
          alertLabel: alert.label,
          symbol: transition.symbol,
          direction: transition.current,
          eventType: transition.eventType,
          signal: transition.signal,
          oscillatorValue: transition.oscillatorValue,
          interval: alert.interval,
          period: alert.period,
          stdDev: alert.stdDev,
          breakoutAt: transition.breakoutAt,
          breakoutStartAt: transition.breakoutStartAt,
          breakoutEndAt: null,
          telegramStatus: alert.telegramEnabled ? "pending" : null,
          telegramError: null,
          createdAt: eventCreatedAt,
        } satisfies typeof alertEventsTable.$inferInsert;

        const [inserted] = await tx
          .insert(alertEventsTable)
          .values(event)
          .returning();
        if (!inserted) continue;
        emittedEvents.push({
          id: inserted.id,
          alertId: inserted.alertId,
          alertLabel: inserted.alertLabel,
          symbol: inserted.symbol,
          direction: inserted.direction as "bullish" | "bearish",
          eventType: inserted.eventType as "started" | "changed" | "ended",
          signal: inserted.signal,
          oscillatorValue: inserted.oscillatorValue,
          interval: inserted.interval,
          period: inserted.period,
          stdDev: inserted.stdDev,
          breakoutAt: inserted.breakoutAt?.toISOString() ?? null,
          breakoutStartAt: inserted.breakoutStartAt?.toISOString() ?? null,
          breakoutEndAt: inserted.breakoutEndAt?.toISOString() ?? null,
          telegramStatus: inserted.telegramStatus as
            | "pending"
            | "sent"
            | "failed"
            | null,
        });
      }

      const lastTriggered = emittedEvents[0];
      await tx
        .update(alertMonitorsTable)
        .set({
          trendStates: nextTrends,
          lastScanAt: scannedAt,
          lastScanError: missingSymbols.length
            ? `Market data unavailable for ${missingSymbols.length} of ${symbols.length} symbols.`
            : null,
          ...(lastTriggered
            ? {
                lastTriggeredAt: eventCreatedAt,
                lastTriggeredSymbol: lastTriggered.symbol,
                lastTriggeredOscillator: lastTriggered.oscillatorValue,
              }
            : {}),
        })
        .where(eq(alertMonitorsTable.id, alert.id));
    });

    for (const event of emittedEvents) {
      if (event.telegramStatus === "pending") {
        await deliverPendingEvent(event, alert.userId);
      }
    }
  } catch (error) {
    logger.warn(
      { err: error, alertId: alert.id, interval: alert.interval },
      "Alert monitor scan failed",
    );
    await db
      .update(alertMonitorsTable)
      .set({
        lastScanAt: scannedAt,
        lastScanError:
          error instanceof Error ? error.message : "Market data scan failed.",
      })
      .where(eq(alertMonitorsTable.id, alert.id));
  }
}

async function runMonitorCycle(): Promise<void> {
  const client = await pool.connect();
  let hasLock = false;
  try {
    const lockResult = await client.query<{ locked: boolean }>(
      "SELECT pg_try_advisory_lock($1) AS locked",
      [MONITOR_LOCK_ID],
    );
    hasLock = lockResult.rows[0]?.locked === true;
    if (!hasLock) return;

    const alerts = await db
      .select()
      .from(alertMonitorsTable)
      .where(
        and(
          eq(alertMonitorsTable.enabled, true),
          isNull(alertMonitorsTable.deletedAt),
        ),
      );

    for (const alert of alerts) {
      await scanAlert(alert);
    }
  } finally {
    if (hasLock) {
      try {
        await client.query("SELECT pg_advisory_unlock($1)", [MONITOR_LOCK_ID]);
      } catch (error) {
        logger.warn({ err: error }, "Could not release alert monitor lock");
      }
    }
    client.release();
  }
}

export function startAlertMonitor(): void {
  if (monitorTimer) return;

  const run = async () => {
    if (monitorInProgress) return;
    monitorInProgress = true;
    try {
      await runMonitorCycle();
    } catch (error) {
      logger.error({ err: error }, "Alert monitor cycle failed");
    } finally {
      monitorInProgress = false;
    }
  };

  void run();
  monitorTimer = setInterval(() => void run(), MONITOR_INTERVAL_MS);
  monitorTimer.unref();
  logger.info({ intervalMs: MONITOR_INTERVAL_MS }, "Server-side alert monitoring started");
}
