import { getPresetWithDynamicUniverse } from "./nseUniverse";

export function normalizeSymbol(input: string): string {
  const symbol = input.trim().toUpperCase();
  return symbol.startsWith("^") || symbol.endsWith(".NS") || symbol.endsWith(".BO")
    ? symbol
    : `${symbol}.NS`;
}

export async function resolveSymbols(
  rawSymbols?: string,
  preset?: string,
): Promise<string[]> {
  if (rawSymbols && rawSymbols.trim()) {
    return rawSymbols
      .split(",")
      .map(normalizeSymbol)
      .filter(Boolean)
      .slice(0, 100);
  }
  if (preset) {
    const resolvedPreset = await getPresetWithDynamicUniverse(preset);
    if (resolvedPreset) return resolvedPreset.symbols;
  }
  const fallback = await getPresetWithDynamicUniverse("nifty_50");
  if (!fallback) throw new Error("The default market universe is unavailable.");
  return fallback.symbols;
}

export async function resolveAlertSymbols(input: {
  symbol: string | null;
  preset: string | null;
}): Promise<string[]> {
  if (input.symbol) return [normalizeSymbol(input.symbol)];
  if (input.preset) {
    const resolvedPreset = await getPresetWithDynamicUniverse(input.preset);
    if (resolvedPreset) return resolvedPreset.symbols;
    throw new Error(`Unknown market category: ${input.preset}`);
  }
  throw new Error("Choose a stock symbol or a market category.");
}
