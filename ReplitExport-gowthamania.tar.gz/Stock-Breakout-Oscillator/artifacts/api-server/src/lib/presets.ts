/**
 * Built-in symbol list presets for the screener.
 * Indian stocks use Yahoo Finance .NS suffix (NSE).
 * Indian indices use ^ prefix Yahoo Finance tickers.
 */
export interface Preset {
  id: string;
  name: string;
  description: string;
  symbols: string[];
  group?: string; // optional grouping label
}

const INDIA_LARGE_CAP_SYMBOLS = [
  "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "BHARTIARTL.NS", "ICICIBANK.NS",
  "INFY.NS", "SBIN.NS", "HINDUNILVR.NS", "ITC.NS", "LT.NS",
  "BAJFINANCE.NS", "HCLTECH.NS", "KOTAKBANK.NS", "AXISBANK.NS", "MARUTI.NS",
  "SUNPHARMA.NS", "TITAN.NS", "ASIANPAINT.NS", "ULTRACEMCO.NS", "WIPRO.NS",
  "NTPC.NS", "POWERGRID.NS", "ADANIENT.NS", "ADANIPORTS.NS", "BAJAJFINSV.NS",
  "TATAMOTORS.NS", "TATASTEEL.NS", "JSWSTEEL.NS", "ONGC.NS", "COALINDIA.NS",
  "TECHM.NS", "M&M.NS", "NESTLEIND.NS", "CIPLA.NS", "DRREDDY.NS",
  "APOLLOHOSP.NS", "DIVISLAB.NS", "EICHERMOT.NS", "GRASIM.NS", "HINDALCO.NS",
  "INDUSINDBK.NS", "SBILIFE.NS", "HDFCLIFE.NS", "TATACONSUM.NS", "BPCL.NS",
  "HEROMOTOCO.NS", "BRITANNIA.NS", "UPL.NS", "SHREECEM.NS", "BAJAJ-AUTO.NS",
  "ADANIGREEN.NS", "AMBUJACEM.NS", "ATGL.NS", "AUROPHARMA.NS", "BERGEPAINT.NS",
  "BOSCHLTD.NS", "CANBK.NS", "CHOLAFIN.NS", "COLPAL.NS", "DABUR.NS",
  "DLF.NS", "DMART.NS", "GAIL.NS", "GODREJCP.NS", "GODREJPROP.NS",
  "HAVELLS.NS", "ICICIPRULI.NS", "INDUSTOWER.NS", "IRCTC.NS", "JINDALSTEL.NS",
  "LICI.NS", "LUPIN.NS", "MARICO.NS", "MAXHEALTH.NS", "MCDOWELL-N.NS",
  "MUTHOOTFIN.NS", "NAUKRI.NS", "OBEROIRLTY.NS", "OFSS.NS", "PAGEIND.NS",
  "PIDILITIND.NS", "PNB.NS", "POLYCAB.NS", "RECLTD.NS", "SAIL.NS",
  "SIEMENS.NS", "SRF.NS", "TORNTPHARM.NS", "TRENT.NS", "TVSMOTOR.NS",
  "UNIONBANK.NS", "VEDL.NS", "VOLTAS.NS", "ZOMATO.NS", "ZYDUSLIFE.NS",
  "BANKBARODA.NS", "FEDERALBNK.NS", "PHOENIXLTD.NS", "LTIM.NS", "PERSISTENT.NS",
];

const INDIA_FNO_SYMBOLS = [
  "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "ICICIBANK.NS", "BHARTIARTL.NS",
  "INFY.NS", "SBIN.NS", "ITC.NS", "HINDUNILVR.NS", "LT.NS",
  "BAJFINANCE.NS", "HCLTECH.NS", "KOTAKBANK.NS", "AXISBANK.NS", "MARUTI.NS",
  "SUNPHARMA.NS", "TITAN.NS", "ASIANPAINT.NS", "ULTRACEMCO.NS", "WIPRO.NS",
  "NTPC.NS", "POWERGRID.NS", "ADANIENT.NS", "ADANIPORTS.NS", "BAJAJFINSV.NS",
  "TATAMOTORS.NS", "TATASTEEL.NS", "JSWSTEEL.NS", "ONGC.NS", "COALINDIA.NS",
  "TECHM.NS", "M&M.NS", "NESTLEIND.NS", "CIPLA.NS", "DRREDDY.NS",
  "APOLLOHOSP.NS", "DIVISLAB.NS", "EICHERMOT.NS", "GRASIM.NS", "HINDALCO.NS",
  "INDUSINDBK.NS", "SBILIFE.NS", "HDFCLIFE.NS", "TATACONSUM.NS", "BPCL.NS",
  "HEROMOTOCO.NS", "BRITANNIA.NS", "UPL.NS", "SHREECEM.NS", "BAJAJ-AUTO.NS",
  "ADANIGREEN.NS", "AMBUJACEM.NS", "AUROPHARMA.NS", "BOSCHLTD.NS", "CANBK.NS",
  "CHOLAFIN.NS", "COLPAL.NS", "DABUR.NS", "DLF.NS", "DMART.NS",
  "GAIL.NS", "GODREJCP.NS", "HAVELLS.NS", "ICICIPRULI.NS", "INDUSTOWER.NS",
  "IRCTC.NS", "JINDALSTEL.NS", "LICI.NS", "LUPIN.NS", "MARICO.NS",
  "MUTHOOTFIN.NS", "NAUKRI.NS", "PAGEIND.NS", "PIDILITIND.NS", "PNB.NS",
  "POLYCAB.NS", "RECLTD.NS", "SAIL.NS", "SIEMENS.NS", "SRF.NS",
  "TORNTPHARM.NS", "TRENT.NS", "TVSMOTOR.NS", "UNIONBANK.NS", "VEDL.NS",
  "VOLTAS.NS", "ZYDUSLIFE.NS", "BANKBARODA.NS", "FEDERALBNK.NS", "LTIM.NS",
  "PERSISTENT.NS", "AUBANK.NS", "BANDHANBNK.NS", "IDFCFIRSTB.NS", "IRFC.NS",
  "REC.NS", "PFC.NS", "RVNL.NS", "SAIL.NS", "TATAPOWER.NS",
];

const INDIA_MID_CAP_SYMBOLS = [
  "ASHOKLEY.NS", "ASTRAL.NS", "AUROPHARMA.NS", "BHARATFORG.NS", "BHEL.NS",
  "BALKRISIND.NS", "BEL.NS", "BIOCON.NS", "BSE.NS", "CGPOWER.NS",
  "COFORGE.NS", "CONCOR.NS", "CUMMINSIND.NS", "DIXON.NS", "ESCORTS.NS",
  "EXIDEIND.NS", "FORTIS.NS", "GLENMARK.NS", "GMRINFRA.NS", "GUJGASLTD.NS",
  "HINDPETRO.NS", "IDBI.NS", "IDFCFIRSTB.NS", "INDHOTEL.NS", "INDIANB.NS",
  "INOXWIND.NS", "JINDALSTEL.NS", "JUBLFOOD.NS", "KPITTECH.NS", "LALPATHLAB.NS",
  "LAURUSLABS.NS", "LICHSGFIN.NS", "MANAPPURAM.NS", "MAXHEALTH.NS", "MCX.NS",
  "MOTHERSON.NS", "MRF.NS", "MPHASIS.NS", "NATIONALUM.NS", "NHPC.NS",
  "NMDC.NS", "OBEROIRLTY.NS", "OIL.NS", "PERSISTENT.NS", "PETRONET.NS",
  "PIIND.NS", "POLYCAB.NS", "PRESTIGE.NS", "SAIL.NS", "SJVN.NS",
  "SOLARINDS.NS", "SONACOMS.NS", "STARHEALTH.NS", "SUPREMEIND.NS", "TATAELXSI.NS",
  "TATACHEM.NS", "TATACOMM.NS", "TATATECH.NS", "THERMAX.NS", "TIMKEN.NS",
  "TORNTPOWER.NS", "TRIDENT.NS", "UPL.NS", "VBL.NS", "VOLTAS.NS",
  "WHIRLPOOL.NS", "YESBANK.NS", "ZEEL.NS", "ZENSARTECH.NS", "ABFRL.NS",
  "AFFLE.NS", "ANGELONE.NS", "BANDHANBNK.NS", "CANFINHOME.NS", "CAMS.NS",
  "CESC.NS", "CYIENT.NS", "DEEPAKNTR.NS", "DELHIVERY.NS", "ENDURANCE.NS",
  "FINEORG.NS", "GLAND.NS", "HAPPSTMNDS.NS", "INDIAMART.NS", "JBCHEPHARM.NS",
];

export const PRESETS: Preset[] = [
  // ── Indian Indices ───────────────────────────────────────────────
  {
    id: "india_indices",
    name: "Indian Indices",
    description: "Indian market indices with Yahoo Finance historical candle support",
    group: "India Indices",
    symbols: [
      "^NSEI",      // Nifty 50
      "^NSEBANK",   // Bank Nifty
      "^BSESN",     // Sensex
      "^CNXIT",     // Nifty IT
      "^CNXPHARMA", // Nifty Pharma
      "^NSEMDCP50", // Nifty Midcap 50
      "^CNX100",    // Nifty 100
    ],
  },

  // ── Indian Stocks ────────────────────────────────────────────────
  {
    id: "nifty_50",
    name: "Nifty 50",
    description: "All 50 stocks in the Nifty 50 index (NSE large-caps)",
    group: "India Stocks",
    symbols: [
      "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "BHARTIARTL.NS", "ICICIBANK.NS",
      "INFY.NS", "SBIN.NS", "HINDUNILVR.NS", "ITC.NS", "LT.NS",
      "BAJFINANCE.NS", "HCLTECH.NS", "KOTAKBANK.NS", "AXISBANK.NS", "MARUTI.NS",
      "SUNPHARMA.NS", "TITAN.NS", "ASIANPAINT.NS", "ULTRACEMCO.NS", "WIPRO.NS",
      "NTPC.NS", "POWERGRID.NS", "ADANIENT.NS", "ADANIPORTS.NS", "BAJAJFINSV.NS",
      "TATAMOTORS.NS", "TATASTEEL.NS", "JSWSTEEL.NS", "ONGC.NS", "COALINDIA.NS",
      "TECHM.NS", "M&M.NS", "NESTLEIND.NS", "CIPLA.NS", "DRREDDY.NS",
      "APOLLOHOSP.NS", "DIVISLAB.NS", "EICHERMOT.NS", "GRASIM.NS", "HINDALCO.NS",
      "INDUSINDBK.NS", "SBILIFE.NS", "HDFCLIFE.NS", "TATACONSUM.NS", "BPCL.NS",
      "HEROMOTOCO.NS", "BRITANNIA.NS", "UPL.NS", "SHREECEM.NS", "BAJAJ-AUTO.NS",
    ],
  },
  {
    id: "nifty_next50",
    name: "Nifty Next 50",
    description: "50 large-cap stocks just outside the Nifty 50",
    group: "India Stocks",
    symbols: [
      "ADANIGREEN.NS", "AMBUJACEM.NS", "ATGL.NS", "AUROPHARMA.NS", "BERGEPAINT.NS",
      "BOSCHLTD.NS", "CANBK.NS", "CHOLAFIN.NS", "COLPAL.NS", "DABUR.NS",
      "DLF.NS", "DMART.NS", "GAIL.NS", "GODREJCP.NS", "GODREJPROP.NS",
      "HAVELLS.NS", "ICICIPRULI.NS", "INDUSTOWER.NS", "IRCTC.NS", "JINDALSTEL.NS",
      "LICI.NS", "LUPIN.NS", "MARICO.NS", "MAXHEALTH.NS", "MCDOWELL-N.NS",
      "MUTHOOTFIN.NS", "NAUKRI.NS", "OBEROIRLTY.NS", "OFSS.NS", "PAGEIND.NS",
      "PIDILITIND.NS", "PNB.NS", "POLYCAB.NS", "RECLTD.NS", "SAIL.NS",
      "SIEMENS.NS", "SRF.NS", "TORNTPHARM.NS", "TRENT.NS", "TVSMOTOR.NS",
      "UNIONBANK.NS", "VEDL.NS", "VOLTAS.NS", "ZOMATO.NS", "ZYDUSLIFE.NS",
      "BANKBARODA.NS", "FEDERALBNK.NS", "PHOENIXLTD.NS", "LTIM.NS", "PERSISTENT.NS",
    ],
  },
  {
    id: "india_fno",
    name: "India F&O Stocks",
    description: "Curated NSE futures and options stock universe",
    group: "India F&O",
    symbols: INDIA_FNO_SYMBOLS,
  },
  {
    id: "india_large_cap",
    name: "Indian Large Cap",
    description: "Nifty 100 large-cap stocks",
    group: "India Market Cap",
    symbols: INDIA_LARGE_CAP_SYMBOLS,
  },
  {
    id: "india_mid_cap",
    name: "Indian Mid Cap",
    description: "Liquid Indian mid-cap stocks across major sectors",
    group: "India Market Cap",
    symbols: INDIA_MID_CAP_SYMBOLS,
  },
  {
    id: "nifty_bank",
    name: "Nifty Bank",
    description: "Nifty Bank index constituents — Indian banking stocks",
    group: "India Stocks",
    symbols: [
      "HDFCBANK.NS", "ICICIBANK.NS", "SBIN.NS", "KOTAKBANK.NS", "AXISBANK.NS",
      "INDUSINDBK.NS", "BANKBARODA.NS", "PNB.NS", "CANBK.NS", "FEDERALBNK.NS",
      "UNIONBANK.NS", "AUBANK.NS", "BANDHANBNK.NS", "IDFCFIRSTB.NS",
    ],
  },
  {
    id: "nifty_it",
    name: "Nifty IT",
    description: "Nifty IT index — top Indian information technology companies",
    group: "India Stocks",
    symbols: [
      "TCS.NS", "INFY.NS", "HCLTECH.NS", "WIPRO.NS", "TECHM.NS",
      "LTIM.NS", "MPHASIS.NS", "PERSISTENT.NS", "COFORGE.NS", "BSOFT.NS",
    ],
  },
  {
    id: "nifty_auto",
    name: "Nifty Auto",
    description: "Indian automobile and auto-components sector",
    group: "India Stocks",
    symbols: [
      "MARUTI.NS", "TATAMOTORS.NS", "M&M.NS", "BAJAJ-AUTO.NS", "HEROMOTOCO.NS",
      "EICHERMOT.NS", "TVSMOTOR.NS", "ASHOKLEY.NS", "MRF.NS", "BALKRISIND.NS",
      "BOSCHLTD.NS", "MOTHERSON.NS",
    ],
  },
  {
    id: "nifty_fmcg",
    name: "Nifty FMCG",
    description: "Fast-moving consumer goods sector stocks",
    group: "India Stocks",
    symbols: [
      "HINDUNILVR.NS", "ITC.NS", "NESTLEIND.NS", "BRITANNIA.NS", "DABUR.NS",
      "MARICO.NS", "COLPAL.NS", "GODREJCP.NS", "EMAMILTD.NS", "VBL.NS",
      "RADICO.NS", "TATACONSUM.NS",
    ],
  },
  {
    id: "nifty_pharma",
    name: "Nifty Pharma",
    description: "Indian pharmaceutical and healthcare companies",
    group: "India Stocks",
    symbols: [
      "SUNPHARMA.NS", "DRREDDY.NS", "CIPLA.NS", "DIVISLAB.NS", "APOLLOHOSP.NS",
      "LUPIN.NS", "AUROPHARMA.NS", "TORNTPHARM.NS", "ZYDUSLIFE.NS", "ALKEM.NS",
      "IPCALAB.NS", "MAXHEALTH.NS",
    ],
  },
  {
    id: "nifty_metal",
    name: "Nifty Metal",
    description: "Indian metals and mining sector",
    group: "India Stocks",
    symbols: [
      "TATASTEEL.NS", "JSWSTEEL.NS", "HINDALCO.NS", "VEDL.NS", "SAIL.NS",
      "JINDALSTEL.NS", "COALINDIA.NS", "NMDC.NS", "MOIL.NS", "NATIONALUM.NS",
    ],
  },
  {
    id: "nifty_realty",
    name: "Nifty Realty",
    description: "Indian real estate sector stocks",
    group: "India Stocks",
    symbols: [
      "DLF.NS", "GODREJPROP.NS", "OBEROIRLTY.NS", "PHOENIXLTD.NS", "PRESTIGE.NS",
      "SOBHA.NS", "MAHLIFE.NS", "BRIGADE.NS", "SUNTECK.NS", "KOLTEPATIL.NS",
    ],
  },
  {
    id: "nifty_energy",
    name: "Nifty Energy",
    description: "Indian energy and oil & gas companies",
    group: "India Stocks",
    symbols: [
      "RELIANCE.NS", "ONGC.NS", "NTPC.NS", "POWERGRID.NS", "BPCL.NS",
      "GAIL.NS", "ADANIGREEN.NS", "TATAPOWER.NS", "TORNTPOWER.NS", "ATGL.NS",
      "IOC.NS", "HINDPETRO.NS",
    ],
  },
  {
    id: "india_small_cap",
    name: "Indian Small Cap",
    description: "Liquid NSE small-cap stocks across multiple sectors",
    group: "India Market Cap",
    symbols: [
      "IRFC.NS", "RVNL.NS", "IREDA.NS", "HUDCO.NS", "NBCC.NS", "RITES.NS",
      "BSE.NS", "CDSL.NS", "MCX.NS", "KAYNES.NS", "DIXON.NS", "KFINTECH.NS",
      "ANGELONE.NS", "IEX.NS", "CAMS.NS", "TANLA.NS", "KALYANKJIL.NS",
      "SAPPHIRE.NS", "MAPMYINDIA.NS", "EASEMYTRIP.NS", "LATENTVIEW.NS",
      "RATEGAIN.NS", "KPI.NS", "TITAGARH.NS", "JWL.NS", "JAMNAAUTO.NS",
      "KPITTECH.NS", "CYIENT.NS", "ZENSARTECH.NS", "NEWGEN.NS", "INTELLECT.NS",
      "ECLERX.NS", "BSOFT.NS", "MASTEK.NS", "SURYAROSNI.NS", "KNRCON.NS",
      "PNCINFRA.NS", "GRINFRA.NS", "ENGINERSIN.NS", "GPPL.NS", "FINEORG.NS",
      "CLEAN.NS", "ANURAS.NS", "MEDANTA.NS", "RAINBOW.NS", "ETHOSLTD.NS",
      "JUBLPHARMA.NS", "GLAND.NS", "MARKSANS.NS", "SUZLON.NS", "INOXWIND.NS",
      "JAIBALAJI.NS", "HBLENGINE.NS", "KAYNES.NS", "APARINDS.NS", "WELCORP.NS",
      "KIRLOSBROS.NS", "GARFIBRES.NS", "ASTRAL.NS", "CERA.NS", "BORORENEW.NS",
    ],
  },
  {
    id: "india_recent_ipos",
    name: "Recent Indian IPOs",
    description: "Newly listed Indian IPO stocks and recent listings",
    group: "India Stocks",
    symbols: [
      "SWIGGY.NS", "HYUNDAI.NS", "NTPCGREEN.NS", "WAAREEENER.NS", "VMM.NS",
      "BLACKBUCK.NS", "ACMESOLAR.NS", "TARSONS.NS", "AWL.NS", "GODAWARI.NS",
      "AETHER.NS", "LATENTVIEW.NS", "ZOMATO.NS", "PAYTM.NS", "NYKAA.NS",
      "POLICYBZR.NS", "DELHIVERY.NS", "MAPMYINDIA.NS", "RATEGAIN.NS", "TBO.NS",
      "IDEAFORGE.NS", "MANKIND.NS", "JSWINFRA.NS", "UTIAMC.NS", "MOTILALOFS.NS",
      "HONASA.NS", "IKS.NS", "DOMS.NS", "CELLO.NS", "TATATECH.NS",
      "SULA.NS", "FUSION.NS", "NETWEB.NS", "YATHARTH.NS", "REDCONENT.NS",
      "JNKINDIA.NS", "GO_DIGIT.NS", "TRUST.NS", "FIRSTCRY.NS", "UNIMECH.NS",
      "VENTIVE.NS", "CARRARO.NS", "CONCORD.NS", "MOBIKWIK.NS", "VIKRAN.NS",
    ],
  },
  {
    id: "india_broad_market",
    name: "India Broad Market",
    description: "Broad liquid basket across large, mid, small-cap and recent IPO stocks",
    group: "India Stocks",
    symbols: [
      "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "BHARTIARTL.NS", "ICICIBANK.NS",
      "INFY.NS", "SBIN.NS", "HINDUNILVR.NS", "ITC.NS", "LT.NS", "BAJFINANCE.NS",
      "HCLTECH.NS", "KOTAKBANK.NS", "AXISBANK.NS", "MARUTI.NS", "SUNPHARMA.NS",
      "TITAN.NS", "NTPC.NS", "POWERGRID.NS", "ADANIENT.NS", "TATAMOTORS.NS",
      "TATASTEEL.NS", "JSWSTEEL.NS", "ONGC.NS", "COALINDIA.NS", "TECHM.NS",
      "M&M.NS", "CIPLA.NS", "APOLLOHOSP.NS", "DIVISLAB.NS", "IRFC.NS",
      "RVNL.NS", "IREDA.NS", "HUDCO.NS", "NBCC.NS", "BSE.NS", "CDSL.NS",
      "DIXON.NS", "KFINTECH.NS", "ANGELONE.NS", "IEX.NS", "CAMS.NS",
      "KPITTECH.NS", "CYIENT.NS", "TITAGARH.NS", "SUZLON.NS", "ASTRAL.NS",
      "SWIGGY.NS", "HYUNDAI.NS", "NTPCGREEN.NS", "WAAREEENER.NS", "VMM.NS",
      "BLACKBUCK.NS", "ACMESOLAR.NS", "ZOMATO.NS", "PAYTM.NS", "NYKAA.NS",
      "POLICYBZR.NS", "DELHIVERY.NS", "TATATECH.NS", "MANKIND.NS", "JSWINFRA.NS",
    ],
  },
];

export function getPreset(id: string): Preset | undefined {
  return PRESETS.find((p) => p.id === id);
}

/** Return presets grouped by their group label */
export function getPresetGroups(): Record<string, Preset[]> {
  const groups: Record<string, Preset[]> = {};
  for (const p of PRESETS) {
    const g = p.group ?? "Other";
    if (!groups[g]) groups[g] = [];
    groups[g].push(p);
  }
  return groups;
}
