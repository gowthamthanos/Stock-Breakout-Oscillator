/**
 * Bollinger Bands Breakout Oscillator (BBands BO).
 *
 * This is a TypeScript port of the public LuxAlgo Pine Script calculation:
 * https://www.tradingview.com/script/YaniRMVC-Bollinger-Bands-Breakout-Oscillator-LuxAlgo/
 * The source script is licensed CC BY-NC-SA 4.0 and is © LuxAlgo.
 */

export type BBandSignal =
  | "bullish_breakout"
  | "neutral"
  | "bearish_breakout";

export type BBandSource = "close";
export type BBandTrend = "bullish" | "bearish" | null;

export interface BBandResult {
  /** Signed difference between LuxAlgo's bullish and bearish series. */
  oscillatorValue: number;
  /** Kept for API compatibility; this now reflects the latched color trend. */
  signal: BBandSignal;
  /** Latched LuxAlgo color state: green until red, red until green. */
  trend: BBandTrend;
  upperBand: number;
  lowerBand: number;
  middleBand: number;
  breakoutAt: string | null;
  breakoutStartAt: string | null;
  breakoutEndAt: string | null;
}

interface BandsAt {
  middle: number;
  upper: number;
  lower: number;
}

const round = (value: number, decimals: number): number => {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
};

function mean(values: number[], endIndex: number, period: number): number {
  let sum = 0;
  for (let index = endIndex - period + 1; index <= endIndex; index += 1) {
    sum += values[index];
  }
  return sum / period;
}

/** Pine's ta.stdev() defaults to biased=true, i.e. population deviation. */
function populationStdDev(
  values: number[],
  endIndex: number,
  period: number,
): number {
  const average = mean(values, endIndex, period);
  let squaredDifferenceSum = 0;
  for (let index = endIndex - period + 1; index <= endIndex; index += 1) {
    squaredDifferenceSum += (values[index] - average) ** 2;
  }
  return Math.sqrt(squaredDifferenceSum / period);
}

function makeBands(
  closes: number[],
  period: number,
  multiplier: number,
): Array<BandsAt | undefined> {
  const bands: Array<BandsAt | undefined> = new Array(closes.length);
  const ema: number[] = new Array(closes.length);
  const alpha = 2 / (period + 1);

  for (let index = 0; index < closes.length; index += 1) {
    ema[index] =
      index === 0
        ? closes[index]
        : alpha * closes[index] + (1 - alpha) * ema[index - 1];

    if (index < period - 1) continue;
    const deviation = populationStdDev(closes, index, period) * multiplier;
    bands[index] = {
      middle: ema[index],
      upper: ema[index] + deviation,
      lower: ema[index] - deviation,
    };
  }

  return bands;
}

function lineStrengthsAt(
  closes: number[],
  bands: Array<BandsAt | undefined>,
  endIndex: number,
  period: number,
): { bullish: number; bearish: number } {
  let bullishDistance = 0;
  let bearishDistance = 0;
  let bullishDenominator = 0;
  let bearishDenominator = 0;

  for (let index = endIndex - period + 1; index <= endIndex; index += 1) {
    const band = bands[index];
    if (!band) return { bullish: 0, bearish: 0 };

    const upperDistance = closes[index] - band.upper;
    const lowerDistance = band.lower - closes[index];
    bullishDistance += Math.max(upperDistance, 0);
    bearishDistance += Math.max(lowerDistance, 0);
    bullishDenominator += Math.abs(upperDistance);
    bearishDenominator += Math.abs(lowerDistance);
  }

  return {
    bullish:
      bullishDenominator === 0
        ? 0
        : (bullishDistance / bullishDenominator) * 100,
    bearish:
      bearishDenominator === 0
        ? 0
        : (bearishDistance / bearishDenominator) * 100,
  };
}

function mostRecentExcursion(
  closes: number[],
  bands: Array<BandsAt | undefined>,
  endIndex: number,
  period: number,
): Exclude<BBandTrend, null> | null {
  let direction: Exclude<BBandTrend, null> | null = null;
  for (
    let index = Math.max(period - 1, endIndex - period + 1);
    index <= endIndex;
    index += 1
  ) {
    const band = bands[index];
    if (!band) continue;
    if (closes[index] > band.upper) direction = "bullish";
    else if (closes[index] < band.lower) direction = "bearish";
  }
  return direction;
}

/**
 * Calculate LuxAlgo BBands BO over the provided candle closes.
 *
 * The green/red series each sum the last `period` candles' excursions beyond
 * their EMA-based Bollinger extreme, normalized by total absolute distance.
 * A color line appears when its series changes from zero to positive. The
 * latched `trend` remains until the opposing color line appears.
 */
export function calcBBandsBO(
  closes: number[],
  period = 14,
  multiplier = 1,
  timestamps?: string[],
  _source: BBandSource = "close",
): BBandResult | null {
  if (
    !Number.isInteger(period) ||
    period < 2 ||
    !Number.isFinite(multiplier) ||
    multiplier <= 0 ||
    closes.some((close) => !Number.isFinite(close))
  ) {
    return null;
  }

  // Each of the last `period` Bollinger values itself needs `period` closes.
  const firstSeriesIndex = 2 * period - 2;
  if (closes.length <= firstSeriesIndex) return null;

  const bands = makeBands(closes, period, multiplier);
  let trend: BBandTrend = null;
  let trendStartIndex: number | null = null;
  let previousBullishActive: boolean | undefined;
  let previousBearishActive: boolean | undefined;
  let latestStrengths = { bullish: 0, bearish: 0 };

  for (let index = firstSeriesIndex; index < closes.length; index += 1) {
    const strengths = lineStrengthsAt(closes, bands, index, period);
    const bullishActive = strengths.bullish > 0;
    const bearishActive = strengths.bearish > 0;

    if (previousBullishActive === undefined) {
      // Establish an initial state without fabricating a line-start time at
      // the edge of the downloaded history window.
      if (bullishActive || bearishActive) {
        trend =
          mostRecentExcursion(closes, bands, index, period) ??
          (bullishActive ? "bullish" : "bearish");
      }
    } else {
      const bullishLineAppeared =
        bullishActive && !previousBullishActive;
      const bearishLineAppeared =
        bearishActive && !previousBearishActive;

      if (bullishLineAppeared && bearishLineAppeared) {
        const lastExcursion = mostRecentExcursion(
          closes,
          bands,
          index,
          period,
        );
        if (lastExcursion && lastExcursion !== trend) {
          trend = lastExcursion;
          trendStartIndex = index;
        }
      } else if (bullishLineAppeared && trend !== "bullish") {
        trend = "bullish";
        trendStartIndex = index;
      } else if (bearishLineAppeared && trend !== "bearish") {
        trend = "bearish";
        trendStartIndex = index;
      }
    }

    previousBullishActive = bullishActive;
    previousBearishActive = bearishActive;
    latestStrengths = strengths;
  }

  const latestIndex = closes.length - 1;
  const latestBands = bands[latestIndex];
  if (!latestBands) return null;

  const breakoutStartAt =
    trendStartIndex === null ? null : timestamps?.[trendStartIndex] ?? null;
  const breakoutEndAt =
    trend === null ? null : timestamps?.[latestIndex] ?? null;
  const signal: BBandSignal =
    trend === "bullish"
      ? "bullish_breakout"
      : trend === "bearish"
        ? "bearish_breakout"
        : "neutral";

  return {
    oscillatorValue: round(
      latestStrengths.bullish - latestStrengths.bearish,
      4,
    ),
    signal,
    trend,
    upperBand: round(latestBands.upper, 2),
    lowerBand: round(latestBands.lower, 2),
    middleBand: round(latestBands.middle, 2),
    breakoutAt: breakoutStartAt,
    breakoutStartAt,
    breakoutEndAt,
  };
}
