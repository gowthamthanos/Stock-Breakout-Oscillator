export type CandleInterval = "5m" | "15m" | "1h" | "1d" | "1wk" | "1mo";

function timestampMs(value: Date | string | number): number | undefined {
  if (value instanceof Date) {
    const time = value.getTime();
    return Number.isFinite(time) ? time : undefined;
  }
  if (typeof value === "number") {
    const milliseconds = value < 1_000_000_000_000 ? value * 1000 : value;
    return Number.isFinite(milliseconds) ? milliseconds : undefined;
  }
  const time = Date.parse(value);
  return Number.isFinite(time) ? time : undefined;
}

export function exchangeDateKey(time: number): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(time));
}

export function exchangeMonthKey(time: number): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
  }).format(new Date(time));
}

export function exchangeWeekKey(time: number): string {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "numeric",
    day: "numeric",
  }).formatToParts(new Date(time));
  const year = Number(parts.find((part) => part.type === "year")?.value);
  const month = Number(parts.find((part) => part.type === "month")?.value);
  const day = Number(parts.find((part) => part.type === "day")?.value);
  const date = new Date(Date.UTC(year, month - 1, day));
  const dayOfWeek = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() - dayOfWeek + 1);
  return date.toISOString().slice(0, 10);
}

function exchangeDateTimeParts(time: number): {
  year: number;
  month: number;
  day: number;
} {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "numeric",
    day: "numeric",
  }).formatToParts(new Date(time));
  return {
    year: Number(parts.find((part) => part.type === "year")?.value),
    month: Number(parts.find((part) => part.type === "month")?.value),
    day: Number(parts.find((part) => part.type === "day")?.value),
  };
}

function exchangeLocalTimeToUtc(
  year: number,
  month: number,
  day: number,
  hour: number,
  minute = 0,
): number {
  return Date.UTC(year, month - 1, day, hour, minute) - 5.5 * 60 * 60 * 1000;
}

/**
 * Returns true only after the candle's interval has finished in the NSE
 * timezone. Weekly/monthly candles use conservative period boundaries so a
 * partially formed candle can never trigger a confirmed alert.
 */
export function isCandleClosed(
  timestamp: Date | string | number,
  interval: CandleInterval,
  now = Date.now(),
): boolean {
  const candleStart = timestampMs(timestamp);
  if (candleStart === undefined || !Number.isFinite(now)) return false;

  const { year, month, day } = exchangeDateTimeParts(candleStart);
  const nowParts = exchangeDateTimeParts(now);
  const candleDate = exchangeDateKey(candleStart);
  const currentDate = exchangeDateKey(now);

  if (interval === "5m" || interval === "15m" || interval === "1h") {
    const intervalMs = interval === "5m"
      ? 5 * 60 * 1000
      : interval === "15m"
        ? 15 * 60 * 1000
        : 60 * 60 * 1000;
    const sessionClose = exchangeLocalTimeToUtc(year, month, day, 15, 30);
    const candleEnd = Math.min(candleStart + intervalMs, sessionClose);
    return now >= candleEnd;
  }

  if (interval === "1d") {
    if (candleDate !== currentDate) return true;
    return now >= exchangeLocalTimeToUtc(year, month, day, 15, 30);
  }

  if (interval === "1wk") {
    if (exchangeWeekKey(candleStart) !== exchangeWeekKey(now)) return true;
    const monday = new Date(`${exchangeWeekKey(candleStart)}T00:00:00.000Z`);
    monday.setUTCDate(monday.getUTCDate() + 4);
    return now >= exchangeLocalTimeToUtc(
      monday.getUTCFullYear(),
      monday.getUTCMonth() + 1,
      monday.getUTCDate(),
      15,
      30,
    );
  }

  if (exchangeMonthKey(candleStart) !== exchangeMonthKey(now)) return true;
  const nextMonth = new Date(Date.UTC(nowParts.year, nowParts.month, 1));
  return now >= exchangeLocalTimeToUtc(
    nextMonth.getUTCFullYear(),
    nextMonth.getUTCMonth() + 1,
    1,
    0,
  );
}
