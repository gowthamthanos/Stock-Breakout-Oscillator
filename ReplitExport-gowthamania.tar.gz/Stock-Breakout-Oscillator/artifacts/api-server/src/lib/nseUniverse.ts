import { PRESETS, type Preset } from "./presets";
import { logger } from "./logger";

const NSE_EQUITY_URL = "https://archives.nseindia.com/content/equities/EQUITY_L.csv";
const CACHE_TTL_MS = 6 * 60 * 60 * 1000;
const NEW_IPO_WINDOW_DAYS = 730;
const DYNAMIC_PRESET_IDS = new Set(["india_all_nse", "india_new_ipos"]);

type NseListing = {
  symbol: string;
  companyName: string;
  series: string;
  isin: string;
  listingDate: Date | null;
};

let cachedDynamicPresets: { expiresAt: number; presets: Preset[] } | undefined;
let pendingLoad: Promise<Preset[]> | undefined;

function parseCsvLine(line: string): string[] {
  const values: string[] = [];
  let value = "";
  let quoted = false;

  for (let i = 0; i < line.length; i += 1) {
    const character = line[i];
    const nextCharacter = line[i + 1];

    if (character === '"' && quoted && nextCharacter === '"') {
      value += '"';
      i += 1;
    } else if (character === '"') {
      quoted = !quoted;
    } else if (character === "," && !quoted) {
      values.push(value.trim());
      value = "";
    } else {
      value += character;
    }
  }

  values.push(value.trim());
  return values;
}

function parseListingDate(value: string): Date | null {
  const match = value.match(/^(\d{2})-([A-Z]{3})-(\d{4})$/i);
  if (!match) return null;

  const month = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]
    .indexOf(match[2].toUpperCase());
  if (month < 0) return null;

  return new Date(Date.UTC(Number(match[3]), month, Number(match[1])));
}

function parseNseListings(csv: string): NseListing[] {
  const lines = csv.split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];

  const headers = parseCsvLine(lines[0]).map((header) => header.trim().toUpperCase());
  const symbolIndex = headers.indexOf("SYMBOL");
  const companyIndex = headers.indexOf("NAME OF COMPANY");
  const seriesIndex = headers.indexOf("SERIES");
  const listingDateIndex = headers.indexOf("DATE OF LISTING");
  const isinIndex = headers.indexOf("ISIN NUMBER");

  if (symbolIndex < 0 || seriesIndex < 0) return [];

  return lines.slice(1).flatMap((line) => {
    const values = parseCsvLine(line);
    const symbol = values[symbolIndex]?.toUpperCase();
    const series = values[seriesIndex]?.toUpperCase();
    if (!symbol || !series || !/^[A-Z0-9&-]+$/.test(symbol)) return [];

    return [{
      symbol,
      companyName: values[companyIndex] ?? symbol,
      series,
      isin: values[isinIndex] ?? "",
      listingDate: listingDateIndex >= 0 ? parseListingDate(values[listingDateIndex] ?? "") : null,
    }];
  });
}

let cachedListings: NseListing[] = [];

function staticStockSymbols(): string[] {
  return [...new Set(
    PRESETS
      .filter((preset) => preset.group !== "India Indices")
      .flatMap((preset) => preset.symbols)
      .filter((symbol) => symbol.endsWith(".NS")),
  )];
}

function fallbackDynamicPresets(): Preset[] {
  const fallbackIpos = PRESETS.find((preset) => preset.id === "india_recent_ipos");
  return [
    {
      id: "india_all_nse",
      name: "All NSE Listed Stocks",
      description: "All available NSE equity symbols; refresh the list from the exchange feed",
      group: "India Exchange",
      symbols: staticStockSymbols(),
    },
    {
      id: "india_new_ipos",
      name: "New Indian IPOs",
      description: "Recent Indian IPOs from the curated fallback basket",
      group: "India Exchange",
      symbols: fallbackIpos?.symbols ?? [],
    },
  ];
}

async function loadDynamicPresets(): Promise<Preset[]> {
  const response = await fetch(NSE_EQUITY_URL, {
    headers: {
      Accept: "text/csv",
      "User-Agent": "BBands-BO-Screener/1.0",
    },
  });
  if (!response.ok) {
    throw new Error(`NSE equity feed returned ${response.status}`);
  }

  const listings = parseNseListings(await response.text())
    .filter((listing) => ["EQ", "BE", "SM", "ST"].includes(listing.series));
  cachedListings = listings;
  const symbols = [...new Set(listings.map((listing) => `${listing.symbol}.NS`))].sort();
  const ipoCutoff = Date.now() - NEW_IPO_WINDOW_DAYS * 24 * 60 * 60 * 1000;
  const ipoSymbols = listings
    .filter((listing) => listing.listingDate && listing.listingDate.getTime() >= ipoCutoff)
    .sort((a, b) => (b.listingDate?.getTime() ?? 0) - (a.listingDate?.getTime() ?? 0))
    .map((listing) => `${listing.symbol}.NS`);

  if (symbols.length === 0) {
    throw new Error("NSE equity feed contained no usable symbols");
  }

  return [
    {
      id: "india_all_nse",
      name: "All NSE Listed Stocks",
      description: `${symbols.length} NSE-listed equity symbols from the live exchange feed`,
      group: "India Exchange",
      symbols,
    },
    {
      id: "india_new_ipos",
      name: "New Indian IPOs",
      description: `${ipoSymbols.length} NSE stocks listed in the last two years`,
      group: "India Exchange",
      symbols: [...new Set(ipoSymbols)],
    },
  ];
}

export async function getNseEquityInstrumentToken(yahooSymbol: string): Promise<string | undefined> {
  await getDynamicPresets();
  const symbol = yahooSymbol.toUpperCase().replace(/\.NS$/, "");
  const listing = cachedListings.find(
    (candidate) => candidate.symbol === symbol && candidate.series === "EQ" && candidate.isin,
  );
  return listing ? `NSE_EQ|${listing.isin}` : undefined;
}

export async function getDynamicPresets(): Promise<Preset[]> {
  if (cachedDynamicPresets && cachedDynamicPresets.expiresAt > Date.now()) {
    return cachedDynamicPresets.presets;
  }
  if (pendingLoad) return pendingLoad;

  pendingLoad = loadDynamicPresets()
    .catch((error) => {
      logger.warn({ err: error }, "Failed to load NSE equity universe; using curated fallback");
      return fallbackDynamicPresets();
    })
    .then((presets) => {
      cachedDynamicPresets = {
        presets,
        expiresAt: Date.now() + CACHE_TTL_MS,
      };
      return presets;
    })
    .finally(() => {
      pendingLoad = undefined;
    });

  return pendingLoad;
}

export async function getAvailablePresets(): Promise<Preset[]> {
  const dynamicPresets = await getDynamicPresets();
  return [
    ...PRESETS.filter((preset) => !DYNAMIC_PRESET_IDS.has(preset.id)),
    ...dynamicPresets,
  ];
}

export async function getPresetWithDynamicUniverse(id: string): Promise<Preset | undefined> {
  const presets = await getAvailablePresets();
  return presets.find((preset) => preset.id === id);
}