export type ObservedTrend = "bullish" | "bearish" | null;
export type AlertTrendEventType = "started" | "changed";

export function classifyTrendTransition(
  previous: ObservedTrend,
  current: ObservedTrend,
): AlertTrendEventType | null {
  if (current === null || previous === current) return null;
  return previous === null ? "started" : "changed";
}
