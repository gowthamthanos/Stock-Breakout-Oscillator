import { Router, type IRouter } from "express";
import healthRouter from "./health";
import screenerRouter from "./screener";
import watchlistRouter from "./watchlist";
import alertsRouter from "./alerts";
import telegramRouter from "./telegram";
import upstoxRouter from "./upstox";

const router: IRouter = Router();

router.use(healthRouter);
router.use(screenerRouter);
router.use(watchlistRouter);
router.use(alertsRouter);
router.use(telegramRouter);
router.use(upstoxRouter);

export default router;
