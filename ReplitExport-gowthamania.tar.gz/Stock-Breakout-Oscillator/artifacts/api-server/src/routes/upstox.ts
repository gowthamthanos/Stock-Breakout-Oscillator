import { Router, type IRouter } from "express";
import { getNseEquityInstrumentToken } from "../lib/nseUniverse";
import { logger } from "../lib/logger";

const router: IRouter = Router();
const SANDBOX_BASE_URL = "https://sandbox.upstox.com";

type OrderType = "MARKET" | "LIMIT" | "SL" | "SL-M";
type TransactionType = "BUY" | "SELL";
type ProductType = "D" | "I";

function getSandboxToken(): string | undefined {
  return process.env.UPSTOX_SANDBOX_ACCESS_TOKEN;
}

function errorMessage(body: unknown): string {
  if (typeof body === "object" && body !== null && "errors" in body) {
    const errors = (body as { errors?: Array<{ message?: string }> }).errors;
    if (errors?.[0]?.message) return errors[0].message;
  }
  if (typeof body === "object" && body !== null && "message" in body) {
    const message = (body as { message?: string }).message;
    if (message) return message;
  }
  return "Upstox sandbox request failed";
}

async function sandboxRequest(path: string, init: RequestInit = {}): Promise<{ response: Response; body: unknown }> {
  const token = getSandboxToken();
  if (!token) {
    throw new Error("Upstox sandbox access token is not configured");
  }

  const response = await fetch(`${SANDBOX_BASE_URL}${path}`, {
    ...init,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...init.headers,
    },
  });
  const text = await response.text();
  let body: unknown = {};
  try {
    body = text ? JSON.parse(text) : {};
  } catch {
    body = { message: text };
  }
  return { response, body };
}

function parseOrderInput(body: unknown): {
  symbol: string;
  quantity: number;
  transactionType: TransactionType;
  orderType: OrderType;
  product: ProductType;
  validity: "DAY" | "IOC";
  price?: number;
  triggerPrice?: number;
  tag?: string;
} | { error: string } {
  if (typeof body !== "object" || body === null) return { error: "Order details are required" };
  const input = body as Record<string, unknown>;
  const symbol = typeof input.symbol === "string" ? input.symbol.trim().toUpperCase() : "";
  const quantity = Number(input.quantity);
  const transactionType = input.transactionType === "SELL" ? "SELL" : input.transactionType === "BUY" ? "BUY" : undefined;
  const orderType = ["MARKET", "LIMIT", "SL", "SL-M"].includes(String(input.orderType))
    ? input.orderType as OrderType
    : undefined;
  const product = input.product === "I" ? "I" : input.product === "D" ? "D" : undefined;
  const validity = input.validity === "IOC" ? "IOC" : "DAY";
  const price = input.price === undefined || input.price === "" ? undefined : Number(input.price);
  const triggerPrice = input.triggerPrice === undefined || input.triggerPrice === "" ? undefined : Number(input.triggerPrice);

  if (!symbol) return { error: "An NSE symbol is required" };
  if (!Number.isInteger(quantity) || quantity <= 0) return { error: "Quantity must be a positive whole number" };
  if (!transactionType) return { error: "Transaction type must be BUY or SELL" };
  if (!orderType) return { error: "Unsupported order type" };
  if (!product) return { error: "Product must be Delivery or Intraday" };
  if (["LIMIT", "SL"].includes(orderType) && (!Number.isFinite(price) || price === undefined || price <= 0)) {
    return { error: "A positive limit price is required for this order type" };
  }
  if (["SL", "SL-M"].includes(orderType) && (!Number.isFinite(triggerPrice) || triggerPrice === undefined || triggerPrice <= 0)) {
    return { error: "A positive trigger price is required for this order type" };
  }

  return {
    symbol,
    quantity,
    transactionType,
    orderType,
    product,
    validity,
    ...(price === undefined ? {} : { price }),
    ...(triggerPrice === undefined ? {} : { triggerPrice }),
    ...(typeof input.tag === "string" && input.tag.trim() ? { tag: input.tag.trim().slice(0, 40) } : {}),
  };
}

router.get("/upstox/status", (_req, res) => {
  res.json({
    configured: Boolean(getSandboxToken()),
    environment: "sandbox",
    liveTradingEnabled: false,
  });
});

router.post("/upstox/orders/preview", async (req, res): Promise<void> => {
  const parsed = parseOrderInput(req.body);
  if ("error" in parsed) {
    res.status(400).json({ error: parsed.error });
    return;
  }

  const instrumentToken = await getNseEquityInstrumentToken(parsed.symbol);
  if (!instrumentToken) {
    res.status(400).json({ error: `Could not resolve an NSE equity instrument for ${parsed.symbol}` });
    return;
  }

  res.json({
    environment: "sandbox",
    symbol: parsed.symbol,
    instrumentToken,
    quantity: parsed.quantity,
    transactionType: parsed.transactionType,
    orderType: parsed.orderType,
    product: parsed.product,
    validity: parsed.validity,
    price: parsed.price ?? 0,
    triggerPrice: parsed.triggerPrice ?? 0,
    tag: parsed.tag ?? "bbands-bo",
    message: "Review this sandbox order before placing it.",
  });
});

router.post("/upstox/orders", async (req, res): Promise<void> => {
  const parsed = parseOrderInput(req.body);
  if ("error" in parsed) {
    res.status(400).json({ error: parsed.error });
    return;
  }

  const instrumentToken = await getNseEquityInstrumentToken(parsed.symbol);
  if (!instrumentToken) {
    res.status(400).json({ error: `Could not resolve an NSE equity instrument for ${parsed.symbol}` });
    return;
  }

  const { response, body } = await sandboxRequest("/v2/order/place", {
    method: "POST",
    body: JSON.stringify({
      quantity: parsed.quantity,
      product: parsed.product,
      validity: parsed.validity,
      price: parsed.price ?? 0,
      tag: parsed.tag ?? "bbands-bo",
      instrument_token: instrumentToken,
      order_type: parsed.orderType,
      transaction_type: parsed.transactionType,
      disclosed_quantity: 0,
      trigger_price: parsed.triggerPrice ?? 0,
      is_amo: false,
    }),
  });

  if (!response.ok) {
    res.status(response.status).json({ error: errorMessage(body), details: body });
    return;
  }

  res.status(201).json({
    environment: "sandbox",
    symbol: parsed.symbol,
    instrumentToken,
    response: body,
  });
});

router.get("/upstox/orders/:orderId", async (req, res): Promise<void> => {
  try {
    const { response, body } = await sandboxRequest(
      `/v2/order/details?order_id=${encodeURIComponent(req.params.orderId)}`,
    );
    if (!response.ok) {
      res.status(response.status).json({ error: errorMessage(body), details: body });
      return;
    }
    res.json(body);
  } catch (error) {
    logger.warn({ err: error }, "Failed to read Upstox sandbox order");
    res.status(503).json({ error: error instanceof Error ? error.message : "Upstox sandbox unavailable" });
  }
});

router.delete("/upstox/orders/:orderId", async (req, res): Promise<void> => {
  try {
    const { response, body } = await sandboxRequest(
      `/v2/order/cancel?order_id=${encodeURIComponent(req.params.orderId)}`,
      { method: "DELETE" },
    );
    if (!response.ok) {
      res.status(response.status).json({ error: errorMessage(body), details: body });
      return;
    }
    res.json(body);
  } catch (error) {
    logger.warn({ err: error }, "Failed to cancel Upstox sandbox order");
    res.status(503).json({ error: error instanceof Error ? error.message : "Upstox sandbox unavailable" });
  }
});

export default router;