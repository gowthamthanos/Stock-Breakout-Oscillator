import { Router, type IRouter } from "express";
import { calcBBandsBO } from "../lib/bbands";
import { fetchQuotes, type YInterval } from "../lib/yahooFinance";
import { getAvailablePresets } from "../lib/nseUniverse";
import { resolveSymbols } from "../lib/symbols";
import {
  RunScreenerQueryParams,
  GetScreenerSummaryQueryParams,
  RunScreenerResponseItem,
  GetScreenerPresetsResponse,
  GetScreenerSummaryResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function trendStartTime(row: { breakoutStartAt?: string | Date | null }): number {
  if (!row.breakoutStartAt) return Number.NEGATIVE_INFINITY;
  const timestamp = row.breakoutStartAt instanceof Date
    ? row.breakoutStartAt.getTime()
    : Date.parse(row.breakoutStartAt);
  return Number.isFinite(timestamp) ? timestamp : Number.NEGATIVE_INFINITY;
}

function sortNewestTrendFirst<
  T extends { symbol: string; breakoutStartAt?: string | Date | null },
>(
  rows: T[],
): T[] {
  return [...rows].sort((a, b) => {
    const timeDifference = trendStartTime(b) - trendStartTime(a);
    return Number.isNaN(timeDifference) || timeDifference === 0
      ? a.symbol.localeCompare(b.symbol)
      : timeDifference;
  });
}

router.get("/screener/scan", async (req, res): Promise<void> => {
  const params = RunScreenerQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const {
    symbols: rawSymbols,
    preset,
    period = 14,
    stdDev = 1.0,
    src = "close",
    interval = "1d",
    closedCandlesOnly = false,
    minOscillator,
    maxOscillator,
    signal: signalFilter,
  } = params.data;

  const symbols = await resolveSymbols(rawSymbols, preset);
  const quotes = await fetchQuotes(
    symbols,
    period,
    interval as YInterval,
    3,
    closedCandlesOnly,
  );

  const scannedAt = new Date().toISOString();
  const results = [];

  for (const quote of quotes) {
     const bbResult = calcBBandsBO(quote.closes, period, stdDev, quote.timestamps, src);
    if (!bbResult) continue;

    const item = {
      symbol: quote.symbol,
      name: quote.name,
      price: quote.price,
      change: quote.change,
      changePercent: quote.changePercent,
      oscillatorValue: bbResult.oscillatorValue,
      signal: bbResult.signal,
      trend: bbResult.trend,
      upperBand: bbResult.upperBand,
      lowerBand: bbResult.lowerBand,
      middleBand: bbResult.middleBand,
      breakoutAt: bbResult.breakoutAt,
      breakoutStartAt: bbResult.breakoutStartAt,
      breakoutEndAt: bbResult.breakoutEndAt,
      volume: quote.volume,
      avgVolume: quote.avgVolume,
      marketCap: quote.marketCap,
      scannedAt,
    };

    const validated = RunScreenerResponseItem.safeParse(item);
    if (!validated.success) continue;

    const d = validated.data;
    if (!d.trend) continue;
    if (minOscillator !== undefined && d.oscillatorValue < minOscillator) continue;
    if (maxOscillator !== undefined && d.oscillatorValue > maxOscillator) continue;
    if (signalFilter && d.signal !== signalFilter) continue;

    results.push(d);
  }

  res.json(sortNewestTrendFirst(results));
});

router.get("/screener/summary", async (req, res): Promise<void> => {
  const params = GetScreenerSummaryQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const {
    symbols: rawSymbols,
    preset,
    period = 14,
    stdDev = 1.0,
    src = "close",
    interval = "1d",
    signal: signalFilter,
  } = params.data;

  const symbols = await resolveSymbols(rawSymbols, preset);
  const quotes = await fetchQuotes(symbols, period, interval as YInterval);

  const scannedAt = new Date().toISOString();
  const allResults = [];

  for (const quote of quotes) {
     const bbResult = calcBBandsBO(quote.closes, period, stdDev, quote.timestamps, src);
    if (!bbResult) continue;
     allResults.push({
      symbol: quote.symbol,
      name: quote.name,
      price: quote.price,
      change: quote.change,
      changePercent: quote.changePercent,
      oscillatorValue: bbResult.oscillatorValue,
      signal: bbResult.signal,
      trend: bbResult.trend,
      upperBand: bbResult.upperBand,
      lowerBand: bbResult.lowerBand,
      middleBand: bbResult.middleBand,
      breakoutAt: bbResult.breakoutAt,
      breakoutStartAt: bbResult.breakoutStartAt,
      breakoutEndAt: bbResult.breakoutEndAt,
      volume: quote.volume,
      avgVolume: quote.avgVolume,
      marketCap: quote.marketCap,
      scannedAt,
    });
  }

  const filteredResults = sortNewestTrendFirst(
    allResults.filter(
      (result) =>
        result.trend !== null &&
        (!signalFilter || result.signal === signalFilter),
    ),
  );
  const bullishBreakouts = filteredResults.filter((r) => r.trend === "bullish").length;
  const bearishBreakouts = filteredResults.filter((r) => r.trend === "bearish").length;
  const overbought = 0;
  const oversold = 0;
  const neutral = allResults.filter((r) => r.trend === null).length;

  const topBullish = sortNewestTrendFirst(
    filteredResults.filter((r) => r.trend === "bullish"),
  )
    .slice(0, 5);

  const topBearish = sortNewestTrendFirst(
    filteredResults.filter((r) => r.trend === "bearish"),
  )
    .slice(0, 5);

  const summary = {
    totalScanned: filteredResults.length,
    bullishBreakouts,
    bearishBreakouts,
    overbought,
    oversold,
    neutral,
    topBullish,
    topBearish,
    scannedAt,
  };

  const validated = GetScreenerSummaryResponse.safeParse(summary);
  if (!validated.success) {
    req.log.error({ err: validated.error }, "Failed to validate summary");
    res.status(500).json({ error: "Internal server error" });
    return;
  }

  res.json(validated.data);
});

router.get("/screener/presets", async (_req, res): Promise<void> => {
  const result = GetScreenerPresetsResponse.safeParse(await getAvailablePresets());
  if (!result.success) {
    res.status(500).json({ error: "Failed to serialize presets" });
    return;
  }
  res.json(result.data);
});

export default router;
