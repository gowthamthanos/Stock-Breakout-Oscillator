import { randomUUID } from "node:crypto";
import { and, desc, eq, isNull } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreateAlertBody,
  ToggleAlertBody,
} from "@workspace/api-zod";
import {
  alertEventsTable,
  alertMonitorsTable,
  db,
} from "@workspace/db";
import { sendTelegramAlert } from "../lib/telegramService";
import { resolveAlertSymbols, normalizeSymbol } from "../lib/symbols";
import { requireAuth, authenticatedUserId } from "../middlewares/requireAuth";

const router: IRouter = Router();
const UUID_PATTERN =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const MAX_ACTIVE_ALERTS_PER_USER = 25;
const MAX_SYMBOLS_PER_ALERT = 100;

router.use(requireAuth);

router.get("/alerts", async (_req, res): Promise<void> => {
  const userId = authenticatedUserId(res);
  const [alerts, events] = await Promise.all([
    db
      .select()
      .from(alertMonitorsTable)
      .where(
        and(
          eq(alertMonitorsTable.userId, userId),
          isNull(alertMonitorsTable.deletedAt),
        ),
      )
      .orderBy(desc(alertMonitorsTable.createdAt)),
    db
      .select()
      .from(alertEventsTable)
      .where(eq(alertEventsTable.userId, userId))
      .orderBy(desc(alertEventsTable.createdAt))
      .limit(50),
  ]);

  res.json({ alerts, events });
});

router.post("/alerts", async (req, res): Promise<void> => {
  const parsed = CreateAlertBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const userId = authenticatedUserId(res);
  const input = parsed.data;
  const hasSymbol = Boolean(input.symbol?.trim());
  const hasPreset = Boolean(input.preset?.trim());
  if (hasSymbol === hasPreset) {
    res.status(400).json({ error: "Choose exactly one stock symbol or market category." });
    return;
  }

  const symbol = hasSymbol ? normalizeSymbol(input.symbol!) : null;
  if (
    symbol &&
    !/^[A-Z0-9&.-]+\.(NS|BO)$/.test(symbol)
  ) {
    res.status(400).json({
      error: "Enter an Indian NSE/BSE symbol, such as RELIANCE or RELIANCE.NS.",
    });
    return;
  }

  const preset = hasPreset ? input.preset!.trim() : null;
  const presetName = hasPreset ? input.presetName?.trim() || preset : null;
  try {
    const symbols = await resolveAlertSymbols({ symbol, preset });
    if (symbols.length > MAX_SYMBOLS_PER_ALERT) {
      res.status(400).json({
        error: `This category has ${symbols.length} symbols. Alert monitors support up to ${MAX_SYMBOLS_PER_ALERT}.`,
      });
      return;
    }
  } catch (error) {
    res.status(400).json({
      error: error instanceof Error ? error.message : "Invalid alert scope.",
    });
    return;
  }

  const active = await db
    .select({ id: alertMonitorsTable.id })
    .from(alertMonitorsTable)
    .where(
      and(
        eq(alertMonitorsTable.userId, userId),
        eq(alertMonitorsTable.enabled, true),
        isNull(alertMonitorsTable.deletedAt),
      ),
    );
  if (active.length >= MAX_ACTIVE_ALERTS_PER_USER) {
    res.status(409).json({
      error: `You can run up to ${MAX_ACTIVE_ALERTS_PER_USER} active alert monitors.`,
    });
    return;
  }

  const [alert] = await db
    .insert(alertMonitorsTable)
    .values({
      id: randomUUID(),
      userId,
      label: input.label.trim(),
      symbol,
      preset,
      presetName,
      interval: input.interval,
      period: input.period,
      stdDev: input.stdDev,
      direction: input.direction,
      telegramEnabled: input.telegramEnabled,
      enabled: true,
      trendStates: {},
    })
    .returning();

  if (!alert) {
    res.status(500).json({ error: "The alert could not be saved." });
    return;
  }
  res.status(201).json(alert);
});

router.delete("/alerts/events", async (_req, res): Promise<void> => {
  const userId = authenticatedUserId(res);
  await db
    .delete(alertEventsTable)
    .where(eq(alertEventsTable.userId, userId));
  res.status(204).end();
});

router.patch("/alerts/:alertId", async (req, res): Promise<void> => {
  const alertId = req.params.alertId;
  if (!UUID_PATTERN.test(alertId)) {
    res.status(404).json({ error: "Alert not found." });
    return;
  }

  const parsed = ToggleAlertBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const userId = authenticatedUserId(res);
  const [alert] = await db
    .update(alertMonitorsTable)
    .set({ enabled: parsed.data.enabled })
    .where(
      and(
        eq(alertMonitorsTable.id, alertId),
        eq(alertMonitorsTable.userId, userId),
        isNull(alertMonitorsTable.deletedAt),
      ),
    )
    .returning();
  if (!alert) {
    res.status(404).json({ error: "Alert not found." });
    return;
  }
  res.json(alert);
});

router.delete("/alerts/:alertId", async (req, res): Promise<void> => {
  const alertId = req.params.alertId;
  if (!UUID_PATTERN.test(alertId)) {
    res.status(404).json({ error: "Alert not found." });
    return;
  }

  const userId = authenticatedUserId(res);
  const [alert] = await db
    .update(alertMonitorsTable)
    .set({ enabled: false, deletedAt: new Date() })
    .where(
      and(
        eq(alertMonitorsTable.id, alertId),
        eq(alertMonitorsTable.userId, userId),
        isNull(alertMonitorsTable.deletedAt),
      ),
    )
    .returning({ id: alertMonitorsTable.id });
  if (!alert) {
    res.status(404).json({ error: "Alert not found." });
    return;
  }
  res.status(204).end();
});

router.post("/alerts/events/:eventId/retry", async (req, res): Promise<void> => {
  const eventId = req.params.eventId;
  if (!UUID_PATTERN.test(eventId)) {
    res.status(404).json({ error: "Failed Telegram event not found." });
    return;
  }

  const userId = authenticatedUserId(res);
  const [event] = await db
    .select()
    .from(alertEventsTable)
    .where(
      and(
        eq(alertEventsTable.id, eventId),
        eq(alertEventsTable.userId, userId),
        eq(alertEventsTable.telegramStatus, "failed"),
      ),
    )
    .limit(1);
  if (!event) {
    res.status(404).json({ error: "Failed Telegram event not found." });
    return;
  }

  await db
    .update(alertEventsTable)
    .set({ telegramStatus: "pending", telegramError: null })
    .where(
      and(
        eq(alertEventsTable.id, event.id),
        eq(alertEventsTable.userId, userId),
      ),
    );

  try {
    await sendTelegramAlert(userId, {
      symbol: event.symbol,
      alertLabel: event.alertLabel,
      direction: event.direction as "bullish" | "bearish",
      eventType: event.eventType as "started" | "changed" | "ended",
      signal: event.signal,
      oscillatorValue: event.oscillatorValue,
      interval: event.interval,
      period: event.period,
      stdDev: event.stdDev,
      breakoutAt: event.breakoutAt,
      breakoutStartAt: event.breakoutStartAt,
      breakoutEndAt: event.breakoutEndAt,
    });
    await db
      .update(alertEventsTable)
      .set({ telegramStatus: "sent", telegramError: null })
      .where(
        and(
          eq(alertEventsTable.id, event.id),
          eq(alertEventsTable.userId, userId),
        ),
      );
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Telegram delivery failed.";
    await db
      .update(alertEventsTable)
      .set({ telegramStatus: "failed", telegramError: message })
      .where(
        and(
          eq(alertEventsTable.id, event.id),
          eq(alertEventsTable.userId, userId),
        ),
      );
    res.status(502).json({ error: message });
    return;
  }

  const [updated] = await db
    .select()
    .from(alertEventsTable)
    .where(
      and(
        eq(alertEventsTable.id, event.id),
        eq(alertEventsTable.userId, userId),
      ),
    )
    .limit(1);
  res.json(updated);
});

export default router;
