import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, watchlistTable } from "@workspace/db";
import {
  AddToWatchlistBody,
  GetWatchlistResponse,
  AddToWatchlistResponse,
  RemoveFromWatchlistParams,
} from "@workspace/api-zod";
import YahooFinance from "yahoo-finance2";
const yahooFinance = new YahooFinance();

const router: IRouter = Router();

router.get("/watchlist", async (_req, res): Promise<void> => {
  const entries = await db
    .select()
    .from(watchlistTable)
    .orderBy(watchlistTable.addedAt);

  const result = GetWatchlistResponse.safeParse(
    entries.map((e) => ({
      id: e.id,
      symbol: e.symbol,
      name: e.name,
      addedAt: e.addedAt.toISOString(),
    })),
  );

  if (!result.success) {
    res.status(500).json({ error: "Internal server error" });
    return;
  }

  res.json(result.data);
});

router.post("/watchlist", async (req, res): Promise<void> => {
  const parsed = AddToWatchlistBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const enteredSymbol = parsed.data.symbol.trim().toUpperCase();
  // Keep the watchlist India-only while allowing users to type RELIANCE
  // instead of RELIANCE.NS. Explicit NSE/BSE symbols are preserved.
  const symbol =
    enteredSymbol.endsWith(".NS") || enteredSymbol.endsWith(".BO")
      ? enteredSymbol
      : `${enteredSymbol}.NS`;

  if (!/^[A-Z0-9&.-]+\.(NS|BO)$/.test(symbol)) {
    res.status(400).json({
      error: "Enter an Indian NSE/BSE symbol, for example RELIANCE or RELIANCE.NS",
    });
    return;
  }

  // Check not already in watchlist
  const existing = await db
    .select()
    .from(watchlistTable)
    .where(eq(watchlistTable.symbol, symbol));

  if (existing.length > 0) {
    res.status(400).json({ error: `${symbol} is already in your watchlist` });
    return;
  }

  // Validate symbol and get name from Yahoo Finance
  let name = symbol;
  try {
    const quote = await yahooFinance.quote(symbol, {}, { validateResult: false });
    const q = quote as unknown as { shortName?: string; longName?: string };
    name = q.shortName ?? q.longName ?? symbol;
  } catch {
    // If yahoo can't find it, we still allow adding — symbol might be valid but temporarily unavailable
    req.log.warn({ symbol }, "Could not fetch quote for watchlist symbol");
  }

  const [entry] = await db
    .insert(watchlistTable)
    .values({ symbol, name })
    .returning();

  const result = AddToWatchlistResponse.safeParse({
    id: entry.id,
    symbol: entry.symbol,
    name: entry.name,
    addedAt: entry.addedAt.toISOString(),
  });

  if (!result.success) {
    res.status(500).json({ error: "Internal server error" });
    return;
  }

  res.status(201).json(result.data);
});

router.delete("/watchlist/:symbol", async (req, res): Promise<void> => {
  const params = RemoveFromWatchlistParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const symbol = Array.isArray(req.params.symbol)
    ? req.params.symbol[0]
    : req.params.symbol;

  const [deleted] = await db
    .delete(watchlistTable)
    .where(eq(watchlistTable.symbol, symbol.toUpperCase()))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: `${symbol} not found in watchlist` });
    return;
  }

  res.sendStatus(204);
});

export default router;
