import { Router, type IRouter, type Request, type Response } from "express";
import { SendTelegramAlertBody as TelegramAlertInputSchema } from "@workspace/api-zod";
import {
  getTelegramStatus,
  startTelegramLink,
  sendTelegramAlert,
  sendTelegramTest,
  TelegramError,
} from "../lib/telegramService";
import { authenticatedUserId, requireAuth } from "../middlewares/requireAuth";

const router: IRouter = Router();
router.use(requireAuth);

function handleTelegramError(req: Request, res: Response, error: unknown): void {
  const telegramError = error instanceof TelegramError ? error : undefined;
  const status = telegramError?.kind === "not_configured"
    ? 503
    : telegramError?.kind === "chat_not_found"
      ? 409
      : 502;

  req.log.warn({ err: error }, "Telegram request failed");
  res.status(status).json({
    error: error instanceof Error ? error.message : "Telegram request failed",
  });
}

router.get("/telegram/status", async (_req, res): Promise<void> => {
  try {
    res.json(await getTelegramStatus(authenticatedUserId(res)));
  } catch (error) {
    handleTelegramError(_req, res, error);
  }
});

router.post("/telegram/link", async (_req, res): Promise<void> => {
  try {
    res.json(await startTelegramLink(authenticatedUserId(res)));
  } catch (error) {
    handleTelegramError(_req, res, error);
  }
});

router.post("/telegram/test", async (req, res): Promise<void> => {
  try {
    await sendTelegramTest(authenticatedUserId(res));
    res.json({ sent: true, message: "Test message sent to Telegram." });
  } catch (error) {
    handleTelegramError(req, res, error);
  }
});

router.post("/telegram/notify", async (req, res): Promise<void> => {
  const parsed = TelegramAlertInputSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    await sendTelegramAlert(authenticatedUserId(res), {
      ...parsed.data,
      period: parsed.data.period ?? 14,
      stdDev: parsed.data.stdDev ?? 1,
    });
    res.json({ sent: true, message: "Alert sent to Telegram." });
  } catch (error) {
    handleTelegramError(req, res, error);
  }
});

export default router;