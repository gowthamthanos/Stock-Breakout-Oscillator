import assert from "node:assert/strict";
import test from "node:test";
import { classifyTrendTransition } from "../src/lib/alertTransition.ts";

test("a newly appearing line starts a trend", () => {
  assert.equal(classifyTrendTransition(null, "bullish"), "started");
  assert.equal(classifyTrendTransition(null, "bearish"), "started");
});

test("the same line does not emit another alert", () => {
  assert.equal(classifyTrendTransition("bullish", "bullish"), null);
  assert.equal(classifyTrendTransition("bearish", "bearish"), null);
});

test("a missing colored line does not end the latched trend", () => {
  assert.equal(classifyTrendTransition("bullish", null), null);
  assert.equal(classifyTrendTransition("bearish", null), null);
});

test("only the opposite line changes the active trend", () => {
  assert.equal(classifyTrendTransition("bullish", "bearish"), "changed");
  assert.equal(classifyTrendTransition("bearish", "bullish"), "changed");
});
