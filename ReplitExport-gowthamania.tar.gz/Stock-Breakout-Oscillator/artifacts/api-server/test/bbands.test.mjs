import assert from "node:assert/strict";
import test from "node:test";
import { calcBBandsBO } from "../src/lib/bbands.ts";
import { isCandleClosed } from "../src/lib/candleCompletion.ts";

function timestamps(length) {
  return Array.from({ length }, (_, index) =>
    new Date(Date.UTC(2026, 9, 6, 3, 45 + index * 15)).toISOString(),
  );
}

test("uses LuxAlgo's default 14-period calculation window", () => {
  assert.equal(calcBBandsBO(Array(26).fill(100)), null);

  const result = calcBBandsBO(Array(27).fill(100));
  assert.ok(result);
  assert.equal(result.trend, null);
  assert.equal(result.signal, "neutral");
  assert.equal(result.oscillatorValue, 0);
});

test("starts bullish when the LuxAlgo green series first appears", () => {
  const closes = [100, 101, 99, 100, 102, 120];
  const result = calcBBandsBO(closes, 3, 1, timestamps(closes.length));

  assert.ok(result);
  assert.equal(result.trend, "bullish");
  assert.equal(result.signal, "bullish_breakout");
  assert.equal(result.breakoutStartAt, "2026-10-06T05:00:00.000Z");
  assert.equal(result.oscillatorValue, 38.0171);
});

test("keeps a bullish trend latched after the green series disappears", () => {
  const closes = [100, 101, 99, 100, 102, 120, 101, 100, 102, 101];
  const result = calcBBandsBO(closes, 3, 1, timestamps(closes.length));

  assert.ok(result);
  assert.equal(result.trend, "bullish");
  assert.equal(result.oscillatorValue, 0);
  assert.equal(result.breakoutStartAt, "2026-10-06T05:00:00.000Z");
});

test("changes to bearish only when the red series appears", () => {
  const closes = [100, 101, 99, 100, 102, 120, 101, 100, 102, 101, 60];
  const result = calcBBandsBO(closes, 3, 1, timestamps(closes.length));

  assert.ok(result);
  assert.equal(result.trend, "bearish");
  assert.equal(result.signal, "bearish_breakout");
  assert.equal(result.breakoutStartAt, "2026-10-06T06:15:00.000Z");
});

test("does not invent a trend-start timestamp at the edge of fetched history", () => {
  const result = calcBBandsBO(
    Array.from({ length: 27 }, (_, index) => 100 + index),
  );

  assert.ok(result);
  assert.equal(result.trend, "bullish");
  assert.equal(result.breakoutStartAt, null);
});

function istTimestamp(year, month, day, hour, minute = 0, second = 0) {
  return Date.UTC(year, month - 1, day, hour, minute, second) - 5.5 * 60 * 60 * 1000;
}

test("holds a five-minute alert until the candle's close time", () => {
  const candle = istTimestamp(2026, 10, 6, 9, 15);

  assert.equal(isCandleClosed(candle, "5m", istTimestamp(2026, 10, 6, 9, 19, 59)), false);
  assert.equal(isCandleClosed(candle, "5m", istTimestamp(2026, 10, 6, 9, 20)), true);
});

test("holds fifteen-minute and hourly alerts until their candle closes", () => {
  const candle = istTimestamp(2026, 10, 6, 9, 15);

  assert.equal(isCandleClosed(candle, "15m", istTimestamp(2026, 10, 6, 9, 29, 59)), false);
  assert.equal(isCandleClosed(candle, "15m", istTimestamp(2026, 10, 6, 9, 30)), true);
  assert.equal(isCandleClosed(candle, "1h", istTimestamp(2026, 10, 6, 10, 14, 59)), false);
  assert.equal(isCandleClosed(candle, "1h", istTimestamp(2026, 10, 6, 10, 15)), true);
});

test("holds a daily alert until the NSE session closes", () => {
  const candle = istTimestamp(2026, 10, 6, 0, 0);

  assert.equal(isCandleClosed(candle, "1d", istTimestamp(2026, 10, 6, 15, 29)), false);
  assert.equal(isCandleClosed(candle, "1d", istTimestamp(2026, 10, 6, 15, 30)), true);
});

test("holds weekly and monthly alerts through their active periods", () => {
  const weeklyCandle = istTimestamp(2026, 10, 5, 0, 0);
  const monthlyCandle = istTimestamp(2026, 10, 1, 0, 0);

  assert.equal(
    isCandleClosed(weeklyCandle, "1wk", istTimestamp(2026, 10, 9, 15, 29)),
    false,
  );
  assert.equal(
    isCandleClosed(weeklyCandle, "1wk", istTimestamp(2026, 10, 9, 15, 30)),
    true,
  );
  assert.equal(
    isCandleClosed(monthlyCandle, "1mo", istTimestamp(2026, 10, 31, 23, 59)),
    false,
  );
  assert.equal(
    isCandleClosed(monthlyCandle, "1mo", istTimestamp(2026, 11, 1, 0, 0)),
    true,
  );
});
