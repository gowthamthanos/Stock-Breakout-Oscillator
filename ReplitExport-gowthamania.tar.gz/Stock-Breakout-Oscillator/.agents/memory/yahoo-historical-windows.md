---
name: Yahoo historical windows
description: Durable constraints when fetching Indian stock candles from Yahoo Finance for interval-based indicators.
---

Yahoo Finance candle availability is based on calendar time, not trading sessions. Intraday calculations can return too few valid candles when the lookback crosses weekends, exchange holidays, or includes an incomplete current candle.

**Why:** A nominal five-day 1-hour window produced fewer than the 20 candles required by the Bollinger calculation, making an entire large-stock scan appear empty.

**How to apply:** Choose a wider minimum window for each intraday interval, filter null current candles, merge Yahoo quote metadata into the active chart period when the chart endpoint lags, and share/cache identical concurrent basket requests so scan and summary endpoints do not independently trigger Yahoo throttling.