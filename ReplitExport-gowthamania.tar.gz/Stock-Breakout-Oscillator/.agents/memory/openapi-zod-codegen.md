---
name: OpenAPI Zod codegen compatibility
description: Compatibility constraint between the workspace OpenAPI generator and its installed Zod version.
---

When adding integer-valued fields to the OpenAPI contract, prefer a numeric schema with explicit whole-number validation in the server when the generated Zod client does not support the generator's `z.int()` output.

**Why:** The installed Zod version failed code generation for an OpenAPI `integer` field because Orval emitted `z.int()`, which that version does not expose.

**How to apply:** Check generated schemas after contract changes and run the API-spec codegen plus workspace typechecks before restarting services.