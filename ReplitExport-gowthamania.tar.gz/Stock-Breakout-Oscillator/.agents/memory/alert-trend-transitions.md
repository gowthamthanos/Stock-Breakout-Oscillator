---
name: Alert trend transitions
description: Product rule for bullish and bearish breakout alert timing and lifecycle notifications.
---

The screener and alerts must match the published LuxAlgo BBands BO indicator, not a generic Bollinger threshold classifier. Breakout alerts follow the latched color: a green bullish line remains active through neutral/intermediate candles until a red bearish line appears, and vice versa. Notify only when the opposing color line appears; a flip notifies the new direction and closes the prior event at the new line's timestamp. Do not notify at every refresh or send a separate end alert. The first poll establishes a baseline rather than treating an already-active color as a new line. Alert calculations must exclude the still-forming candle and wait until the configured interval closes before confirming a transition.

**Why:** The prior generic oscillator produced bullish/bearish timing that disagreed with the chart. Users want alerts to match the indicator's green/red trend line, not temporary candle-by-candle classifications or a fake start/end at the same time.

**How to apply:** Keep the last observed color per alert and symbol. Ignore null/intermediate signal states while a color is latched. Browser and Telegram alerts are sent only when the observed color changes on closed candles; record the prior trend end at the opposing line's timestamp. Keep the screener's live-candle behavior separate from the alert confirmation path. When a chart timestamp differs, compare the same interval and data feed before changing the calculation.