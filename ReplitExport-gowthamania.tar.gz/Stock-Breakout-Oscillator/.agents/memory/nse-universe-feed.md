---
name: NSE universe feed
description: Source and fallback policy for the live Indian stock universe
---

Use the official NSE equity listing CSV as the live source for NSE symbols and listing dates. Derive recent IPO groups from the listing date instead of maintaining only a manually curated list, and retain a curated fallback for feed outages.

**Why:** The exchange feed provides the current listed universe and automatically captures new listings, while Yahoo may omit individual symbols with no usable historical candles.

**How to apply:** Keep broad universe discovery separate from Yahoo historical-data availability; skip unavailable symbols during scans rather than treating them as valid empty results.