---
name: Telegram chat resolution
description: Avoid Telegram Bot API getUpdates conflicts during concurrent alert sends.
---

Telegram's long-polling `getUpdates` call conflicts with another active poller using the same bot token. Category alerts can trigger many sends concurrently, so each message must not independently poll to resolve the chat. Cache the resolved chat, share an in-flight lookup, and serialize outbound messages.

**Why:** Real Telegram alert attempts failed with `Conflict: terminated by other getUpdates request` when status checks and alert fan-out overlapped.

**How to apply:** Keep a single in-process chat lookup promise and return cached chat data on subsequent sends. Queue sendMessage calls; do not poll getUpdates for every alert.
