---
name: Breakout alert windows
description: How bullish and bearish breakout timestamps should be represented across screener intervals.
---

Expose both the first and latest candle of the current contiguous breakout run. Keep the legacy breakout timestamp as an alias of the start for older consumers.

**Why:** A single breakout timestamp cannot show how long an active signal has persisted, and alert events need their end point refreshed as later candles remain in the same breakout state.

**How to apply:** Calculate the window from the selected interval's signal sequence, return it for every symbol category including indices, and update active local alert events without creating duplicate notifications.