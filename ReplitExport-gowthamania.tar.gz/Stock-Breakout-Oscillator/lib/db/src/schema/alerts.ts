import { sql } from "drizzle-orm";
import {
  bigint,
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export type AlertTrend = "bullish" | "bearish" | null;

export const alertMonitorsTable = pgTable(
  "alert_monitors",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull(),
    label: text("label").notNull(),
    symbol: text("symbol"),
    preset: text("preset"),
    presetName: text("preset_name"),
    interval: text("interval").notNull(),
    period: integer("period").notNull(),
    stdDev: real("std_dev").notNull(),
    direction: text("direction").notNull(),
    telegramEnabled: boolean("telegram_enabled").notNull().default(true),
    enabled: boolean("enabled").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
    trendStates: jsonb("trend_states")
      .$type<Record<string, AlertTrend>>()
      .notNull()
      .default(sql`'{}'::jsonb`),
    lastTriggeredAt: timestamp("last_triggered_at", { withTimezone: true }),
    lastTriggeredSymbol: text("last_triggered_symbol"),
    lastTriggeredOscillator: real("last_triggered_oscillator"),
    lastScanAt: timestamp("last_scan_at", { withTimezone: true }),
    lastScanError: text("last_scan_error"),
  },
  (table) => [
    index("alert_monitors_user_active_idx").on(table.userId, table.deletedAt, table.enabled),
  ],
);

export const alertEventsTable = pgTable(
  "alert_events",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull(),
    alertId: text("alert_id").notNull(),
    alertLabel: text("alert_label").notNull(),
    symbol: text("symbol").notNull(),
    direction: text("direction").notNull(),
    eventType: text("event_type").notNull(),
    signal: text("signal").notNull(),
    oscillatorValue: real("oscillator_value").notNull(),
    interval: text("interval").notNull(),
    period: integer("period").notNull(),
    stdDev: real("std_dev").notNull(),
    breakoutAt: timestamp("breakout_at", { withTimezone: true }),
    breakoutStartAt: timestamp("breakout_start_at", { withTimezone: true }),
    breakoutEndAt: timestamp("breakout_end_at", { withTimezone: true }),
    telegramStatus: text("telegram_status"),
    telegramError: text("telegram_error"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("alert_events_user_created_idx").on(table.userId, table.createdAt),
    index("alert_events_monitor_symbol_idx").on(table.alertId, table.symbol, table.createdAt),
  ],
);

export const userTelegramChatsTable = pgTable("user_telegram_chats", {
  userId: text("user_id").primaryKey(),
  chatId: text("chat_id").notNull(),
  chatLabel: text("chat_label"),
  username: text("username"),
  linkedAt: timestamp("linked_at", { withTimezone: true }).notNull().defaultNow(),
});

export const telegramLinkCodesTable = pgTable(
  "telegram_link_codes",
  {
    code: text("code").primaryKey(),
    userId: text("user_id").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    claimedAt: timestamp("claimed_at", { withTimezone: true }),
  },
  (table) => [index("telegram_link_codes_user_idx").on(table.userId)],
);

export const telegramPollingStateTable = pgTable("telegram_polling_state", {
  id: integer("id").primaryKey().default(1),
  nextUpdateId: bigint("next_update_id", { mode: "number" }).notNull().default(0),
});
