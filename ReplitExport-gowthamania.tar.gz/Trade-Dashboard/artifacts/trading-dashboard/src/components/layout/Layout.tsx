import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  Activity, 
  LayoutDashboard, 
  LineChart, 
  Code2, 
  List, 
  Filter, 
  BellRing,
  BookOpen,
  Menu,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

interface NavItem {
  title: string;
  href: string;
  icon: React.ElementType;
}

const navItems: NavItem[] = [
  { title: "Dashboard Overview", href: "/", icon: LayoutDashboard },
  { title: "Chart Layout", href: "/chart-layout", icon: LineChart },
  { title: "Pine Script", href: "/pine-script", icon: Code2 },
  { title: "Watchlist", href: "/watchlist", icon: List },
  { title: "Screener", href: "/screener", icon: Filter },
  { title: "Alerts", href: "/alerts", icon: BellRing },
  { title: "Trade Journal", href: "/journal", icon: BookOpen },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const toggleMobile = () => setMobileOpen(!mobileOpen);

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden text-foreground selection:bg-primary/30">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-64 border-r border-border bg-card/50">
        <div className="p-4 border-b border-border flex items-center gap-2">
          <Activity className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg tracking-tight">NSE TERMINAL</span>
        </div>
        <ScrollArea className="flex-1 py-4">
          <nav className="grid gap-1 px-2">
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <Link key={item.href} href={item.href}>
                  <div
                    className={cn(
                      "flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer",
                      isActive 
                        ? "bg-primary/10 text-primary" 
                        : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                    )}
                  >
                    <item.icon className="h-4 w-4" />
                    {item.title}
                  </div>
                </Link>
              );
            })}
          </nav>
        </ScrollArea>
        <div className="p-4 border-t border-border text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
            LIVE • NSE/BSE
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-14 border-b border-border bg-background z-50 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-primary" />
          <span className="font-bold">NSE TERMINAL</span>
        </div>
        <Button variant="ghost" size="icon" onClick={toggleMobile}>
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 top-14 bg-background z-40 border-t border-border">
          <nav className="grid gap-2 p-4">
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <Link key={item.href} href={item.href}>
                  <div
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      "flex items-center gap-3 px-4 py-3 rounded-md text-base font-medium transition-colors cursor-pointer",
                      isActive 
                        ? "bg-primary/10 text-primary border border-primary/20" 
                        : "text-muted-foreground bg-card border border-border"
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    {item.title}
                  </div>
                </Link>
              );
            })}
          </nav>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 md:pt-0 pt-14 h-full overflow-hidden">
        {/* Top bar */}
        <header className="h-14 hidden md:flex items-center justify-end px-6 border-b border-border bg-card/30">
          <div className="text-xs text-muted-foreground font-mono flex items-center gap-4">
            <span>Market Open: 09:15</span>
            <span>Market Close: 15:30</span>
            <span className="px-2 py-1 bg-secondary rounded text-foreground">Last updated: Market Open Today</span>
          </div>
        </header>
        
        <ScrollArea className="flex-1 p-4 md:p-6 lg:p-8">
          <div className="max-w-6xl mx-auto pb-12">
            {children}
          </div>
        </ScrollArea>
      </main>
    </div>
  );
}
