import React, { useEffect } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import Layout from "@/components/layout/Layout";
import Dashboard from "@/pages/Dashboard";
import ChartLayout from "@/pages/ChartLayout";
import PineScript from "@/pages/PineScript";
import Watchlist from "@/pages/Watchlist";
import Screener from "@/pages/Screener";
import Alerts from "@/pages/Alerts";
import TradeJournal from "@/pages/TradeJournal";

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/chart-layout" component={ChartLayout} />
        <Route path="/pine-script" component={PineScript} />
        <Route path="/watchlist" component={Watchlist} />
        <Route path="/screener" component={Screener} />
        <Route path="/alerts" component={Alerts} />
        <Route path="/journal" component={TradeJournal} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  // Force dark mode
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
