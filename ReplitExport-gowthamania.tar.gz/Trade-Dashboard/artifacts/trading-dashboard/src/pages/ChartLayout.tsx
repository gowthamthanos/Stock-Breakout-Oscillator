import React from "react";
import { LayoutTemplate, Settings, Save, Link2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function ChartLayout() {
  return (
    <div className="space-y-6">
      <header className="pb-4 border-b border-border">
        <h1 className="text-3xl font-bold tracking-tight">Chart Layout Blueprint</h1>
        <p className="text-muted-foreground mt-1 text-sm">Recommended 4-chart TradingView setup for precision execution</p>
      </header>

      {/* Blueprint Diagram */}
      <section className="bg-card border border-border rounded-xl p-4 md:p-6">
        <div className="flex items-center gap-2 mb-4 text-sm font-medium text-muted-foreground uppercase tracking-wider">
          <LayoutTemplate className="h-4 w-4" /> Visual Mockup
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-auto lg:h-[600px]">
          {/* Main Chart - Left 2 columns */}
          <div className="lg:col-span-2 flex flex-col gap-4">
            <div className="flex-1 bg-secondary/30 border border-border rounded-lg p-4 flex flex-col relative overflow-hidden group">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-blue-500"></div>
              <div className="flex justify-between items-start mb-auto">
                <Badge variant="outline" className="bg-background/80 font-mono">Chart 1: Primary (5-min)</Badge>
                <div className="flex gap-1">
                  <Badge variant="secondary" className="text-[10px]">VWAP</Badge>
                  <Badge variant="secondary" className="text-[10px]">BB</Badge>
                  <Badge variant="secondary" className="text-[10px]">RSI</Badge>
                </div>
              </div>
              <div className="text-center text-muted-foreground mt-8">
                <div className="text-xl font-bold mb-2">Main Trading Timeframe</div>
                <p className="text-sm max-w-sm mx-auto">Used for executing entries, reading price action, and managing active trades.</p>
              </div>
              <div className="mt-auto pt-4 flex justify-between items-center text-xs text-muted-foreground border-t border-border/50">
                <span className="flex items-center gap-1"><Link2 className="h-3 w-3"/> Symbol Sync On</span>
                <span>Crosshair Sync On</span>
              </div>
            </div>

            <div className="h-[200px] bg-secondary/20 border border-border rounded-lg p-4 flex flex-col relative">
              <div className="flex justify-between items-start mb-auto">
                <Badge variant="outline" className="bg-background/80 font-mono">Chart 3: Precision (1-min)</Badge>
              </div>
              <div className="text-center text-muted-foreground my-auto">
                <div className="font-semibold text-sm mb-1">Entry / Exit Precision</div>
                <p className="text-xs">Zoom in on key levels</p>
              </div>
              <div className="mt-auto flex justify-between items-center text-[10px] text-muted-foreground border-t border-border/50 pt-2">
                <span className="flex items-center gap-1"><Link2 className="h-3 w-3"/> Symbol Sync On</span>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="flex flex-col gap-4">
            <div className="flex-1 bg-secondary/20 border border-border rounded-lg p-4 flex flex-col relative">
              <div className="flex justify-between items-start mb-auto">
                <Badge variant="outline" className="bg-background/80 font-mono">Chart 2: Trend (15-min)</Badge>
                <Badge variant="secondary" className="text-[10px]">9 EMA</Badge>
              </div>
              <div className="text-center text-muted-foreground my-auto">
                <div className="font-semibold mb-1">Trend Direction</div>
                <p className="text-xs">Confirm broader intraday structure before entry</p>
              </div>
              <div className="mt-auto flex justify-between items-center text-[10px] text-muted-foreground border-t border-border/50 pt-2">
                <span className="flex items-center gap-1"><Link2 className="h-3 w-3"/> Symbol Sync On</span>
              </div>
            </div>

            <div className="flex-1 bg-secondary/10 border border-border rounded-lg p-4 flex flex-col relative">
              <div className="flex justify-between items-start mb-auto">
                <Badge variant="outline" className="bg-background/80 font-mono text-muted-foreground">Chart 4: Context (Daily)</Badge>
              </div>
              <div className="text-center text-muted-foreground my-auto">
                <div className="font-semibold mb-1">Broader Context</div>
                <p className="text-xs">Key swing levels, PDH/PDL, support/resistance</p>
              </div>
              <div className="mt-auto flex justify-between items-center text-[10px] text-muted-foreground border-t border-border/50 pt-2">
                <span className="flex items-center gap-1"><Link2 className="h-3 w-3"/> Symbol Sync On</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Setup Guide */}
      <Card className="bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Settings className="h-5 w-5 text-primary" /> Setup Instructions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="space-y-4 text-sm text-foreground/90">
            <li className="flex items-start gap-3">
              <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded bg-secondary text-primary font-mono font-bold text-xs">1</span>
              <div>
                <strong className="text-foreground">Add Layout:</strong> Open TradingView → Click the grid icon top right → Select "4 Charts" (1 left large, 3 right, or 2x2).
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded bg-secondary text-primary font-mono font-bold text-xs">2</span>
              <div>
                <strong className="text-foreground">Lock Symbol Sync:</strong> Click the chain-link icon in the layout menu. Ensure "Symbol" is checked so all charts update when you change tickers.
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded bg-secondary text-primary font-mono font-bold text-xs">3</span>
              <div>
                <strong className="text-foreground">Enable Crosshair Sync:</strong> Chart Settings → Crosshair → Sync across all charts. This lets you inspect the exact same moment across all timeframes.
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded bg-secondary text-primary font-mono font-bold text-xs">4</span>
              <div>
                <strong className="text-foreground">Apply Templates:</strong> Save your indicator sets as templates. Apply the full VWAP/BB/RSI to Chart 1. Keep Charts 2-4 clean with only essential EMAs.
              </div>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex-shrink-0 flex items-center justify-center h-6 w-6 rounded bg-primary/20 text-primary font-mono font-bold text-xs"><Save className="h-3 w-3" /></span>
              <div>
                <strong className="text-primary">Save Work:</strong> Press <kbd className="bg-secondary px-1 py-0.5 rounded text-xs">Ctrl+S</kbd> (Cmd+S) and name it "NSE Day Trading Setup".
              </div>
            </li>
          </ol>
        </CardContent>
      </Card>
    </div>
  );
}
