import React from "react";
import { Layers, Zap, RotateCcw, CalendarClock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function Watchlist() {
  return (
    <div className="space-y-6">
      <header className="pb-4 border-b border-border">
        <h1 className="text-3xl font-bold tracking-tight">Watchlist Framework</h1>
        <p className="text-muted-foreground mt-1 text-sm">Organized lists with specific custom columns for day trading context</p>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        
        {/* Watchlist 1 */}
        <Card className="bg-card">
          <CardHeader className="pb-3 border-b border-border/50">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2 text-blue-400">
                <Layers className="h-5 w-5" /> NSE F&O Heavyweights
              </CardTitle>
              <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/20">Always Watch</Badge>
            </div>
            <CardDescription className="pt-2">
              <div className="flex flex-wrap gap-1.5">
                {["RELIANCE", "HDFCBANK", "INFY", "TCS", "ICICIBANK", "SBIN", "BAJFINANCE"].map(s => (
                  <Badge key={s} variant="secondary" className="font-mono text-xs">{s}</Badge>
                ))}
              </div>
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Custom Columns Required</h4>
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent border-border/50">
                  <TableHead className="h-8 text-xs">LTP</TableHead>
                  <TableHead className="h-8 text-xs">Chg%</TableHead>
                  <TableHead className="h-8 text-xs">Vol</TableHead>
                  <TableHead className="h-8 text-xs text-primary">Rel Vol</TableHead>
                  <TableHead className="h-8 text-xs">ATR(14)</TableHead>
                  <TableHead className="h-8 text-xs">VWAP Dist%</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow className="hover:bg-transparent border-0 opacity-50">
                  <TableCell className="py-2 text-xs font-mono">1450.2</TableCell>
                  <TableCell className="py-2 text-xs font-mono text-primary">+1.2%</TableCell>
                  <TableCell className="py-2 text-xs font-mono">2.4M</TableCell>
                  <TableCell className="py-2 text-xs font-mono text-primary">2.1x</TableCell>
                  <TableCell className="py-2 text-xs font-mono">18.5</TableCell>
                  <TableCell className="py-2 text-xs font-mono">+0.5%</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Watchlist 2 */}
        <Card className="bg-card border-primary/20">
          <CardHeader className="pb-3 border-b border-border/50">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2 text-primary">
                <Zap className="h-5 w-5" /> Day Trade Momentum
              </CardTitle>
              <Badge className="bg-primary text-primary-foreground">Active Intraday</Badge>
            </div>
            <CardDescription className="pt-2 text-sm text-muted-foreground">
              Rotate daily based on premarket screener results. Only keep 5-8 highly active stocks.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Custom Columns Required</h4>
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent border-border/50">
                  <TableHead className="h-8 text-xs">LTP</TableHead>
                  <TableHead className="h-8 text-xs">Gap%</TableHead>
                  <TableHead className="h-8 text-xs text-primary">5m RVOL</TableHead>
                  <TableHead className="h-8 text-xs">RSI(14)</TableHead>
                  <TableHead className="h-8 text-xs">VWAP Dist</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow className="hover:bg-transparent border-0 opacity-50">
                  <TableCell className="py-2 text-xs font-mono">890.5</TableCell>
                  <TableCell className="py-2 text-xs font-mono text-primary">+2.4%</TableCell>
                  <TableCell className="py-2 text-xs font-mono text-primary">4.5x</TableCell>
                  <TableCell className="py-2 text-xs font-mono">68.2</TableCell>
                  <TableCell className="py-2 text-xs font-mono">+1.1%</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Watchlist 3 */}
        <Card className="bg-card">
          <CardHeader className="pb-3 border-b border-border/50">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2 text-purple-400">
                <RotateCcw className="h-5 w-5" /> Sector Rotators
              </CardTitle>
              <Badge variant="outline" className="bg-purple-500/10 text-purple-400 border-purple-500/20">Context</Badge>
            </div>
            <CardDescription className="pt-2">
              <div className="flex flex-wrap gap-1.5">
                {["NIFTY IT", "NIFTY BANK", "NIFTY AUTO", "NIFTY PHARMA"].map(s => (
                  <Badge key={s} variant="secondary" className="font-mono text-xs">{s}</Badge>
                ))}
              </div>
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Custom Columns Required</h4>
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent border-border/50">
                  <TableHead className="h-8 text-xs">1D%</TableHead>
                  <TableHead className="h-8 text-xs">5D%</TableHead>
                  <TableHead className="h-8 text-xs">1M%</TableHead>
                  <TableHead className="h-8 text-xs">52W High%</TableHead>
                  <TableHead className="h-8 text-xs text-primary">RS vs Nifty</TableHead>
                </TableRow>
              </TableHeader>
            </Table>
          </CardContent>
        </Card>

        {/* Watchlist 4 */}
        <Card className="bg-card">
          <CardHeader className="pb-3 border-b border-border/50">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2 text-amber-500">
                <CalendarClock className="h-5 w-5" /> F&O Expiry Watch
              </CardTitle>
              <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">Weekly</Badge>
            </div>
            <CardDescription className="pt-2 text-sm text-muted-foreground">
              Top 10 stocks with highest OI buildup for the current expiry week.
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Custom Columns Required</h4>
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent border-border/50">
                  <TableHead className="h-8 text-xs">LTP</TableHead>
                  <TableHead className="h-8 text-xs">PCR</TableHead>
                  <TableHead className="h-8 text-xs text-primary">Max Pain</TableHead>
                  <TableHead className="h-8 text-xs">OI Change</TableHead>
                  <TableHead className="h-8 text-xs">IV%</TableHead>
                </TableRow>
              </TableHeader>
            </Table>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
