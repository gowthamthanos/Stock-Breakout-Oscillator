import { useState } from "react";
import { Terminal, Copy, Check, Info, Zap, TrendingUp, BarChart2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const scriptCode = `//@version=5
indicator("BBands BO [LuxAlgo]", shorttitle="BBands BO", overlay=true, max_bars_back=500)

// ─── INPUTS ──────────────────────────────────────────────────────────────────
length      = input.int(20,    "BB Length",          minval=1,   group="Bollinger Bands")
mult        = input.float(2.0, "BB Multiplier",      minval=0.1, group="Bollinger Bands", step=0.1)
src         = input.source(close, "Source",                      group="Bollinger Bands")

show_signals = input.bool(true,  "Show Breakout Signals", group="Display")
show_labels  = input.bool(true,  "Show Labels",            group="Display")
bull_col     = input.color(color.new(#00e676, 0),  "Bullish Color", group="Colors")
bear_col     = input.color(color.new(#ff1744, 0),  "Bearish Color", group="Colors")
band_col     = input.color(color.new(#90a4ae, 60), "Band Color",    group="Colors")

// ─── BOLLINGER BANDS CALCULATION ─────────────────────────────────────────────
basis     = ta.sma(src, length)
deviation = ta.stdev(src, length)
upper     = basis + mult * deviation
lower     = basis - mult * deviation

// ─── BREAKOUT DETECTION ──────────────────────────────────────────────────────
// A breakout occurs when close crosses outside the band
bull_bo   = ta.crossover(close, upper)   // Bullish breakout — close crosses above upper band
bear_bo   = ta.crossunder(close, lower)  // Bearish breakout — close crosses below lower band

// ─── BAND WIDTH (Squeeze detection) ──────────────────────────────────────────
bw        = (upper - lower) / basis * 100
bw_avg    = ta.sma(bw, 50)
squeeze   = bw < bw_avg * 0.75           // Band width below 75% of 50-bar avg = squeeze

// ─── TREND STATE ─────────────────────────────────────────────────────────────
var int trend = 0
if bull_bo
    trend := 1
if bear_bo
    trend := -1

// ─── PLOTS ───────────────────────────────────────────────────────────────────
upper_color = trend ==  1 ? bull_col : trend == -1 ? bear_col : band_col
lower_color = trend == -1 ? bear_col : trend ==  1 ? bull_col : band_col

p_upper = plot(upper, "Upper Band", color=upper_color, linewidth=2)
p_basis = plot(basis, "Basis",      color=color.new(#eceff1, 40), linewidth=1, style=plot.style_line)
p_lower = plot(lower, "Lower Band", color=lower_color, linewidth=2)

fill(p_upper, p_lower,
     color=trend == 1  ? color.new(bull_col, 92) :
           trend == -1 ? color.new(bear_col, 92) :
                         color.new(#90a4ae, 95),
     title="Band Fill")

// ─── BREAKOUT SIGNALS ────────────────────────────────────────────────────────
plotshape(show_signals and bull_bo,
     title="Bull Breakout",
     style=shape.diamond,
     location=location.belowbar,
     color=bull_col,
     size=size.small)

plotshape(show_signals and bear_bo,
     title="Bear Breakout",
     style=shape.diamond,
     location=location.abovebar,
     color=bear_col,
     size=size.small)

// ─── LABELS ──────────────────────────────────────────────────────────────────
if show_labels and bull_bo
    label.new(bar_index, low - ta.atr(14),
         text="BO ▲",
         style=label.style_label_up,
         color=color.new(bull_col, 20),
         textcolor=color.white,
         size=size.small)

if show_labels and bear_bo
    label.new(bar_index, high + ta.atr(14),
         text="BO ▼",
         style=label.style_label_down,
         color=color.new(bear_col, 20),
         textcolor=color.white,
         size=size.small)

// ─── SQUEEZE BACKGROUND ──────────────────────────────────────────────────────
bgcolor(squeeze ? color.new(#ffd600, 96) : na, title="Squeeze Zone")

// ─── ALERTS ──────────────────────────────────────────────────────────────────
alertcondition(bull_bo, title="Bullish Breakout",  message="BBands BO: Bullish breakout on {{ticker}} — {{close}}")
alertcondition(bear_bo, title="Bearish Breakout",  message="BBands BO: Bearish breakout on {{ticker}} — {{close}}")
alertcondition(squeeze, title="Squeeze Detected",  message="BBands BO: Squeeze on {{ticker}} — breakout incoming")`;

export default function PineScript() {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(scriptCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="space-y-6">
      <header className="pb-4 border-b border-border flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl font-bold tracking-tight">BBands BO</h1>
            <Badge variant="outline" className="text-[10px] font-mono border-primary/30 text-primary bg-primary/10">LuxAlgo Style</Badge>
          </div>
          <p className="text-muted-foreground text-sm">Bollinger Bands Breakout indicator — detects band breakouts, squeeze zones, and labels every signal directly on chart.</p>
        </div>
      </header>

      {/* Code Block */}
      <div className="relative rounded-lg overflow-hidden border border-border bg-[#0d1117]">
        <div className="flex items-center justify-between px-4 py-2 bg-[#161b22] border-b border-[#30363d]">
          <div className="flex items-center gap-2 text-xs font-mono text-[#8b949e]">
            <Terminal className="h-3.5 w-3.5" />
            <span>bbands_bo_luxalgo.pine</span>
            <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#21262d] border border-[#30363d]">Pine Script v5</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs font-mono text-[#8b949e] hover:text-white hover:bg-[#21262d]"
            onClick={handleCopy}
            data-testid="button-copy-pine"
          >
            {copied ? <Check className="h-3 w-3 mr-1 text-emerald-400" /> : <Copy className="h-3 w-3 mr-1" />}
            {copied ? "COPIED!" : "COPY"}
          </Button>
        </div>
        <pre className="p-5 text-[13px] font-mono overflow-x-auto leading-relaxed">
          <code>
            {scriptCode.split("\n").map((line, i) => {
              const isComment = line.trim().startsWith("//");
              const isSection = line.includes("─────") || line.includes("─────────────────");
              const isKeyword = /^\s*(var|if|else|for|while|import|export|true|false|na|barstate|bar_index)\b/.test(line);
              return (
                <span key={i} className="block">
                  {isComment || isSection ? (
                    <span className="text-[#6e7681]">{line}</span>
                  ) : (
                    <span className="text-[#79c0ff]">{line}</span>
                  )}
                </span>
              );
            })}
          </code>
        </pre>
      </div>

      {/* How It Works — 3 cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-card border-l-4 border-l-emerald-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-emerald-400 flex items-center gap-2">
              <Zap className="h-4 w-4" /> Breakout Detection
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <p>A <strong className="text-foreground">bullish breakout</strong> fires when close crosses <em>above</em> the upper band.</p>
            <p>A <strong className="text-foreground">bearish breakout</strong> fires when close crosses <em>below</em> the lower band.</p>
            <p>Diamond shapes and <strong className="text-emerald-400">BO ▲ / BO ▼</strong> labels mark every signal directly on the candle.</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-l-4 border-l-amber-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-amber-400 flex items-center gap-2">
              <BarChart2 className="h-4 w-4" /> Squeeze Zones
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <p>A <strong className="text-amber-400">yellow background</strong> appears when band width drops below 75% of its 50-bar average — indicating a squeeze.</p>
            <p>Squeezes precede sharp moves. Wait for a confirmed breakout candle <em>after</em> the squeeze resolves before entering.</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-l-4 border-l-blue-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-blue-400 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" /> Band Color = Trend State
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <p><strong className="text-emerald-400">Green bands</strong> = Bullish trend active after a bull breakout.</p>
            <p><strong className="text-rose-400">Red bands</strong> = Bearish trend active after a bear breakout.</p>
            <p>Band fill color switches accordingly — no ambiguity on trend direction at a glance.</p>
          </CardContent>
        </Card>
      </div>

      {/* Day Trading Usage for NSE */}
      <Card className="bg-secondary/10 border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Info className="h-4 w-4 text-primary" /> How to use on NSE 5-min chart
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="list-decimal list-inside space-y-3 text-sm text-muted-foreground ml-2">
            <li>Open TradingView → Pine Script Editor (bottom panel). Paste the code and click <strong className="text-foreground">Add to chart</strong>.</li>
            <li>Apply on your <strong className="text-foreground">5-min primary chart</strong>. Set length=20, mult=2.0 (defaults are optimised for NSE).</li>
            <li>Wait for a <strong className="text-amber-400">yellow squeeze zone</strong> to form — price is coiling for a move.</li>
            <li>Enter on the first <strong className="text-foreground">BO ▲ or BO ▼</strong> label that prints <em>after</em> the squeeze ends, with volume confirmation.</li>
            <li>Target the opposite band or VWAP. Stop below/above the basis line (middle band).</li>
            <li>Enable the built-in <strong className="text-foreground">alerts</strong> ("Bullish Breakout", "Bearish Breakout", "Squeeze Detected") so you never miss a setup.</li>
          </ol>
        </CardContent>
      </Card>
    </div>
  );
}
