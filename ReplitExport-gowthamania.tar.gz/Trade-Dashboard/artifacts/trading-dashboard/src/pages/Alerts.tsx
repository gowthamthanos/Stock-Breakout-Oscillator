import React from "react";
import { Bell, Activity, ArrowDownUp, Minimize, BarChart2, Hash, ShieldAlert } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Alerts() {
  return (
    <div className="space-y-6">
      <header className="pb-4 border-b border-border">
        <h1 className="text-3xl font-bold tracking-tight">Alert Configurations</h1>
        <p className="text-muted-foreground mt-1 text-sm">Systematic triggers to prevent screen fatigue</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Cat 1 */}
        <Card className="bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2 text-yellow-500">
              <ArrowDownUp className="h-4 w-4" /> VWAP Cross Alerts (Priority)
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <AlertItem 
              condition="Price crosses above VWAP" 
              message="LONG BIAS: [SYMBOL] reclaimed VWAP" 
              setting="Once per bar close"
            />
            <AlertItem 
              condition="Price crosses below VWAP" 
              message="SHORT BIAS: [SYMBOL] lost VWAP" 
              setting="Once per bar close"
            />
            <AlertItem 
              condition="Price within 0.1% of VWAP" 
              message="VWAP Test incoming on [SYMBOL]" 
              setting="Once per bar close"
            />
          </CardContent>
        </Card>

        {/* Cat 2 */}
        <Card className="bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2 text-purple-400">
              <Activity className="h-4 w-4" /> RSI Extreme Alerts
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <AlertItem 
              condition="RSI crosses above 70" 
              message="[SYMBOL] RSI Overbought — watch reversal" 
              setting="Once per bar close (5m)"
            />
            <AlertItem 
              condition="RSI crosses below 30" 
              message="[SYMBOL] RSI Oversold — watch bounce" 
              setting="Once per bar close (5m)"
            />
            <AlertItem 
              condition="RSI crosses 50 upward" 
              message="[SYMBOL] RSI momentum shift BULLISH" 
              setting="Once per bar close (5m)"
            />
          </CardContent>
        </Card>

        {/* Cat 3 */}
        <Card className="bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2 text-blue-400">
              <Minimize className="h-4 w-4" /> Bollinger Band Squeeze
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <AlertItem 
              condition="BB Width < 0.5% price" 
              message="BB SQUEEZE: [SYMBOL] — breakout imminent" 
              setting="Once per bar close (15m)"
            />
            <AlertItem 
              condition="Price closes > upper BB" 
              message="BB BREAKOUT UP: [SYMBOL]" 
              setting="Once per bar close"
            />
          </CardContent>
        </Card>

        {/* Cat 4 */}
        <Card className="bg-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2 text-emerald-400">
              <BarChart2 className="h-4 w-4" /> Volume Spike
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <AlertItem 
              condition="Vol > 2x 20-bar avg" 
              message="VOLUME SPIKE on [SYMBOL]" 
              setting="Once per bar (Real-time)"
            />
            <AlertItem 
              condition="Vol > 5x avg" 
              message="UNUSUAL VOLUME on [SYMBOL]" 
              setting="Once per bar (Real-time)"
            />
          </CardContent>
        </Card>

      </div>

      {/* Cat 5 - Key Levels */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 text-foreground">
            <Hash className="h-4 w-4" /> Key Level Alerts (Manual)
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-3 bg-secondary/30 rounded border border-border">
            <div className="text-xs font-semibold text-primary mb-1">PDH BREAKOUT</div>
            <div className="text-sm text-muted-foreground">Price crosses above previous day high</div>
          </div>
          <div className="p-3 bg-secondary/30 rounded border border-border">
            <div className="text-xs font-semibold text-destructive mb-1">PDL BREAKDOWN</div>
            <div className="text-sm text-muted-foreground">Price crosses below previous day low</div>
          </div>
          <div className="p-3 bg-secondary/30 rounded border border-border">
            <div className="text-xs font-semibold text-blue-400 mb-1">ROUND NUMBERS</div>
            <div className="text-sm text-muted-foreground">Crosses 1000, 1500, 2000 etc.</div>
          </div>
        </CardContent>
      </Card>

      {/* Screen Fatigue Prevention */}
      <Card className="bg-primary/5 border-primary/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center gap-2 text-primary">
            <ShieldAlert className="h-5 w-5" /> Screen Fatigue Prevention
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm text-foreground/80 mt-2">
            <li className="flex items-center gap-2">
              <div className="h-1.5 w-1.5 rounded-full bg-primary" /> Group all alerts by ticker in TradingView Manager
            </li>
            <li className="flex items-center gap-2">
              <div className="h-1.5 w-1.5 rounded-full bg-primary" /> Use Telegram integration for mobile alerts (faster than email)
            </li>
            <li className="flex items-center gap-2">
              <div className="h-1.5 w-1.5 rounded-full bg-primary" /> Set "quiet hours" alerts off from 12:30-1:45 PM (dead zone)
            </li>
            <li className="flex items-center gap-2">
              <div className="h-1.5 w-1.5 rounded-full bg-primary" /> Max 15 active alerts at any time — quality over quantity
            </li>
            <li className="flex items-center gap-2">
              <div className="h-1.5 w-1.5 rounded-full bg-primary" /> Set all intraday alerts to expire at 3:30 PM daily
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

function AlertItem({ condition, message, setting }: { condition: string, message: string, setting: string }) {
  return (
    <div className="flex flex-col gap-1 border-l-2 border-border pl-3">
      <div className="text-sm font-medium">{condition}</div>
      <div className="text-xs font-mono text-muted-foreground bg-secondary/50 p-1.5 rounded inline-block w-fit">
        "{message}"
      </div>
      <div className="text-[10px] text-muted-foreground uppercase tracking-wide mt-1 flex items-center gap-1">
        <Bell className="h-3 w-3" /> {setting}
      </div>
    </div>
  );
}
