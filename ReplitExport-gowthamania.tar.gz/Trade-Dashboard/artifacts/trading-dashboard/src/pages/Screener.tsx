import React from "react";
import { Filter, Flame, TrendingDown, ArrowUpRight, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Screener() {
  return (
    <div className="space-y-6">
      <header className="pb-4 border-b border-border">
        <h1 className="text-3xl font-bold tracking-tight">Day Trading Screener</h1>
        <p className="text-muted-foreground mt-1 text-sm">TradingView scanner criteria for high-probability setups</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Set 1 */}
        <Card className="bg-card border-border/50">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle className="text-base text-primary flex items-center gap-2">
                <Flame className="h-5 w-5" /> Morning Breakout
              </CardTitle>
              <Badge variant="outline" className="font-mono text-[10px]">09:30 - 10:30</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 mt-2">
              <FilterItem text="Exchange: NSE" />
              <FilterItem text="Market Cap > 5000 Cr" />
              <FilterItem text="Volume > 2x 20D Avg (RVOL>2)" />
              <FilterItem text="Change % > 1.5% OR < -1.5%" />
              <FilterItem text="RSI(14) 5m: 55-75" />
              <FilterItem text="Price > VWAP" highlight />
              <FilterItem text="ATR% > 1.5" />
            </ul>
          </CardContent>
        </Card>

        {/* Set 2 */}
        <Card className="bg-card border-border/50">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle className="text-base text-blue-400 flex items-center gap-2">
                <TrendingDown className="h-5 w-5" /> VWAP Reversal
              </CardTitle>
              <Badge variant="outline" className="font-mono text-[10px]">10:30 - 12:30</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 mt-2">
              <FilterItem text="Exchange: NSE" />
              <FilterItem text="Price within 0.3% of VWAP" highlight />
              <FilterItem text="RSI(14): 40-60 (Coiled)" />
              <FilterItem text="Last Candle Vol > 1.5x Avg" />
              <FilterItem text="15-min Trend: Bullish (Price > 9 EMA)" />
            </ul>
          </CardContent>
        </Card>

        {/* Set 3 */}
        <Card className="bg-card border-border/50">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <CardTitle className="text-base text-purple-400 flex items-center gap-2">
                <ArrowUpRight className="h-5 w-5" /> Pre-Close Momentum
              </CardTitle>
              <Badge variant="outline" className="font-mono text-[10px]">14:00 - 15:00</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 mt-2">
              <FilterItem text="Exchange: NSE" />
              <FilterItem text="Price = New Day High OR Low" highlight />
              <FilterItem text="Vol Last Hour > 30% Total Vol" />
              <FilterItem text="RSI(14) 15m: >60 or <40" />
              <FilterItem text="F&O Stocks Only" />
            </ul>
          </CardContent>
        </Card>

      </div>

      <Card className="bg-secondary/20 border-amber-500/30">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2 text-amber-500">
            <AlertTriangle className="h-5 w-5" /> Pro Tips to Avoid False Signals
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-foreground/80">
            <li className="flex gap-2">
              <span className="text-destructive font-bold">×</span>
              <span>Never trade first 15 minutes (9:15-9:30) — avoid morning noise and fakeouts.</span>
            </li>
            <li className="flex gap-2">
              <span className="text-emerald-500 font-bold">✓</span>
              <span>Only take F&O stocks for day trading to ensure sufficient liquidity.</span>
            </li>
            <li className="flex gap-2">
              <span className="text-emerald-500 font-bold">✓</span>
              <span>Always check OI (Open Interest) data on NSE website before significant entry.</span>
            </li>
            <li className="flex gap-2">
              <span className="text-emerald-500 font-bold">✓</span>
              <span>Volume must confirm the price move. No volume = trap.</span>
            </li>
          </ul>
        </CardContent>
      </Card>

    </div>
  );
}

function FilterItem({ text, highlight = false }: { text: string, highlight?: boolean }) {
  return (
    <li className="flex items-center gap-2 text-sm">
      <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground" />
      <span className={highlight ? "text-primary font-medium" : "text-muted-foreground"}>
        {text}
      </span>
    </li>
  );
}
