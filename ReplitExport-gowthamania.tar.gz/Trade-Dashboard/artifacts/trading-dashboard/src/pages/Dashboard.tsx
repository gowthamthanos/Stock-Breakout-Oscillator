import React from "react";
import { ArrowUpRight, ArrowDownRight, Clock, Target, CalendarDays, CheckCircle2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-border">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Today's Game Plan</h1>
          <p className="text-muted-foreground mt-1 text-sm">Strategic overview and market context</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 px-3 py-1 text-sm font-mono">
            <span className="h-2 w-2 rounded-full bg-primary mr-2 animate-pulse"></span>
            NSE ACTIVE
          </Badge>
          <Badge variant="outline" className="text-muted-foreground font-mono text-xs">
            09:15 - 15:30 IST
          </Badge>
        </div>
      </header>

      {/* Market Context */}
      <section>
        <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <Target className="h-5 w-5 text-muted-foreground" /> Market Context
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <IndexCard
            name="NIFTY 50"
            value="24,853.15"
            change="+213.40"
            changePct="+0.87%"
            isPositive={true}
            progress={72}
            dayLow="24,598.50"
            dayHigh="24,891.30"
          />
          <IndexCard
            name="BANK NIFTY"
            value="55,342.80"
            change="+641.25"
            changePct="+1.17%"
            isPositive={true}
            progress={68}
            dayLow="54,710.00"
            dayHigh="55,490.60"
          />
          <IndexCard
            name="SENSEX"
            value="81,721.55"
            change="+698.40"
            changePct="+0.86%"
            isPositive={true}
            progress={70}
            dayLow="80,940.20"
            dayHigh="81,805.75"
          />
        </div>
      </section>

      {/* Session Timeline */}
      <section className="bg-card border border-border p-5 rounded-lg">
        <h2 className="text-sm font-medium text-muted-foreground mb-4 font-mono uppercase tracking-wider flex items-center gap-2">
          <Clock className="h-4 w-4" /> Market Session Timeline
        </h2>
        <div className="relative pt-6 pb-2">
          <div className="h-2 w-full bg-secondary rounded-full overflow-hidden flex">
            <div className="h-full bg-amber-500/50 w-[5%]" title="Pre-open"></div>
            <div className="h-full bg-primary w-[5%]" title="Opening"></div>
            <div className="h-full bg-primary/70 w-[15%]" title="Power Hour"></div>
            <div className="h-full bg-muted w-[50%]" title="Mid-session"></div>
            <div className="h-full bg-primary/70 w-[25%]" title="Closing Power Hour"></div>
          </div>
          
          <div className="flex justify-between text-[10px] font-mono text-muted-foreground mt-3 relative">
            <span className="absolute left-[0%] -translate-x-1/2 flex flex-col items-center gap-1">
              <span className="h-2 w-[1px] bg-border -mt-3"></span>
              9:00<br/>Pre
            </span>
            <span className="absolute left-[5%] -translate-x-1/2 flex flex-col items-center gap-1">
              <span className="h-2 w-[1px] bg-border -mt-3"></span>
              9:15<br/>Open
            </span>
            <span className="absolute left-[10%] -translate-x-1/2 flex flex-col items-center gap-1">
              <span className="h-2 w-[1px] bg-border -mt-3"></span>
              9:30
            </span>
            <span className="absolute left-[25%] -translate-x-1/2 flex flex-col items-center gap-1">
              <span className="h-2 w-[1px] bg-border -mt-3"></span>
              10:30<br/>Mid
            </span>
            <span className="absolute left-[75%] -translate-x-1/2 flex flex-col items-center gap-1">
              <span className="h-2 w-[1px] bg-border -mt-3"></span>
              14:00<br/>Close PH
            </span>
            <span className="absolute left-[100%] -translate-x-1/2 flex flex-col items-center gap-1 text-right">
              <span className="h-2 w-[1px] bg-border -mt-3"></span>
              15:30<br/>Close
            </span>
          </div>
        </div>
      </section>

      {/* Quick Reference Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="bg-card/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary" /> Pre-Market Checklist
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <CheckItem text="Check Global Cues (GIFT Nifty, US Futures)" />
            <CheckItem text="Review FII/DII Data from previous day" />
            <CheckItem text="Identify Nifty/BankNifty key support/resistance" />
            <CheckItem text="Scan pre-market top gainers/losers" />
            <CheckItem text="Load 4-Chart TradingView layout" />
          </CardContent>
        </Card>

        <Card className="bg-card/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="h-4 w-4 text-blue-400" /> Sectors In Play
            </CardTitle>
            <CardDescription>Top momentum sectors today</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <div className="flex justify-between text-sm">
                <span className="font-medium text-blue-400">NIFTY IT</span>
                <span className="font-mono text-primary">+1.85%</span>
              </div>
              <Progress value={85} className="h-1.5 bg-secondary" indicatorClassName="bg-blue-500" />
            </div>
            <div className="space-y-1.5">
              <div className="flex justify-between text-sm">
                <span className="font-medium text-emerald-400">NIFTY AUTO</span>
                <span className="font-mono text-primary">+1.20%</span>
              </div>
              <Progress value={65} className="h-1.5 bg-secondary" indicatorClassName="bg-emerald-500" />
            </div>
            <div className="space-y-1.5">
              <div className="flex justify-between text-sm">
                <span className="font-medium text-rose-400">NIFTY PHARMA</span>
                <span className="font-mono text-destructive">-0.75%</span>
              </div>
              <Progress value={30} className="h-1.5 bg-secondary" indicatorClassName="bg-rose-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <CalendarDays className="h-4 w-4 text-amber-500" /> F&O Calendar
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-3 bg-secondary/50 rounded-md border border-border">
                <div className="text-xs text-muted-foreground uppercase font-semibold mb-1">This Week</div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">NIFTY / BANKNIFTY</span>
                  <Badge variant="outline" className="text-amber-500 border-amber-500/30 bg-amber-500/10">Thursday</Badge>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <span className="font-medium">FINNIFTY</span>
                  <Badge variant="outline" className="text-blue-400 border-blue-400/30 bg-blue-400/10">Tuesday</Badge>
                </div>
              </div>
              
              <div className="p-3 bg-secondary/50 rounded-md border border-border opacity-70">
                <div className="text-xs text-muted-foreground uppercase font-semibold mb-1">Monthly Expiry</div>
                <div className="flex justify-between items-center">
                  <span className="font-medium">Stock Options</span>
                  <span className="text-sm font-mono text-muted-foreground">Last Thu</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function IndexCard({ name, value, change, changePct, isPositive, progress, dayLow, dayHigh }: any) {
  return (
    <Card className="overflow-hidden border-border/50">
      <CardContent className="p-5">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-muted-foreground">{name}</h3>
          {isPositive ? (
            <ArrowUpRight className="h-5 w-5 text-primary" />
          ) : (
            <ArrowDownRight className="h-5 w-5 text-destructive" />
          )}
        </div>
        <div className="font-mono text-2xl font-bold tracking-tight mb-1">{value}</div>
        <div className={cn(
          "font-mono text-sm font-medium flex gap-2",
          isPositive ? "text-primary" : "text-destructive"
        )}>
          <span>{change}</span>
          <span>({changePct})</span>
        </div>
        <div className="mt-4">
          <div className="flex justify-between text-[10px] text-muted-foreground mb-1 uppercase">
            <span>{dayLow ?? "Day Low"}</span>
            <span>{dayHigh ?? "Day High"}</span>
          </div>
          <Progress
            value={progress}
            className="h-1"
            indicatorClassName={isPositive ? "bg-primary" : "bg-destructive"}
          />
        </div>
      </CardContent>
    </Card>
  );
}

function CheckItem({ text }: { text: string }) {
  return (
    <div className="flex items-start gap-2">
      <div className="mt-0.5 h-4 w-4 rounded-sm border border-muted-foreground/30 flex-shrink-0" />
      <span className="text-sm text-foreground/80">{text}</span>
    </div>
  );
}
