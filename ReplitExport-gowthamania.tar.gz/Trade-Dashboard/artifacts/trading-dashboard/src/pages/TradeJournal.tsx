import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BookOpen, Plus, Trash2, TrendingUp, TrendingDown, Target,
  BarChart2, Award, AlertTriangle, ChevronDown, ChevronUp,
  Zap, Brain, Lightbulb,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AreaChart, Area, BarChart, Bar, Cell, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, ReferenceLine,
} from "recharts";
import { cn } from "@/lib/utils";

const SETUP_TYPES = [
  "VWAP Reclaim", "VWAP Rejection", "BB Breakout", "BB Reversal",
  "RSI Divergence", "Opening Range Breakout", "Gap & Go", "Gap Fill",
  "PDH/PDL Break", "Trend Pullback", "Other",
];

const EMOTIONS = ["Calm", "Confident", "Hesitant", "Greedy", "FOMO", "Revenge Trade"];

interface Trade {
  id: string;
  date: string;
  symbol: string;
  direction: "LONG" | "SHORT";
  setupType: string;
  entryPrice: number;
  exitPrice: number;
  qty: number;
  pnl: number;
  pnlPct: number;
  riskReward: number;
  emotion: string;
  notes: string;
}

const STORAGE_KEY = "nse_trade_journal_v1";

function loadTrades(): Trade[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : seedTrades();
  } catch {
    return seedTrades();
  }
}

function saveTrades(trades: Trade[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(trades));
}

function seedTrades(): Trade[] {
  const trades: Trade[] = [
    { id: "1", date: "2026-05-24", symbol: "RELIANCE", direction: "LONG", setupType: "VWAP Reclaim", entryPrice: 2845.50, exitPrice: 2878.30, qty: 20, pnl: 656, pnlPct: 1.15, riskReward: 2.4, emotion: "Calm", notes: "Clean VWAP reclaim after 10:15 pullback. Strong volume confirmation." },
    { id: "2", date: "2026-05-24", symbol: "HDFC BANK", direction: "SHORT", setupType: "BB Reversal", entryPrice: 1724.80, exitPrice: 1712.20, qty: 30, pnl: 378, pnlPct: 0.73, riskReward: 1.8, emotion: "Confident", notes: "Price rejected upper BB near PDH. RSI overbought." },
    { id: "3", date: "2026-05-23", symbol: "INFOSYS", direction: "LONG", setupType: "Gap & Go", entryPrice: 1562.10, exitPrice: 1548.40, qty: 25, pnl: -342.5, pnlPct: -0.88, riskReward: -0.7, emotion: "FOMO", notes: "Chased entry too late. Gap was already faded. Lesson: wait for confirmation." },
    { id: "4", date: "2026-05-23", symbol: "BAJFINANCE", direction: "LONG", setupType: "Opening Range Breakout", entryPrice: 6820.00, exitPrice: 6895.50, qty: 10, pnl: 755, pnlPct: 1.11, riskReward: 3.1, emotion: "Calm", notes: "Textbook ORB. Held through first pullback." },
    { id: "5", date: "2026-05-22", symbol: "SBIN", direction: "SHORT", setupType: "PDH/PDL Break", entryPrice: 812.40, exitPrice: 805.10, qty: 50, pnl: 365, pnlPct: 0.90, riskReward: 2.2, emotion: "Confident", notes: "PDL breakdown with volume. Covered near morning low." },
    { id: "6", date: "2026-05-22", symbol: "TCS", direction: "LONG", setupType: "Trend Pullback", entryPrice: 3892.00, exitPrice: 3867.50, qty: 15, pnl: -367.5, pnlPct: -0.63, riskReward: -0.8, emotion: "Hesitant", notes: "Was hesitant entering, placed stop too tight. Got stopped out before move." },
    { id: "7", date: "2026-05-21", symbol: "ICICI BANK", direction: "LONG", setupType: "VWAP Reclaim", entryPrice: 1298.30, exitPrice: 1321.70, qty: 40, pnl: 936, pnlPct: 1.80, riskReward: 3.5, emotion: "Calm", notes: "Perfect setup. VWAP reclaim + RSI 50 cross + volume surge. Best trade of the week." },
  ];
  saveTrades(trades);
  return trades;
}

// ─── Analytics helpers ────────────────────────────────────────────────────────

function calcStats(trades: Trade[]) {
  if (!trades.length) return { totalPnl: 0, winRate: 0, avgRR: 0, bestTrade: 0, worstTrade: 0, wins: 0, losses: 0, totalTrades: 0, streak: 0 };
  const wins = trades.filter(t => t.pnl > 0);
  const losses = trades.filter(t => t.pnl < 0);
  const totalPnl = trades.reduce((s, t) => s + t.pnl, 0);
  const winRate = (wins.length / trades.length) * 100;
  const avgRR = trades.filter(t => t.riskReward > 0).reduce((s, t) => s + t.riskReward, 0) / (wins.length || 1);
  const bestTrade = Math.max(...trades.map(t => t.pnl));
  const worstTrade = Math.min(...trades.map(t => t.pnl));
  const streak = calcStreak(trades);
  return { totalPnl, winRate, avgRR, bestTrade, worstTrade, wins: wins.length, losses: losses.length, totalTrades: trades.length, streak };
}

function calcStreak(trades: Trade[]): number {
  if (!trades.length) return 0;
  const sorted = [...trades].sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));
  let streak = 0;
  const firstIsWin = sorted[0].pnl >= 0;
  for (const t of sorted) {
    if ((t.pnl >= 0) === firstIsWin) streak++;
    else break;
  }
  return streak * (firstIsWin ? 1 : -1);
}

function calcBySetup(trades: Trade[]) {
  const map: Record<string, { pnl: number; count: number; wins: number }> = {};
  for (const t of trades) {
    if (!map[t.setupType]) map[t.setupType] = { pnl: 0, count: 0, wins: 0 };
    map[t.setupType].pnl += t.pnl;
    map[t.setupType].count++;
    if (t.pnl > 0) map[t.setupType].wins++;
  }
  return Object.entries(map)
    .map(([setup, v]) => ({ setup, pnl: parseFloat(v.pnl.toFixed(0)), count: v.count, winRate: (v.wins / v.count) * 100 }))
    .sort((a, b) => b.winRate - a.winRate);
}

function calcByEmotion(trades: Trade[]) {
  const map: Record<string, { count: number; wins: number; pnl: number }> = {};
  for (const t of trades) {
    if (!map[t.emotion]) map[t.emotion] = { count: 0, wins: 0, pnl: 0 };
    map[t.emotion].count++;
    map[t.emotion].pnl += t.pnl;
    if (t.pnl > 0) map[t.emotion].wins++;
  }
  return Object.entries(map)
    .map(([emotion, v]) => ({ emotion, count: v.count, winRate: (v.wins / v.count) * 100, pnl: parseFloat(v.pnl.toFixed(0)) }))
    .sort((a, b) => b.winRate - a.winRate);
}

function groupByDate(trades: Trade[]) {
  const map: Record<string, number> = {};
  trades.forEach(t => { map[t.date] = (map[t.date] || 0) + t.pnl; });
  return Object.entries(map).sort((a, b) => a[0].localeCompare(b[0])).map(([date, pnl]) => ({ date: date.slice(5), pnl: Math.round(pnl) }));
}

function buildEquityCurve(trades: Trade[]) {
  const sorted = [...trades].sort((a, b) => a.date.localeCompare(b.date) || Number(a.id) - Number(b.id));
  let cumulative = 0;
  return sorted.map(t => { cumulative += t.pnl; return { label: t.symbol, equity: Math.round(cumulative) }; });
}

// ─── Tooltip ─────────────────────────────────────────────────────────────────

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  const val = payload[0].value;
  return (
    <div className="bg-card border border-border rounded px-3 py-2 text-xs font-mono">
      <p className="text-muted-foreground mb-1">{label}</p>
      <p className={val >= 0 ? "text-emerald-400" : "text-rose-400"}>₹{val.toLocaleString("en-IN")}</p>
    </div>
  );
};

// ─── Main component ───────────────────────────────────────────────────────────

export default function TradeJournal() {
  const [trades, setTrades] = useState<Trade[]>(loadTrades);
  const [open, setOpen] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [filterDate, setFilterDate] = useState<string>("all");

  const [form, setForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    symbol: "",
    direction: "LONG" as "LONG" | "SHORT",
    setupType: "",
    entryPrice: "",
    exitPrice: "",
    qty: "",
    emotion: "Calm",
    notes: "",
    riskAmt: "",
  });

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const derivedPnl = useCallback(() => {
    const entry = parseFloat(form.entryPrice);
    const exit = parseFloat(form.exitPrice);
    const qty = parseFloat(form.qty);
    if (!entry || !exit || !qty) return null;
    const raw = form.direction === "LONG" ? (exit - entry) * qty : (entry - exit) * qty;
    const pct = form.direction === "LONG" ? ((exit - entry) / entry) * 100 : ((entry - exit) / entry) * 100;
    return { pnl: parseFloat(raw.toFixed(2)), pct: parseFloat(pct.toFixed(2)) };
  }, [form]);

  const derivedRR = useCallback(() => {
    const risk = parseFloat(form.riskAmt);
    const d = derivedPnl();
    if (!risk || !d) return null;
    return parseFloat((d.pnl / risk).toFixed(2));
  }, [form, derivedPnl]);

  const handleAdd = () => {
    const entry = parseFloat(form.entryPrice);
    const exit = parseFloat(form.exitPrice);
    const qty = parseFloat(form.qty);
    if (!form.symbol || !entry || !exit || !qty || !form.setupType) return;
    const d = derivedPnl()!;
    const rr = derivedRR() ?? 0;
    const trade: Trade = {
      id: Date.now().toString(),
      date: form.date,
      symbol: form.symbol.toUpperCase(),
      direction: form.direction,
      setupType: form.setupType,
      entryPrice: entry,
      exitPrice: exit,
      qty,
      pnl: d.pnl,
      pnlPct: d.pct,
      riskReward: rr,
      emotion: form.emotion,
      notes: form.notes,
    };
    const next = [trade, ...trades];
    setTrades(next);
    saveTrades(next);
    setOpen(false);
    setForm({ date: new Date().toISOString().slice(0, 10), symbol: "", direction: "LONG", setupType: "", entryPrice: "", exitPrice: "", qty: "", emotion: "Calm", notes: "", riskAmt: "" });
  };

  const handleDelete = (id: string) => {
    const next = trades.filter(t => t.id !== id);
    setTrades(next);
    saveTrades(next);
  };

  const dates = Array.from(new Set(trades.map(t => t.date))).sort((a, b) => b.localeCompare(a));
  const filtered = filterDate === "all" ? trades : trades.filter(t => t.date === filterDate);
  const stats = calcStats(filtered);
  const bySetup = calcBySetup(filtered);
  const byEmotion = calcByEmotion(filtered);
  const dailyPnl = groupByDate(filtered);
  const equity = buildEquityCurve(filtered);
  const derived = derivedPnl();
  const rr = derivedRR();
  const maxSetupWR = bySetup.length ? Math.max(...bySetup.map(s => s.winRate), 1) : 1;

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>

      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BookOpen className="h-5 w-5 text-primary" />
            <h1 className="text-2xl font-bold tracking-tight">Trade Journal</h1>
          </div>
          <p className="text-sm text-muted-foreground">Log every trade. Track your edge. Improve daily.</p>
        </div>

        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground" data-testid="button-add-trade">
              <Plus className="h-4 w-4" /> Log Trade
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg bg-card border-border text-foreground">
            <DialogHeader>
              <DialogTitle className="text-base font-semibold">Log New Trade</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 mt-2">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block">Date</Label>
                  <Input type="date" value={form.date} onChange={e => set("date", e.target.value)} className="font-mono text-sm" data-testid="input-date" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block">Symbol</Label>
                  <Input placeholder="RELIANCE" value={form.symbol} onChange={e => set("symbol", e.target.value)} className="font-mono text-sm uppercase" data-testid="input-symbol" />
                </div>
              </div>

              {/* Direction toggle */}
              <div>
                <Label className="text-xs text-muted-foreground mb-2 block">Direction</Label>
                <div className="grid grid-cols-2 gap-2">
                  {(["LONG", "SHORT"] as const).map(d => (
                    <button
                      key={d}
                      onClick={() => set("direction", d)}
                      className={cn(
                        "py-2 rounded border text-sm font-mono font-semibold transition-colors",
                        form.direction === d
                          ? d === "LONG" ? "bg-emerald-950/60 border-emerald-700 text-emerald-400" : "bg-rose-950/60 border-rose-700 text-rose-400"
                          : "border-border text-muted-foreground hover:border-border/80"
                      )}
                    >{d}</button>
                  ))}
                </div>
              </div>

              {/* Setup chips */}
              <div>
                <Label className="text-xs text-muted-foreground mb-2 block">Setup Type</Label>
                <div className="flex flex-wrap gap-1.5">
                  {SETUP_TYPES.map(s => (
                    <button
                      key={s}
                      onClick={() => set("setupType", s)}
                      className={cn(
                        "text-xs px-2.5 py-1 rounded-full border transition-colors",
                        form.setupType === s
                          ? "bg-primary/20 border-primary/50 text-primary"
                          : "border-border text-muted-foreground hover:text-foreground"
                      )}
                    >{s}</button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block">Entry ₹</Label>
                  <Input type="number" placeholder="0.00" value={form.entryPrice} onChange={e => set("entryPrice", e.target.value)} className="font-mono text-sm" data-testid="input-entry" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block">Exit ₹</Label>
                  <Input type="number" placeholder="0.00" value={form.exitPrice} onChange={e => set("exitPrice", e.target.value)} className="font-mono text-sm" data-testid="input-exit" />
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block">Qty</Label>
                  <Input type="number" placeholder="0" value={form.qty} onChange={e => set("qty", e.target.value)} className="font-mono text-sm" data-testid="input-qty" />
                </div>
              </div>

              {/* Live P&L preview */}
              {derived && (
                <div className={cn("rounded-md px-4 py-2.5 border text-sm font-mono flex items-center justify-between", derived.pnl >= 0 ? "bg-emerald-950/40 border-emerald-800/40" : "bg-rose-950/40 border-rose-800/40")}>
                  <span className="text-muted-foreground text-xs font-mono tracking-wider">EST. P&L</span>
                  <span className={derived.pnl >= 0 ? "text-emerald-400" : "text-rose-400"}>
                    {derived.pnl >= 0 ? "+" : ""}₹{derived.pnl.toLocaleString("en-IN")} ({derived.pct >= 0 ? "+" : ""}{derived.pct}%)
                  </span>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block">Risk Amount ₹ (for R:R)</Label>
                  <Input type="number" placeholder="Optional" value={form.riskAmt} onChange={e => set("riskAmt", e.target.value)} className="font-mono text-sm" data-testid="input-risk" />
                  {rr !== null && <p className="text-xs text-muted-foreground mt-1">R:R = <span className={rr >= 0 ? "text-emerald-400" : "text-rose-400"}>{rr}</span></p>}
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground mb-1 block">Emotion / Mindset</Label>
                  <Select value={form.emotion} onValueChange={v => set("emotion", v)}>
                    <SelectTrigger data-testid="select-emotion"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {EMOTIONS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">Notes / Observations</Label>
                <Textarea placeholder="What did you observe? What would you do differently?" value={form.notes} onChange={e => set("notes", e.target.value)} className="text-sm resize-none h-20" data-testid="textarea-notes" />
              </div>

              <Button onClick={handleAdd} className="bg-primary hover:bg-primary/90" data-testid="button-submit-trade">Add to Journal</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Date Filter */}
      <div className="flex items-center gap-2 mb-5 flex-wrap">
        <span className="text-xs text-muted-foreground font-mono">FILTER:</span>
        <button
          onClick={() => setFilterDate("all")}
          className={cn("text-xs px-3 py-1 rounded border font-mono transition-colors", filterDate === "all" ? "bg-primary/10 border-primary/30 text-primary" : "border-border text-muted-foreground hover:text-foreground")}
          data-testid="filter-all"
        >All</button>
        {dates.map(d => (
          <button
            key={d}
            onClick={() => setFilterDate(d)}
            className={cn("text-xs px-3 py-1 rounded border font-mono transition-colors", filterDate === d ? "bg-primary/10 border-primary/30 text-primary" : "border-border text-muted-foreground hover:text-foreground")}
            data-testid={`filter-date-${d}`}
          >{d}</button>
        ))}
      </div>

      {/* Stats Row — 5 cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
        <StatCard
          label="Total P&L"
          value={`${stats.totalPnl >= 0 ? "+" : ""}₹${Math.abs(stats.totalPnl).toLocaleString("en-IN", { maximumFractionDigits: 0 })}`}
          positive={stats.totalPnl >= 0}
          icon={stats.totalPnl >= 0 ? TrendingUp : TrendingDown}
          sub={`${stats.totalTrades} trades`}
        />
        <StatCard
          label="Win Rate"
          value={`${stats.winRate.toFixed(1)}%`}
          positive={stats.winRate >= 50}
          icon={Award}
          sub={`${stats.wins}W / ${stats.losses}L`}
        />
        <StatCard
          label="Avg R:R"
          value={stats.avgRR.toFixed(2)}
          positive={stats.avgRR >= 1.5}
          icon={Target}
          sub="on winning trades"
        />
        <StatCard
          label="Best Trade"
          value={`+₹${stats.bestTrade.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`}
          positive
          icon={BarChart2}
          sub={`Worst: -₹${Math.abs(stats.worstTrade).toLocaleString("en-IN", { maximumFractionDigits: 0 })}`}
        />
        <StatCard
          label="Streak"
          value={`${Math.abs(stats.streak)}${stats.streak >= 0 ? "W" : "L"}`}
          positive={stats.streak >= 0}
          icon={Zap}
          sub={stats.streak >= 0 ? "winning streak" : "losing streak"}
        />
      </div>

      {/* Charts + Analytics tabs */}
      <Tabs defaultValue="equity" className="mb-6">
        <TabsList className="bg-card border border-border mb-4">
          <TabsTrigger value="equity" className="text-xs" data-testid="tab-equity">Equity Curve</TabsTrigger>
          <TabsTrigger value="daily" className="text-xs" data-testid="tab-daily">Daily P&L</TabsTrigger>
          <TabsTrigger value="setup" className="text-xs" data-testid="tab-setup">Setup Performance</TabsTrigger>
          <TabsTrigger value="mindset" className="text-xs" data-testid="tab-mindset">Mindset Impact</TabsTrigger>
        </TabsList>

        {/* Equity Curve */}
        <TabsContent value="equity">
          <div className="bg-card border border-border rounded-lg p-4">
            <p className="text-xs text-muted-foreground font-mono mb-3">CUMULATIVE P&L CURVE</p>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={equity} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
                <defs>
                  <linearGradient id="eqGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="label" tick={{ fill: "#64748b", fontSize: 10 }} />
                <YAxis tick={{ fill: "#64748b", fontSize: 10 }} tickFormatter={v => `₹${v}`} />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={0} stroke="#334155" strokeDasharray="4 4" />
                <Area type="monotone" dataKey="equity" stroke="#10b981" strokeWidth={2} fill="url(#eqGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </TabsContent>

        {/* Daily P&L — per-bar coloring */}
        <TabsContent value="daily">
          <div className="bg-card border border-border rounded-lg p-4">
            <p className="text-xs text-muted-foreground font-mono mb-3">DAILY P&L</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={dailyPnl} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="date" tick={{ fill: "#64748b", fontSize: 10 }} />
                <YAxis tick={{ fill: "#64748b", fontSize: 10 }} tickFormatter={v => `₹${v}`} />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={0} stroke="#334155" />
                <Bar dataKey="pnl" radius={[3, 3, 0, 0]} isAnimationActive>
                  {dailyPnl.map((entry, i) => (
                    <Cell key={i} fill={entry.pnl >= 0 ? "#10b981" : "#ef4444"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </TabsContent>

        {/* Setup Performance */}
        <TabsContent value="setup">
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="px-4 py-3 border-b border-border">
              <p className="text-xs text-muted-foreground font-mono">SETUP WIN RATE BREAKDOWN</p>
            </div>
            {bySetup.length === 0 ? (
              <div className="py-12 text-center text-sm text-muted-foreground">No trades to analyze yet.</div>
            ) : (
              <div className="divide-y divide-border">
                {bySetup.map(s => {
                  const color = s.winRate >= 60 ? "#10b981" : s.winRate >= 40 ? "#f59e0b" : "#ef4444";
                  return (
                    <div key={s.setup} className="px-4 py-3 flex items-center gap-4">
                      <div className="w-40 shrink-0">
                        <p className="text-sm font-mono text-foreground leading-tight">{s.setup}</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">{s.count} trade{s.count !== 1 ? "s" : ""}</p>
                      </div>
                      <div className="flex-1 h-2 bg-border rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{ width: `${(s.winRate / maxSetupWR) * 100}%`, backgroundColor: color }}
                        />
                      </div>
                      <span className="text-sm font-mono font-semibold w-10 text-right shrink-0" style={{ color }}>{s.winRate.toFixed(0)}%</span>
                      <span className={cn("text-sm font-mono w-20 text-right shrink-0", s.pnl >= 0 ? "text-emerald-400" : "text-rose-400")}>
                        {s.pnl >= 0 ? "+" : ""}₹{Math.abs(s.pnl).toLocaleString("en-IN", { maximumFractionDigits: 0 })}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </TabsContent>

        {/* Mindset Impact */}
        <TabsContent value="mindset">
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <div className="px-4 py-3 border-b border-border">
              <p className="text-xs text-muted-foreground font-mono">MINDSET → WIN RATE CORRELATION</p>
            </div>
            {byEmotion.length === 0 ? (
              <div className="py-12 text-center text-sm text-muted-foreground">No trades to analyze yet.</div>
            ) : (
              <div className="divide-y divide-border">
                {byEmotion.map(e => {
                  const isBad = ["FOMO", "Greedy", "Revenge Trade"].includes(e.emotion);
                  const color = e.winRate >= 60 ? "#10b981" : e.winRate >= 40 ? "#f59e0b" : "#ef4444";
                  return (
                    <div key={e.emotion} className="px-4 py-3 flex items-center gap-4">
                      <div className="w-32 shrink-0 flex items-center gap-2">
                        <Brain className={cn("h-3.5 w-3.5 shrink-0", isBad ? "text-rose-400" : "text-emerald-400")} />
                        <div>
                          <p className={cn("text-sm font-mono", isBad ? "text-rose-400" : "text-foreground")}>{e.emotion}</p>
                          <p className="text-[10px] text-muted-foreground">{e.count} trade{e.count !== 1 ? "s" : ""}</p>
                        </div>
                      </div>
                      <div className="flex-1 h-2 bg-border rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-500"
                          style={{ width: `${e.winRate}%`, backgroundColor: color }}
                        />
                      </div>
                      <span className="text-sm font-mono font-semibold w-10 text-right shrink-0" style={{ color }}>{e.winRate.toFixed(0)}%</span>
                      <span className={cn("text-sm font-mono w-20 text-right shrink-0", e.pnl >= 0 ? "text-emerald-400" : "text-rose-400")}>
                        {e.pnl >= 0 ? "+" : ""}₹{Math.abs(e.pnl).toLocaleString("en-IN", { maximumFractionDigits: 0 })}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
            {byEmotion.some(e => ["FOMO", "Greedy", "Revenge Trade"].includes(e.emotion)) && (
              <div className="px-4 py-3 border-t border-border bg-amber-950/20 text-xs text-amber-300/80 flex gap-2">
                <Lightbulb className="h-3.5 w-3.5 text-amber-400 mt-0.5 shrink-0" />
                High-risk emotional states (FOMO, Greed, Revenge) in your log. Review if they correlate with your worst trades.
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Trade Log Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <p className="text-xs text-muted-foreground font-mono">TRADE LOG — {filtered.length} ENTRIES</p>
          <span className={cn("text-xs font-mono font-semibold", stats.totalPnl >= 0 ? "text-emerald-400" : "text-rose-400")}>
            {stats.totalPnl >= 0 ? "+" : ""}₹{Math.abs(stats.totalPnl).toLocaleString("en-IN", { maximumFractionDigits: 0 })}
          </span>
        </div>

        {filtered.length === 0 && (
          <div className="py-16 text-center text-muted-foreground text-sm">
            No trades logged yet. Click "Log Trade" to begin.
          </div>
        )}

        <div className="divide-y divide-border">
          <AnimatePresence>
            {filtered
              .sort((a, b) => b.date.localeCompare(a.date))
              .map(trade => {
                const isExpanded = expandedId === trade.id;
                const isWin = trade.pnl >= 0;
                return (
                  <motion.div
                    key={trade.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.2 }}
                    data-testid={`row-trade-${trade.id}`}
                  >
                    {/* Row */}
                    <div
                      className="px-4 py-3 flex items-center gap-3 cursor-pointer hover:bg-secondary/30 transition-colors"
                      onClick={() => setExpandedId(isExpanded ? null : trade.id)}
                    >
                      <span className="text-xs text-muted-foreground font-mono w-20 shrink-0">{trade.date.slice(5)}</span>

                      <Badge variant="outline" className={cn("text-[10px] font-mono w-12 justify-center shrink-0", trade.direction === "LONG" ? "border-emerald-800 text-emerald-400" : "border-rose-800 text-rose-400")}>
                        {trade.direction}
                      </Badge>

                      <span className="font-mono font-semibold text-sm w-24 shrink-0">{trade.symbol}</span>

                      <span className="text-xs text-muted-foreground hidden md:block flex-1 truncate">{trade.setupType}</span>

                      {/* Mindset chip */}
                      <span className={cn("text-[10px] font-mono px-2 py-0.5 rounded-full border hidden lg:block shrink-0",
                        ["FOMO", "Greedy", "Revenge Trade"].includes(trade.emotion)
                          ? "text-amber-400 border-amber-800/50 bg-amber-950/30"
                          : "text-muted-foreground border-border"
                      )}>
                        {trade.emotion}
                      </span>

                      <span className={cn("font-mono text-sm font-semibold w-24 text-right shrink-0", isWin ? "text-emerald-400" : "text-rose-400")}>
                        {isWin ? "+" : ""}₹{trade.pnl.toLocaleString("en-IN", { maximumFractionDigits: 0 })}
                      </span>

                      <span className={cn("font-mono text-xs w-12 text-right shrink-0 hidden md:block", trade.riskReward >= 1 ? "text-emerald-400" : "text-rose-400")}>
                        {trade.riskReward > 0 ? `${trade.riskReward}R` : "—"}
                      </span>

                      <span className="text-muted-foreground ml-1">
                        {isExpanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
                      </span>

                      <button
                        onClick={e => { e.stopPropagation(); handleDelete(trade.id); }}
                        className="text-muted-foreground hover:text-rose-400 transition-colors"
                        data-testid={`button-delete-${trade.id}`}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    {/* Expanded detail */}
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <div className="px-4 pb-4 pt-1 bg-secondary/10 border-t border-border grid grid-cols-2 md:grid-cols-4 gap-3">
                            <MiniStat label="Entry" value={`₹${trade.entryPrice.toLocaleString("en-IN")}`} />
                            <MiniStat label="Exit" value={`₹${trade.exitPrice.toLocaleString("en-IN")}`} />
                            <MiniStat label="Qty" value={`${trade.qty} shares`} />
                            <MiniStat label="P&L %" value={`${trade.pnlPct >= 0 ? "+" : ""}${trade.pnlPct}%`} colored positive={trade.pnlPct >= 0} />
                            <MiniStat label="Setup" value={trade.setupType} />
                            <MiniStat label="R:R" value={trade.riskReward > 0 ? `${trade.riskReward}R` : "—"} colored positive={trade.riskReward >= 1} />
                            <MiniStat label="Mindset" value={trade.emotion} highlight={["FOMO", "Greedy", "Revenge Trade"].includes(trade.emotion)} />
                            {trade.notes && (
                              <div className="col-span-2 md:col-span-4 mt-1">
                                <p className="text-xs text-muted-foreground font-mono mb-1">NOTES</p>
                                <p className="text-xs text-foreground/80 leading-relaxed">{trade.notes}</p>
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </motion.div>
                );
              })}
          </AnimatePresence>
        </div>
      </div>

      {/* Insights Banner */}
      {stats.totalTrades >= 3 && (
        <div className="mt-4 bg-amber-950/30 border border-amber-800/30 rounded-lg px-4 py-3 flex items-start gap-3">
          <AlertTriangle className="h-4 w-4 text-amber-400 mt-0.5 shrink-0" />
          <p className="text-xs text-amber-300/80">
            {stats.winRate < 50
              ? `Win rate at ${stats.winRate.toFixed(1)}% — below 50%. Check the Mindset tab to see if FOMO or Revenge trades are hurting your results.`
              : stats.avgRR < 1.5
              ? `Win rate is healthy at ${stats.winRate.toFixed(1)}%, but avg R:R is ${stats.avgRR.toFixed(2)}. Consider letting winners run longer. Check Setup Performance for your best setups.`
              : `Strong edge: ${stats.winRate.toFixed(1)}% win rate with ${stats.avgRR.toFixed(2)} avg R:R. Keep journaling every trade to protect this edge.`}
          </p>
        </div>
      )}
    </motion.div>
  );
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function StatCard({ label, value, positive, icon: Icon, sub }: { label: string; value: string; positive: boolean; icon: any; sub: string }) {
  return (
    <div className="bg-card border border-border rounded-lg p-4" data-testid={`card-stat-${label.toLowerCase().replace(/\s/g, "-")}`}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-muted-foreground font-mono">{label.toUpperCase()}</span>
        <Icon className={cn("h-4 w-4", positive ? "text-emerald-400" : "text-rose-400")} />
      </div>
      <p className={cn("text-xl font-bold font-mono", positive ? "text-emerald-400" : "text-rose-400")}>{value}</p>
      <p className="text-xs text-muted-foreground mt-1">{sub}</p>
    </div>
  );
}

function MiniStat({ label, value, colored, positive, highlight }: { label: string; value: string; colored?: boolean; positive?: boolean; highlight?: boolean }) {
  return (
    <div>
      <p className="text-[10px] text-muted-foreground font-mono mb-0.5">{label.toUpperCase()}</p>
      <p className={cn("text-xs font-mono", colored ? (positive ? "text-emerald-400" : "text-rose-400") : highlight ? "text-amber-400" : "text-foreground")}>{value}</p>
    </div>
  );
}
