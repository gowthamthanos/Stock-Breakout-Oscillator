import { Router, type IRouter } from "express";
import healthRouter from "./health";
import optionsRouter from "./options";

const router: IRouter = Router();

router.use(healthRouter);
router.use(optionsRouter);

export default router;
