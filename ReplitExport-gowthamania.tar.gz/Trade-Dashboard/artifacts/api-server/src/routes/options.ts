import { Router } from "express";
import { logger } from "../lib/logger";

interface OptionsLeg {
  oi: number;
  oiChange: number;
  volume: number;
  iv: number;
  ltp: number;
}

interface OptionsStrike {
  strike: number;
  isAtm: boolean;
  ce: OptionsLeg;
  pe: OptionsLeg;
}

interface OptionsChain {
  symbol: string;
  expiry: string;
  spot: number;
  atm: number;
  pcr: number;
  maxPain: number;
  totalCeOi: number;
  totalPeOi: number;
  strikes: OptionsStrike[];
  cachedAt: string;
  isMocked: boolean;
}

// ---------- NSE browser-like headers ----------
const BASE_HEADERS: Record<string, string> = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Accept-Language": "en-US,en;q=0.9",
  "Accept-Encoding": "gzip, deflate, br",
  Connection: "keep-alive",
};

// ---------- Cache ----------
const COOKIE_TTL = 4 * 60_000;   // 4 min
const DATA_TTL   = 30_000;       // 30 sec
const MOCK_TTL   = 15_000;       // 15 sec for mocks (refresh quickly when real data available)

let cookieStore: { value: string; expiresAt: number } | null = null;
const dataCache = new Map<string, { value: OptionsChain; expiresAt: number }>();

// ---------- Cookie helpers ----------
function parseCookies(resp: Response): string[] {
  // Node 20+ has getSetCookie(); fall back to forEach for older runtimes
  if (typeof (resp.headers as any).getSetCookie === "function") {
    return (resp.headers as any).getSetCookie() as string[];
  }
  const cookies: string[] = [];
  resp.headers.forEach((v, k) => {
    if (k.toLowerCase() === "set-cookie") cookies.push(v);
  });
  return cookies;
}

function extractCookieStr(rawCookies: string[]): string {
  return rawCookies.map(c => c.split(";")[0]).join("; ");
}

async function fetchWithCookies(url: string, cookie: string, isPage = false): Promise<Response> {
  return fetch(url, {
    headers: {
      ...BASE_HEADERS,
      Accept: isPage
        ? "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        : "application/json, text/plain, */*",
      Referer: "https://www.nseindia.com/option-chain",
      Cookie: cookie,
    },
    signal: AbortSignal.timeout(12_000),
  });
}

async function establishSession(): Promise<string> {
  const now = Date.now();
  if (cookieStore && cookieStore.expiresAt > now) return cookieStore.value;

  // Step 1: hit root
  let allCookies: string[] = [];
  const r1 = await fetch("https://www.nseindia.com", {
    headers: { ...BASE_HEADERS, Accept: "text/html,application/xhtml+xml,*/*;q=0.8" },
    signal: AbortSignal.timeout(12_000),
  });
  allCookies.push(...parseCookies(r1));

  // Step 2: hit the option-chain page with the cookies we just got
  const cookieSoFar = extractCookieStr(allCookies);
  const r2 = await fetchWithCookies("https://www.nseindia.com/option-chain", cookieSoFar, true);
  allCookies.push(...parseCookies(r2));

  // Step 3: combine, dedupe, store
  const deduped = new Map<string, string>();
  for (const raw of allCookies) {
    const [kv] = raw.split(";");
    const [k] = (kv ?? "").split("=");
    if (k?.trim()) deduped.set(k.trim(), kv.trim());
  }
  const cookieStr = Array.from(deduped.values()).join("; ");

  cookieStore = { value: cookieStr, expiresAt: now + COOKIE_TTL };
  logger.info({ cookies: deduped.size }, "NSE session established");
  return cookieStr;
}

// ---------- Mock data generator ----------
function generateMockChain(symbol: string): OptionsChain {
  const SPOT_MAP: Record<string, number> = {
    NIFTY: 24_853,
    BANKNIFTY: 55_342,
    FINNIFTY: 24_120,
  };
  const STEP_MAP: Record<string, number> = {
    NIFTY: 50,
    BANKNIFTY: 100,
    FINNIFTY: 50,
  };

  const spot = SPOT_MAP[symbol] ?? 24_853;
  const step = STEP_MAP[symbol] ?? 50;
  const atm = Math.round(spot / step) * step;
  const expiry = getNextThursday();

  const strikes: OptionsStrike[] = [];
  for (let i = -8; i <= 8; i++) {
    const strike = atm + i * step;
    const distAbs = Math.abs(i);
    const distFrac = distAbs / 8;

    // OI peaks near ATM, falls off at wings
    const ceOI = Math.round((300_000 * (1 - distFrac * 0.5) + Math.random() * 100_000) * (i >= 0 ? 1.2 : 0.8));
    const peOI = Math.round((300_000 * (1 - distFrac * 0.5) + Math.random() * 100_000) * (i <= 0 ? 1.3 : 0.7));

    // Put-heavy below ATM (support), Call-heavy above ATM (resistance)
    const ceLtp = i >= 0
      ? Math.max(1, spot - strike + (Math.random() * 10 - 5)) // OTM → low premium
      : Math.max(2, strike - spot + 10 + Math.random() * 20);
    const peLtp = i <= 0
      ? Math.max(1, strike - spot + (Math.random() * 10 - 5))
      : Math.max(2, spot - strike + 10 + Math.random() * 20);

    const ceIV = 12 + distAbs * 0.8 + Math.random() * 2;
    const peIV = 13 + distAbs * 0.9 + Math.random() * 2;

    strikes.push({
      strike,
      isAtm: i === 0,
      ce: { oi: ceOI, oiChange: Math.round((Math.random() - 0.4) * 50_000), volume: Math.round(ceOI * 0.3), iv: parseFloat(ceIV.toFixed(2)), ltp: parseFloat(ceLtp.toFixed(1)) },
      pe: { oi: peOI, oiChange: Math.round((Math.random() - 0.4) * 50_000), volume: Math.round(peOI * 0.3), iv: parseFloat(peIV.toFixed(2)), ltp: parseFloat(peLtp.toFixed(1)) },
    });
  }

  const totalCeOi = strikes.reduce((s, t) => s + t.ce.oi, 0);
  const totalPeOi = strikes.reduce((s, t) => s + t.pe.oi, 0);
  const pcr = totalCeOi > 0 ? parseFloat((totalPeOi / totalCeOi).toFixed(3)) : 0;
  const maxPain = calcMaxPain(strikes);

  return { symbol, expiry, spot, atm, pcr, maxPain, totalCeOi, totalPeOi, strikes, cachedAt: new Date().toISOString(), isMocked: true };
}

function getNextThursday(): string {
  const d = new Date();
  const day = d.getDay(); // 0=Sun..6=Sat
  const daysUntilThursday = (4 - day + 7) % 7 || 7;
  d.setDate(d.getDate() + daysUntilThursday);
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }).replace(/ /g, "-");
}

// ---------- Max pain ----------
function calcMaxPain(strikes: OptionsStrike[]): number {
  if (!strikes.length) return 0;
  let minPain = Infinity;
  let result = strikes[0].strike;
  for (const s of strikes) {
    let pain = 0;
    for (const other of strikes) {
      if (other.strike < s.strike) pain += (s.strike - other.strike) * other.pe.oi;
      if (other.strike > s.strike) pain += (other.strike - s.strike) * other.ce.oi;
    }
    if (pain < minPain) { minPain = pain; result = s.strike; }
  }
  return result;
}

// ---------- Router ----------
const optionsRouter = Router();

optionsRouter.get("/options/chain", async (req, res) => {
  const symbol = typeof req.query["symbol"] === "string"
    ? req.query["symbol"].toUpperCase()
    : "NIFTY";

  const now = Date.now();
  const cached = dataCache.get(symbol);
  if (cached && cached.expiresAt > now) return res.json(cached.value);

  // ---- Try live NSE data ----
  try {
    const cookie = await establishSession();

    const apiResp = await fetch(
      `https://www.nseindia.com/api/option-chain-indices?symbol=${symbol}`,
      {
        headers: { ...BASE_HEADERS, Accept: "application/json, text/plain, */*", Referer: "https://www.nseindia.com/option-chain", Cookie: cookie },
        signal: AbortSignal.timeout(12_000),
      }
    );

    if (!apiResp.ok) {
      cookieStore = null; // force re-auth next time
      throw new Error(`NSE returned ${apiResp.status}`);
    }

    const raw = (await apiResp.json()) as {
      records: {
        data: Array<{
          strikePrice: number;
          expiryDate: string;
          CE?: { openInterest?: number; changeinOpenInterest?: number; totalTradedVolume?: number; impliedVolatility?: number; lastPrice?: number };
          PE?: { openInterest?: number; changeinOpenInterest?: number; totalTradedVolume?: number; impliedVolatility?: number; lastPrice?: number };
        }>;
        underlyingValue: number;
        expiryDates: string[];
      };
    };

    const records = raw.records;
    const spot: number = records.underlyingValue;
    const nearestExpiry: string = records.expiryDates?.[0] ?? "";

    const strikeMap = new Map<number, OptionsStrike>();
    const emptyLeg = (): OptionsLeg => ({ oi: 0, oiChange: 0, volume: 0, iv: 0, ltp: 0 });

    for (const item of records.data) {
      if (item.expiryDate !== nearestExpiry) continue;
      const sp = item.strikePrice;
      if (!strikeMap.has(sp)) strikeMap.set(sp, { strike: sp, isAtm: false, ce: emptyLeg(), pe: emptyLeg() });
      const entry = strikeMap.get(sp)!;
      if (item.CE) entry.ce = { oi: item.CE.openInterest ?? 0, oiChange: item.CE.changeinOpenInterest ?? 0, volume: item.CE.totalTradedVolume ?? 0, iv: item.CE.impliedVolatility ?? 0, ltp: item.CE.lastPrice ?? 0 };
      if (item.PE) entry.pe = { oi: item.PE.openInterest ?? 0, oiChange: item.PE.changeinOpenInterest ?? 0, volume: item.PE.totalTradedVolume ?? 0, iv: item.PE.impliedVolatility ?? 0, ltp: item.PE.lastPrice ?? 0 };
    }

    const allStrikes = Array.from(strikeMap.values()).sort((a, b) => a.strike - b.strike);
    let atmStrike = allStrikes[0]?.strike ?? spot;
    let minDiff = Infinity;
    for (const s of allStrikes) { const d = Math.abs(s.strike - spot); if (d < minDiff) { minDiff = d; atmStrike = s.strike; } }
    for (const s of allStrikes) s.isAtm = s.strike === atmStrike;

    const atmIdx = allStrikes.findIndex(s => s.strike === atmStrike);
    const strikes = allStrikes.slice(Math.max(0, atmIdx - 8), Math.min(allStrikes.length, atmIdx + 9));

    const totalCeOi = allStrikes.reduce((s, t) => s + t.ce.oi, 0);
    const totalPeOi = allStrikes.reduce((s, t) => s + t.pe.oi, 0);
    const pcr = totalCeOi > 0 ? parseFloat((totalPeOi / totalCeOi).toFixed(3)) : 0;
    const maxPain = calcMaxPain(allStrikes);

    const result: OptionsChain = { symbol, expiry: nearestExpiry, spot, atm: atmStrike, pcr, maxPain, totalCeOi, totalPeOi, strikes, cachedAt: new Date().toISOString(), isMocked: false };
    dataCache.set(symbol, { value: result, expiresAt: now + DATA_TTL });
    req.log.info({ symbol, spot, strikes: strikes.length, pcr }, "Options chain (live)");
    return res.json(result);

  } catch (err) {
    // ---- Fall back to mock data so the UI always works ----
    req.log.warn({ err: (err as Error).message, symbol }, "NSE fetch failed – serving mock data");
    const mock = generateMockChain(symbol);
    dataCache.set(symbol, { value: mock, expiresAt: now + MOCK_TTL });
    return res.json(mock);
  }
});

export default optionsRouter;
