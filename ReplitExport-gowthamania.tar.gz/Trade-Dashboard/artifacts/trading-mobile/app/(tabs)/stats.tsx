import React, { useMemo } from 'react';
import {
  View, Text, ScrollView, StyleSheet, Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { useTradesContext, Trade } from '@/context/TradesContext';

function calcOverall(trades: Trade[]) {
  if (!trades.length) return { totalPnl: 0, winRate: 0, avgRR: 0, bestTrade: 0, worstTrade: 0, wins: 0, losses: 0, totalTrades: 0, currentStreak: 0 };
  const wins = trades.filter(t => t.pnl > 0);
  const losses = trades.filter(t => t.pnl < 0);
  const totalPnl = trades.reduce((s, t) => s + t.pnl, 0);
  const winRate = (wins.length / trades.length) * 100;
  const avgRR = wins.length > 0 ? wins.reduce((s, t) => s + t.riskReward, 0) / wins.length : 0;
  const bestTrade = Math.max(...trades.map(t => t.pnl));
  const worstTrade = Math.min(...trades.map(t => t.pnl));
  const sorted = [...trades].sort((a, b) => b.date.localeCompare(a.date));
  let streak = 0;
  const first = sorted[0]?.pnl >= 0;
  for (const t of sorted) { if ((t.pnl >= 0) === first) streak++; else break; }
  return { totalPnl, winRate, avgRR, bestTrade, worstTrade, wins: wins.length, losses: losses.length, totalTrades: trades.length, currentStreak: streak * (first ? 1 : -1) };
}

function calcBySetup(trades: Trade[]) {
  const map: Record<string, { pnl: number; count: number; wins: number }> = {};
  for (const t of trades) {
    if (!map[t.setupType]) map[t.setupType] = { pnl: 0, count: 0, wins: 0 };
    map[t.setupType].pnl += t.pnl;
    map[t.setupType].count++;
    if (t.pnl > 0) map[t.setupType].wins++;
  }
  return Object.entries(map)
    .map(([setup, v]) => ({ setup, pnl: v.pnl, count: v.count, winRate: (v.wins / v.count) * 100 }))
    .sort((a, b) => b.winRate - a.winRate);
}

function calcDailyPnL(trades: Trade[]) {
  const map: Record<string, number> = {};
  for (const t of trades) { map[t.date] = (map[t.date] || 0) + t.pnl; }
  return Object.entries(map).sort((a, b) => a[0].localeCompare(b[0])).map(([date, pnl]) => ({ date: date.slice(5), pnl: Math.round(pnl) }));
}

function calcByEmotion(trades: Trade[]) {
  const map: Record<string, { count: number; wins: number }> = {};
  for (const t of trades) {
    if (!map[t.emotion]) map[t.emotion] = { count: 0, wins: 0 };
    map[t.emotion].count++;
    if (t.pnl > 0) map[t.emotion].wins++;
  }
  return Object.entries(map).map(([emotion, v]) => ({ emotion, count: v.count, winRate: (v.wins / v.count) * 100 })).sort((a, b) => b.winRate - a.winRate);
}

export default function StatsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { trades, isLoaded } = useTradesContext();
  const isWeb = Platform.OS === 'web';
  const topPad = isWeb ? 67 : insets.top;
  const bottomPad = isWeb ? 34 : 0;

  const overall = useMemo(() => calcOverall(trades), [trades]);
  const bySetup = useMemo(() => calcBySetup(trades), [trades]);
  const daily = useMemo(() => calcDailyPnL(trades), [trades]);
  const byEmotion = useMemo(() => calcByEmotion(trades), [trades]);

  const maxDailyAbs = daily.length ? Math.max(...daily.map(d => Math.abs(d.pnl)), 1) : 1;
  const maxSetupWR = bySetup.length ? Math.max(...bySetup.map(s => s.winRate), 1) : 1;

  const s = makeStyles(colors);

  return (
    <View style={[s.root, { paddingTop: topPad }]}>
      <View style={s.header}>
        <View>
          <Text style={s.headerTitle}>Performance</Text>
          <Text style={s.headerSub}>All-time stats · {overall.totalTrades} trades</Text>
        </View>
        <Ionicons name="analytics-outline" size={22} color={colors.primary} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={[s.scroll, { paddingBottom: bottomPad + 100 }]}>

        {/* Big 4 Stats */}
        <View style={s.bigGrid}>
          <BigStat label="Total P&L" value={`${overall.totalPnl >= 0 ? '+' : ''}₹${Math.abs(overall.totalPnl).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`} positive={overall.totalPnl >= 0} sub={`${overall.wins}W / ${overall.losses}L`} colors={colors} />
          <BigStat label="Win Rate" value={`${overall.winRate.toFixed(1)}%`} positive={overall.winRate >= 50} sub={`${overall.totalTrades} trades`} colors={colors} />
          <BigStat label="Avg R:R" value={overall.avgRR.toFixed(2)} positive={overall.avgRR >= 1.5} sub="on winners" colors={colors} />
          <BigStat
            label="Streak"
            value={`${Math.abs(overall.currentStreak)}${overall.currentStreak >= 0 ? 'W' : 'L'}`}
            positive={overall.currentStreak >= 0}
            sub="current streak"
            colors={colors}
          />
        </View>

        {/* Best / Worst */}
        <View style={s.bwRow}>
          <View style={[s.bwCard, { borderColor: colors.emerald + '55', backgroundColor: colors.emerald + '0a' }]}>
            <Text style={s.bwLabel}>BEST TRADE</Text>
            <Text style={[s.bwValue, { color: colors.emerald }]}>+₹{overall.bestTrade.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</Text>
          </View>
          <View style={[s.bwCard, { borderColor: colors.rose + '55', backgroundColor: colors.rose + '0a' }]}>
            <Text style={s.bwLabel}>WORST TRADE</Text>
            <Text style={[s.bwValue, { color: colors.rose }]}>-₹{Math.abs(overall.worstTrade).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</Text>
          </View>
        </View>

        {/* Daily P&L Bar Chart */}
        {daily.length > 0 && (
          <>
            <Text style={s.sectionLabel}>DAILY P&L</Text>
            <View style={s.chartCard}>
              <View style={s.barChart}>
                {daily.map((d, i) => {
                  const isPos = d.pnl >= 0;
                  const ratio = Math.abs(d.pnl) / maxDailyAbs;
                  return (
                    <View key={i} style={s.barCol}>
                      <View style={s.barWrap}>
                        <View style={[s.bar, { height: `${Math.max(ratio * 100, 6)}%` as any, backgroundColor: isPos ? colors.emerald : colors.rose }]} />
                      </View>
                      <Text style={s.barLabel} numberOfLines={1}>{d.date}</Text>
                    </View>
                  );
                })}
              </View>
            </View>
          </>
        )}

        {/* Setup Breakdown */}
        {bySetup.length > 0 && (
          <>
            <Text style={[s.sectionLabel, { marginTop: 20 }]}>SETUP PERFORMANCE</Text>
            <View style={s.setupCard}>
              {bySetup.map((setup) => (
                <View key={setup.setup} style={s.setupRow}>
                  <View style={s.setupInfo}>
                    <Text style={s.setupName} numberOfLines={1}>{setup.setup}</Text>
                    <Text style={s.setupCount}>{setup.count} trade{setup.count !== 1 ? 's' : ''}</Text>
                  </View>
                  <View style={s.setupBarWrap}>
                    <View style={[s.setupBarBg, { backgroundColor: colors.border }]}>
                      <View style={[s.setupBarFill, { width: `${(setup.winRate / maxSetupWR) * 100}%` as any, backgroundColor: setup.winRate >= 60 ? colors.emerald : setup.winRate >= 40 ? colors.amber : colors.rose }]} />
                    </View>
                  </View>
                  <Text style={[s.setupWR, { color: setup.winRate >= 60 ? colors.emerald : setup.winRate >= 40 ? colors.amber : colors.rose }]}>{setup.winRate.toFixed(0)}%</Text>
                </View>
              ))}
            </View>
          </>
        )}

        {/* Emotion / Mindset Impact */}
        {byEmotion.length > 0 && (
          <>
            <Text style={[s.sectionLabel, { marginTop: 20 }]}>MINDSET IMPACT</Text>
            <View style={s.setupCard}>
              {byEmotion.map((e) => (
                <View key={e.emotion} style={s.setupRow}>
                  <View style={[s.emotionDot, { backgroundColor: e.winRate >= 60 ? colors.emerald : e.winRate >= 40 ? colors.amber : colors.rose }]} />
                  <View style={s.setupInfo}>
                    <Text style={s.setupName}>{e.emotion}</Text>
                    <Text style={s.setupCount}>{e.count} trade{e.count !== 1 ? 's' : ''}</Text>
                  </View>
                  <Text style={[s.setupWR, { color: e.winRate >= 60 ? colors.emerald : e.winRate >= 40 ? colors.amber : colors.rose }]}>{e.winRate.toFixed(0)}% win</Text>
                </View>
              ))}
            </View>
          </>
        )}

        {/* Insight Banner */}
        {overall.totalTrades >= 3 && (
          <View style={[s.insightBanner, { borderColor: colors.amber + '44', backgroundColor: colors.amber + '0a' }]}>
            <Ionicons name="bulb-outline" size={16} color={colors.amber} />
            <Text style={[s.insightText, { color: colors.amber }]}>
              {overall.winRate < 50
                ? `Win rate at ${overall.winRate.toFixed(0)}% — review your losing setups. Check if FOMO/Revenge trades correlate with losses.`
                : overall.avgRR < 1.5
                ? `Solid ${overall.winRate.toFixed(0)}% win rate, but avg R:R of ${overall.avgRR.toFixed(1)} is low. Let winners run longer.`
                : `Strong edge: ${overall.winRate.toFixed(0)}% win rate + ${overall.avgRR.toFixed(1)} avg R:R. Protect this by journaling every trade.`}
            </Text>
          </View>
        )}

      </ScrollView>
    </View>
  );
}

function BigStat({ label, value, positive, sub, colors }: { label: string; value: string; positive: boolean; sub: string; colors: any }) {
  return (
    <View style={{ flex: 1, backgroundColor: colors.card, borderRadius: 10, borderWidth: 1, borderColor: colors.border, padding: 12, alignItems: 'center' }}>
      <Text style={{ fontSize: 9, color: colors.mutedForeground, fontFamily: 'Inter_600SemiBold', letterSpacing: 0.8, marginBottom: 4 }}>{label}</Text>
      <Text style={{ fontSize: 16, fontFamily: 'Inter_700Bold', color: positive ? colors.emerald : colors.rose }}>{value}</Text>
      <Text style={{ fontSize: 9, color: colors.mutedForeground, fontFamily: 'Inter_400Regular', marginTop: 2, textAlign: 'center' }}>{sub}</Text>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.border },
    headerTitle: { fontSize: 22, fontWeight: '700' as const, color: colors.foreground, fontFamily: 'Inter_700Bold' },
    headerSub: { fontSize: 12, color: colors.mutedForeground, marginTop: 1, fontFamily: 'Inter_400Regular' },
    scroll: { paddingHorizontal: 16, paddingTop: 16 },
    bigGrid: { flexDirection: 'row', gap: 8, marginBottom: 12 },
    bwRow: { flexDirection: 'row', gap: 10, marginBottom: 4 },
    bwCard: { flex: 1, borderRadius: 10, borderWidth: 1, padding: 12 },
    bwLabel: { fontSize: 9, color: '#9ca3af', fontFamily: 'Inter_600SemiBold', letterSpacing: 0.8, marginBottom: 4 },
    bwValue: { fontSize: 17, fontFamily: 'Inter_700Bold' },
    sectionLabel: { fontSize: 10, fontFamily: 'Inter_600SemiBold', color: colors.mutedForeground, letterSpacing: 1, marginBottom: 10, marginTop: 4 },
    chartCard: { backgroundColor: colors.card, borderRadius: 10, borderWidth: 1, borderColor: colors.border, padding: 14, height: 140 },
    barChart: { flex: 1, flexDirection: 'row', alignItems: 'flex-end', gap: 4 },
    barCol: { flex: 1, alignItems: 'center', height: '100%' },
    barWrap: { flex: 1, justifyContent: 'flex-end', width: '100%' },
    bar: { width: '100%', borderRadius: 3 },
    barLabel: { fontSize: 8, color: colors.mutedForeground, fontFamily: 'Inter_400Regular', marginTop: 4 },
    setupCard: { backgroundColor: colors.card, borderRadius: 10, borderWidth: 1, borderColor: colors.border, overflow: 'hidden' },
    setupRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.border + '60', gap: 10 },
    setupInfo: { width: 110 },
    setupName: { fontSize: 12, fontFamily: 'Inter_600SemiBold', color: colors.foreground },
    setupCount: { fontSize: 10, color: colors.mutedForeground, fontFamily: 'Inter_400Regular' },
    setupBarWrap: { flex: 1 },
    setupBarBg: { height: 5, borderRadius: 3, overflow: 'hidden' },
    setupBarFill: { height: '100%', borderRadius: 3 },
    setupWR: { width: 40, textAlign: 'right', fontSize: 12, fontFamily: 'Inter_700Bold' },
    emotionDot: { width: 8, height: 8, borderRadius: 4 },
    insightBanner: { borderRadius: 10, borderWidth: 1, padding: 14, flexDirection: 'row', gap: 10, alignItems: 'flex-start', marginTop: 16 },
    insightText: { flex: 1, fontSize: 12, fontFamily: 'Inter_400Regular', lineHeight: 18 },
  });
}
