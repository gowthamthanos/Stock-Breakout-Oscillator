import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  ActivityIndicator, Platform, RefreshControl,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useGetOptionsChain } from '@workspace/api-client-react';
import { useColors } from '@/hooks/useColors';

const SYMBOLS = ['NIFTY', 'BANKNIFTY', 'FINNIFTY'] as const;
type Symbol = typeof SYMBOLS[number];

function formatOI(n: number): string {
  if (n >= 100_00_000) return `${(n / 100_00_000).toFixed(1)}Cr`;
  if (n >= 1_00_000) return `${(n / 1_00_000).toFixed(1)}L`;
  if (n >= 1000) return `${(n / 1000).toFixed(0)}K`;
  return n.toString();
}

function formatLTP(n: number): string {
  return n.toLocaleString('en-IN', { maximumFractionDigits: 1, minimumFractionDigits: 1 });
}

const REFETCH_INTERVAL = 30_000;

export default function OptionsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [symbol, setSymbol] = useState<Symbol>('NIFTY');
  const [countdown, setCountdown] = useState(30);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const isWeb = Platform.OS === 'web';
  const topPad = isWeb ? 67 : insets.top;
  const bottomPad = isWeb ? 34 : 0;

  const { data, isLoading, isFetching, isError, error, refetch } = useGetOptionsChain(
    { symbol },
    { refetchInterval: REFETCH_INTERVAL, staleTime: 25_000 }
  );

  useEffect(() => {
    setCountdown(30);
    if (countdownRef.current) clearInterval(countdownRef.current);
    countdownRef.current = setInterval(() => {
      setCountdown(c => {
        if (c <= 1) { setCountdown(30); return 30; }
        return c - 1;
      });
    }, 1000);
    return () => { if (countdownRef.current) clearInterval(countdownRef.current); };
  }, [data?.cachedAt]);

  const handleRefresh = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setCountdown(30);
    refetch();
  };

  const maxOI = data?.strikes
    ? Math.max(...data.strikes.flatMap(s => [s.ce.oi, s.pe.oi]), 1)
    : 1;

  const isMocked = data?.isMocked ?? false;

  const pcrColor = !data ? colors.mutedForeground
    : data.pcr > 1.2 ? colors.emerald
    : data.pcr < 0.8 ? colors.rose
    : colors.amber;

  const pcrSentiment = !data ? '—'
    : data.pcr > 1.5 ? 'Bullish'
    : data.pcr > 1.2 ? 'Mod. Bullish'
    : data.pcr < 0.6 ? 'Very Bearish'
    : data.pcr < 0.8 ? 'Bearish'
    : 'Neutral';

  const s = makeStyles(colors);

  return (
    <View style={[s.root, { paddingTop: topPad }]}>
      {/* Header */}
      <View style={s.header}>
        <View>
          <Text style={s.headerTitle}>Options Chain</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 1 }}>
            <Text style={s.headerSub}>NSE · {data?.expiry ?? 'Loading...'}</Text>
            {data && (
              <View style={[s.modeBadge, { backgroundColor: isMocked ? colors.amber + '22' : colors.emerald + '22', borderColor: isMocked ? colors.amber + '55' : colors.emerald + '55' }]}>
                <View style={[s.modeDot, { backgroundColor: isMocked ? colors.amber : colors.emerald }]} />
                <Text style={[s.modeText, { color: isMocked ? colors.amber : colors.emerald }]}>
                  {isMocked ? 'SIMULATED' : 'LIVE'}
                </Text>
              </View>
            )}
          </View>
        </View>
        <View style={s.headerRight}>
          <Text style={[s.countdown, { color: countdown <= 10 ? colors.amber : colors.mutedForeground }]}>
            {isFetching ? '↻' : `${countdown}s`}
          </Text>
          <TouchableOpacity style={s.refreshBtn} onPress={handleRefresh} testID="button-refresh">
            <Feather name="refresh-cw" size={16} color={isFetching ? colors.primary : colors.mutedForeground} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Symbol Selector */}
      <View style={s.symbolRow}>
        {SYMBOLS.map(sym => (
          <TouchableOpacity
            key={sym}
            style={[s.symBtn, { borderColor: symbol === sym ? colors.primary : colors.border, backgroundColor: symbol === sym ? colors.primary + '22' : 'transparent' }]}
            onPress={() => { setSymbol(sym); Haptics.selectionAsync(); }}
            testID={`button-symbol-${sym}`}
          >
            <Text style={[s.symText, { color: symbol === sym ? colors.primary : colors.mutedForeground }]}>{sym}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Stats Bar */}
      {data && (
        <View style={s.statsBar}>
          <View style={s.statItem}>
            <Text style={s.statLabel}>SPOT</Text>
            <Text style={s.statValue}>{data.spot.toLocaleString('en-IN')}</Text>
          </View>
          <View style={s.statDivider} />
          <View style={s.statItem}>
            <Text style={s.statLabel}>PCR</Text>
            <Text style={[s.statValue, { color: pcrColor }]}>{data.pcr.toFixed(2)}</Text>
            <Text style={[s.statSub, { color: pcrColor }]}>{pcrSentiment}</Text>
          </View>
          <View style={s.statDivider} />
          <View style={s.statItem}>
            <Text style={s.statLabel}>MAX PAIN</Text>
            <Text style={[s.statValue, { color: colors.amber }]}>{data.maxPain.toLocaleString('en-IN')}</Text>
          </View>
          <View style={s.statDivider} />
          <View style={s.statItem}>
            <Text style={s.statLabel}>ATM</Text>
            <Text style={[s.statValue, { color: colors.blue }]}>{data.atm.toLocaleString('en-IN')}</Text>
          </View>
        </View>
      )}

      {/* OI Balance Bar */}
      {data && data.totalCeOi + data.totalPeOi > 0 && (
        <View style={s.oiBalanceWrap}>
          <Text style={[s.oiBalanceLabel, { color: colors.rose }]}>CE {formatOI(data.totalCeOi)}</Text>
          <View style={s.oiBalanceBar}>
            <View style={[s.oiCeBar, { flex: data.totalCeOi, backgroundColor: colors.rose + 'cc' }]} />
            <View style={[s.oiPeBar, { flex: data.totalPeOi, backgroundColor: colors.emerald + 'cc' }]} />
          </View>
          <Text style={[s.oiBalanceLabel, { color: colors.emerald }]}>PE {formatOI(data.totalPeOi)}</Text>
        </View>
      )}

      {/* Column Headers */}
      <View style={s.colHeader}>
        <Text style={[s.colHeadText, { flex: 1, textAlign: 'right' }]}>OI</Text>
        <Text style={[s.colHeadText, { width: 44, textAlign: 'right' }]}>LTP</Text>
        <Text style={[s.colHeadText, { width: 56, textAlign: 'center' }]}>STRIKE</Text>
        <Text style={[s.colHeadText, { width: 44, textAlign: 'left' }]}>LTP</Text>
        <Text style={[s.colHeadText, { flex: 1, textAlign: 'left' }]}>OI</Text>
      </View>

      {/* Strike Table */}
      {isLoading && (
        <View style={s.loadingWrap}>
          <ActivityIndicator color={colors.primary} size="large" />
          <Text style={s.loadingText}>Fetching from NSE…</Text>
        </View>
      )}

      {isError && (
        <View style={s.errorWrap}>
          <Feather name="wifi-off" size={36} color={colors.mutedForeground} />
          <Text style={s.errorTitle}>NSE Unavailable</Text>
          <Text style={s.errorSub}>
            {(error as any)?.message ?? 'NSE may be blocking the request or market is closed.'}
          </Text>
          <TouchableOpacity style={s.retryBtn} onPress={handleRefresh}>
            <Text style={[s.retryText, { color: colors.primary }]}>Retry</Text>
          </TouchableOpacity>
        </View>
      )}

      {data && !isLoading && (
        <ScrollView
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={isFetching} onRefresh={handleRefresh} tintColor={colors.primary} />}
          contentContainerStyle={{ paddingBottom: bottomPad + 100 }}
        >
          {data.strikes.map((strike) => {
            const isAtm = strike.isAtm;
            const isMaxPain = strike.strike === data.maxPain;
            const ceBarW = maxOI > 0 ? strike.ce.oi / maxOI : 0;
            const peBarW = maxOI > 0 ? strike.pe.oi / maxOI : 0;
            const ceOiPos = strike.ce.oiChange > 0;
            const peOiPos = strike.pe.oiChange > 0;

            return (
              <View
                key={strike.strike}
                style={[
                  s.strikeRow,
                  isAtm && { backgroundColor: colors.blue + '15', borderTopColor: colors.blue + '55', borderBottomColor: colors.blue + '55' },
                  isMaxPain && !isAtm && { backgroundColor: colors.amber + '0a' },
                ]}
              >
                {/* CE Side */}
                <View style={s.ceCell}>
                  {/* OI Bar */}
                  <View style={s.oiBarWrapRight}>
                    <View style={[s.oiBarRight, { width: `${ceBarW * 100}%` as any, backgroundColor: colors.rose + '55' }]} />
                  </View>
                  <View style={s.ceLegContent}>
                    <Text style={[s.oiText, { color: strike.ce.oi > 0 ? colors.foreground : colors.mutedForeground }]} numberOfLines={1}>
                      {formatOI(strike.ce.oi)}
                    </Text>
                    {strike.ce.oiChange !== 0 && (
                      <Text style={[s.oiChangeText, { color: ceOiPos ? colors.emerald : colors.rose }]}>
                        {ceOiPos ? '▲' : '▼'}{formatOI(Math.abs(strike.ce.oiChange))}
                      </Text>
                    )}
                  </View>
                </View>

                {/* CE LTP */}
                <Text style={[s.ltpText, { width: 44, textAlign: 'right', color: colors.rose }]} numberOfLines={1}>
                  {strike.ce.ltp > 0 ? formatLTP(strike.ce.ltp) : '—'}
                </Text>

                {/* Strike Price */}
                <View style={[s.strikeCell, isAtm && { backgroundColor: colors.blue + '33', borderRadius: 5 }]}>
                  <Text style={[s.strikeText, isAtm && { color: colors.blue, fontFamily: 'Inter_700Bold' }]}>
                    {strike.strike.toLocaleString('en-IN')}
                  </Text>
                  {isAtm && <Text style={s.atmLabel}>ATM</Text>}
                  {isMaxPain && <Text style={[s.mpLabel, { color: colors.amber }]}>MP</Text>}
                </View>

                {/* PE LTP */}
                <Text style={[s.ltpText, { width: 44, textAlign: 'left', color: colors.emerald }]} numberOfLines={1}>
                  {strike.pe.ltp > 0 ? formatLTP(strike.pe.ltp) : '—'}
                </Text>

                {/* PE Side */}
                <View style={s.peCell}>
                  <View style={s.peLegContent}>
                    <Text style={[s.oiText, { color: strike.pe.oi > 0 ? colors.foreground : colors.mutedForeground }]} numberOfLines={1}>
                      {formatOI(strike.pe.oi)}
                    </Text>
                    {strike.pe.oiChange !== 0 && (
                      <Text style={[s.oiChangeText, { color: peOiPos ? colors.emerald : colors.rose }]}>
                        {peOiPos ? '▲' : '▼'}{formatOI(Math.abs(strike.pe.oiChange))}
                      </Text>
                    )}
                  </View>
                  <View style={s.oiBarWrapLeft}>
                    <View style={[s.oiBarLeft, { width: `${peBarW * 100}%` as any, backgroundColor: colors.emerald + '55' }]} />
                  </View>
                </View>
              </View>
            );
          })}

          {/* Footer */}
          {data.cachedAt && (
            <Text style={s.footerText}>
              Last updated: {new Date(data.cachedAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </Text>
          )}
        </ScrollView>
      )}
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.border },
    headerTitle: { fontSize: 20, fontWeight: '700' as const, color: colors.foreground, fontFamily: 'Inter_700Bold' },
    headerSub: { fontSize: 11, color: colors.mutedForeground, marginTop: 1, fontFamily: 'Inter_400Regular' },
    headerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    countdown: { fontSize: 13, fontFamily: 'Inter_600SemiBold', width: 28, textAlign: 'right' },
    refreshBtn: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
    symbolRow: { flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: colors.border },
    symBtn: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20, borderWidth: 1 },
    symText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
    statsBar: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.card },
    statItem: { flex: 1, alignItems: 'center' },
    statLabel: { fontSize: 8, color: colors.mutedForeground, fontFamily: 'Inter_600SemiBold', letterSpacing: 0.8, marginBottom: 2 },
    statValue: { fontSize: 14, fontFamily: 'Inter_700Bold', color: colors.foreground },
    statSub: { fontSize: 9, fontFamily: 'Inter_500Medium', marginTop: 1 },
    statDivider: { width: 1, height: 28, backgroundColor: colors.border },
    oiBalanceWrap: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: colors.border, gap: 8 },
    oiBalanceLabel: { fontSize: 9, fontFamily: 'Inter_600SemiBold', width: 52 },
    oiBalanceBar: { flex: 1, height: 5, flexDirection: 'row', borderRadius: 3, overflow: 'hidden' },
    oiCeBar: { height: '100%' },
    oiPeBar: { height: '100%' },
    colHeader: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 5, borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.card },
    colHeadText: { fontSize: 8, color: colors.mutedForeground, fontFamily: 'Inter_600SemiBold', letterSpacing: 0.5 },
    strikeRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6, paddingHorizontal: 8, borderBottomWidth: 1, borderBottomColor: colors.border + '40' },
    ceCell: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', overflow: 'hidden' },
    peCell: { flex: 1, flexDirection: 'row', alignItems: 'center', overflow: 'hidden' },
    ceLegContent: { alignItems: 'flex-end', zIndex: 1 },
    peLegContent: { alignItems: 'flex-start', zIndex: 1 },
    oiBarWrapRight: { position: 'absolute', right: 0, top: 0, bottom: 0, left: 0, justifyContent: 'center' },
    oiBarRight: { height: '70%', borderRadius: 2, alignSelf: 'flex-end' },
    oiBarWrapLeft: { position: 'absolute', left: 0, top: 0, bottom: 0, right: 0, justifyContent: 'center' },
    oiBarLeft: { height: '70%', borderRadius: 2, alignSelf: 'flex-start' },
    oiText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
    oiChangeText: { fontSize: 8, fontFamily: 'Inter_400Regular' },
    ltpText: { fontSize: 11, fontFamily: 'Inter_500Medium', color: colors.foreground },
    strikeCell: { width: 56, alignItems: 'center', paddingVertical: 2 },
    strikeText: { fontSize: 12, fontFamily: 'Inter_600SemiBold', color: colors.foreground, textAlign: 'center' },
    atmLabel: { fontSize: 7, color: colors.blue, fontFamily: 'Inter_700Bold', letterSpacing: 0.5, marginTop: 1 },
    mpLabel: { fontSize: 7, fontFamily: 'Inter_700Bold', letterSpacing: 0.5, marginTop: 1 },
    loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingTop: 80 },
    loadingText: { fontSize: 14, color: colors.mutedForeground, fontFamily: 'Inter_400Regular' },
    errorWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10, paddingHorizontal: 40, paddingTop: 80 },
    errorTitle: { fontSize: 17, fontFamily: 'Inter_700Bold', color: colors.foreground },
    errorSub: { fontSize: 13, color: colors.mutedForeground, fontFamily: 'Inter_400Regular', textAlign: 'center', lineHeight: 20 },
    retryBtn: { marginTop: 8, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 8, borderWidth: 1, borderColor: colors.primary + '55' },
    retryText: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
    footerText: { fontSize: 10, color: colors.mutedForeground, textAlign: 'center', paddingVertical: 16, fontFamily: 'Inter_400Regular' },
    modeBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 10, borderWidth: 1 },
    modeDot: { width: 5, height: 5, borderRadius: 3 },
    modeText: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.5 },
  });
}
