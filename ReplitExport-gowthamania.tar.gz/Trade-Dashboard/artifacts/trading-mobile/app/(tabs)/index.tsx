import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  Platform, ActivityIndicator,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, Feather } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useColors } from '@/hooks/useColors';
import { useTradesContext } from '@/context/TradesContext';

const CHECKLIST_KEY = 'nse_checklist_v1';

const CHECKLIST_ITEMS = [
  'Check GIFT Nifty & US Futures',
  'Review FII/DII data',
  'Mark key S/R levels on chart',
  'Scan pre-market top gainers/losers',
  'Load 4-chart TradingView layout',
];

const INDICES = [
  { name: 'NIFTY 50', value: '24,853', change: '+213.40', pct: '+0.87%', positive: true, low: '24,598', high: '24,891' },
  { name: 'BANK NIFTY', value: '55,342', change: '+641.25', pct: '+1.17%', positive: true, low: '54,710', high: '55,490' },
  { name: 'SENSEX', value: '81,721', change: '+698.40', pct: '+0.86%', positive: true, low: '80,940', high: '81,805' },
];

const SESSIONS = [
  { label: 'Pre-Open', time: '9:00', width: 0.05, color: '#f59e0b' },
  { label: 'Opening', time: '9:15', width: 0.06, color: '#10b981' },
  { label: 'Power Hour', time: '9:30', width: 0.16, color: '#10b981' },
  { label: 'Mid', time: '10:30', width: 0.40, color: '#1f2937' },
  { label: 'Close PH', time: '14:00', width: 0.26, color: '#10b981' },
  { label: 'Close', time: '15:30', width: 0.07, color: '#1f2937' },
];

const today = new Date().toLocaleDateString('en-IN', { weekday: 'short', month: 'short', day: 'numeric' });

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { trades, isLoaded } = useTradesContext();
  const [checked, setChecked] = useState<boolean[]>(new Array(CHECKLIST_ITEMS.length).fill(false));

  const isWeb = Platform.OS === 'web';
  const topPad = isWeb ? 67 : insets.top;
  const bottomPad = isWeb ? 34 : 0;

  useEffect(() => {
    AsyncStorage.getItem(CHECKLIST_KEY).then(raw => {
      if (raw) {
        try { setChecked(JSON.parse(raw)); } catch {}
      }
    });
  }, []);

  const toggleCheck = (i: number) => {
    setChecked(prev => {
      const next = [...prev];
      next[i] = !next[i];
      AsyncStorage.setItem(CHECKLIST_KEY, JSON.stringify(next));
      return next;
    });
  };

  const todayTrades = trades.filter(t => t.date === new Date().toISOString().slice(0, 10));
  const todayPnL = todayTrades.reduce((s, t) => s + t.pnl, 0);
  const checkedCount = checked.filter(Boolean).length;

  const s = makeStyles(colors);

  return (
    <View style={[s.root, { paddingTop: topPad }]}>
      {/* Header */}
      <View style={s.header}>
        <View>
          <Text style={s.headerTitle}>Today's Game Plan</Text>
          <Text style={s.headerSub}>{today}</Text>
        </View>
        <View style={s.liveBadge}>
          <View style={s.liveDot} />
          <Text style={s.liveText}>NSE LIVE</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={[s.scroll, { paddingBottom: bottomPad + 100 }]}>

        {/* Market Index Cards */}
        <Text style={s.sectionLabel}>MARKET CONTEXT</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.indexRow}>
          {INDICES.map((idx) => (
            <View key={idx.name} style={s.indexCard}>
              <View style={s.indexCardTop}>
                <Text style={s.indexName}>{idx.name}</Text>
                <Ionicons
                  name={idx.positive ? 'trending-up' : 'trending-down'}
                  size={16}
                  color={idx.positive ? colors.emerald : colors.rose}
                />
              </View>
              <Text style={s.indexValue}>{idx.value}</Text>
              <Text style={[s.indexChange, { color: idx.positive ? colors.emerald : colors.rose }]}>
                {idx.change} ({idx.pct})
              </Text>
              <View style={s.indexRange}>
                <View style={[s.indexRangeBar, { backgroundColor: colors.border }]}>
                  <View style={[s.indexRangeFill, {
                    backgroundColor: idx.positive ? colors.emerald : colors.rose,
                    width: '72%',
                  }]} />
                </View>
                <View style={s.indexRangeLabels}>
                  <Text style={s.indexRangeText}>{idx.low}</Text>
                  <Text style={s.indexRangeText}>{idx.high}</Text>
                </View>
              </View>
            </View>
          ))}
        </ScrollView>

        {/* Today's P&L Quick Card */}
        {isLoaded && (
          <View style={[s.pnlCard, { borderColor: todayPnL >= 0 ? colors.emerald + '44' : colors.rose + '44', backgroundColor: todayPnL >= 0 ? '#10b98111' : '#ef444411' }]}>
            <View style={s.pnlCardRow}>
              <View>
                <Text style={s.pnlLabel}>TODAY'S P&L</Text>
                <Text style={[s.pnlValue, { color: todayPnL >= 0 ? colors.emerald : colors.rose }]}>
                  {todayPnL >= 0 ? '+' : ''}₹{Math.abs(todayPnL).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                </Text>
              </View>
              <View style={s.pnlRight}>
                <Text style={s.pnlTrades}>{todayTrades.length} trades</Text>
                <Ionicons name="stats-chart" size={22} color={todayPnL >= 0 ? colors.emerald : colors.rose} />
              </View>
            </View>
          </View>
        )}

        {/* Session Timeline */}
        <Text style={[s.sectionLabel, { marginTop: 20 }]}>MARKET SESSION TIMELINE</Text>
        <View style={s.timelineCard}>
          <View style={s.timelineBar}>
            {SESSIONS.map((s2, i) => (
              <View key={i} style={[s.timelineSegment, { flex: s2.width * 100, backgroundColor: s2.color }]} />
            ))}
          </View>
          <View style={s.timelineLabels}>
            {SESSIONS.map((s2, i) => (
              <View key={i} style={[s.timelineLabelItem, { flex: s2.width * 100 }]}>
                <Text style={s.timelineTime} numberOfLines={1}>{s2.time}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Pre-Market Checklist */}
        <View style={s.sectionRow}>
          <Text style={s.sectionLabel}>PRE-MARKET CHECKLIST</Text>
          <Text style={[s.sectionBadge, { color: checkedCount === CHECKLIST_ITEMS.length ? colors.emerald : colors.amber }]}>
            {checkedCount}/{CHECKLIST_ITEMS.length}
          </Text>
        </View>
        <View style={s.checklistCard}>
          {CHECKLIST_ITEMS.map((item, i) => (
            <TouchableOpacity key={i} style={s.checklistRow} onPress={() => toggleCheck(i)} activeOpacity={0.7}>
              <View style={[s.checkbox, { borderColor: checked[i] ? colors.emerald : colors.border, backgroundColor: checked[i] ? colors.emerald + '22' : 'transparent' }]}>
                {checked[i] && <Ionicons name="checkmark" size={12} color={colors.emerald} />}
              </View>
              <Text style={[s.checklistText, { color: checked[i] ? colors.mutedForeground : colors.foreground, textDecorationLine: checked[i] ? 'line-through' : 'none' }]}>
                {item}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Sectors */}
        <Text style={[s.sectionLabel, { marginTop: 20 }]}>SECTORS IN PLAY</Text>
        <View style={s.sectorCard}>
          {[
            { name: 'NIFTY IT', pct: '+1.85%', bar: 0.85, positive: true },
            { name: 'NIFTY AUTO', pct: '+1.20%', bar: 0.65, positive: true },
            { name: 'NIFTY PHARMA', pct: '-0.75%', bar: 0.28, positive: false },
          ].map((sec) => (
            <View key={sec.name} style={s.sectorRow}>
              <Text style={[s.sectorName, { color: sec.positive ? colors.blue : colors.rose }]}>{sec.name}</Text>
              <View style={s.sectorBarWrap}>
                <View style={[s.sectorBarBg, { backgroundColor: colors.border }]}>
                  <View style={[s.sectorBarFill, { width: `${sec.bar * 100}%` as any, backgroundColor: sec.positive ? colors.emerald : colors.rose }]} />
                </View>
              </View>
              <Text style={[s.sectorPct, { color: sec.positive ? colors.emerald : colors.rose }]}>{sec.pct}</Text>
            </View>
          ))}
        </View>

      </ScrollView>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.border },
    headerTitle: { fontSize: 22, fontWeight: '700' as const, color: colors.foreground, fontFamily: 'Inter_700Bold' },
    headerSub: { fontSize: 12, color: colors.mutedForeground, marginTop: 1, fontFamily: 'Inter_400Regular' },
    liveBadge: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, borderWidth: 1, borderColor: colors.emerald + '44', backgroundColor: colors.emerald + '11' },
    liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.emerald },
    liveText: { fontSize: 11, color: colors.emerald, fontFamily: 'Inter_600SemiBold', letterSpacing: 0.5 },
    scroll: { paddingHorizontal: 16, paddingTop: 16 },
    sectionLabel: { fontSize: 10, fontFamily: 'Inter_600SemiBold', color: colors.mutedForeground, letterSpacing: 1, marginBottom: 10, marginTop: 4 },
    sectionRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 20 },
    sectionBadge: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
    indexRow: { paddingRight: 16, gap: 10, paddingBottom: 4 },
    indexCard: { width: 165, backgroundColor: colors.card, borderRadius: 10, borderWidth: 1, borderColor: colors.border, padding: 14 },
    indexCardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
    indexName: { fontSize: 11, color: colors.mutedForeground, fontFamily: 'Inter_500Medium', letterSpacing: 0.3 },
    indexValue: { fontSize: 20, fontFamily: 'Inter_700Bold', color: colors.foreground, marginVertical: 2 },
    indexChange: { fontSize: 12, fontFamily: 'Inter_500Medium' },
    indexRange: { marginTop: 10 },
    indexRangeBar: { height: 3, borderRadius: 2, overflow: 'hidden' },
    indexRangeFill: { height: '100%', borderRadius: 2 },
    indexRangeLabels: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 },
    indexRangeText: { fontSize: 9, color: colors.mutedForeground, fontFamily: 'Inter_400Regular' },
    pnlCard: { borderRadius: 10, borderWidth: 1, padding: 14, marginTop: 12 },
    pnlCardRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    pnlLabel: { fontSize: 10, color: colors.mutedForeground, fontFamily: 'Inter_500Medium', letterSpacing: 1, marginBottom: 4 },
    pnlValue: { fontSize: 26, fontFamily: 'Inter_700Bold' },
    pnlRight: { alignItems: 'flex-end', gap: 4 },
    pnlTrades: { fontSize: 12, color: colors.mutedForeground, fontFamily: 'Inter_400Regular' },
    timelineCard: { backgroundColor: colors.card, borderRadius: 10, borderWidth: 1, borderColor: colors.border, padding: 14, marginBottom: 4 },
    timelineBar: { flexDirection: 'row', height: 8, borderRadius: 4, overflow: 'hidden' },
    timelineSegment: { height: '100%' },
    timelineLabels: { flexDirection: 'row', marginTop: 6 },
    timelineLabelItem: { alignItems: 'flex-start' },
    timelineTime: { fontSize: 9, color: colors.mutedForeground, fontFamily: 'Inter_400Regular' },
    checklistCard: { backgroundColor: colors.card, borderRadius: 10, borderWidth: 1, borderColor: colors.border, overflow: 'hidden' },
    checklistRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: colors.border + '80' },
    checkbox: { width: 18, height: 18, borderRadius: 4, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
    checklistText: { flex: 1, fontSize: 14, fontFamily: 'Inter_400Regular' },
    sectorCard: { backgroundColor: colors.card, borderRadius: 10, borderWidth: 1, borderColor: colors.border, padding: 14, gap: 14 },
    sectorRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
    sectorName: { width: 100, fontSize: 12, fontFamily: 'Inter_600SemiBold' },
    sectorBarWrap: { flex: 1 },
    sectorBarBg: { height: 4, borderRadius: 2, overflow: 'hidden' },
    sectorBarFill: { height: '100%', borderRadius: 2 },
    sectorPct: { width: 50, fontSize: 12, fontFamily: 'Inter_500Medium', textAlign: 'right' },
  });
}
