import React, { useState } from 'react';
import {
  View, Text, FlatList, StyleSheet, TouchableOpacity,
  Modal, ScrollView, TextInput, Platform, Alert,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons, Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/useColors';
import { useTradesContext, Trade } from '@/context/TradesContext';
import { KeyboardAwareScrollView } from 'react-native-keyboard-controller';

const SETUPS = ['VWAP Reclaim', 'VWAP Rejection', 'BB Breakout', 'BB Reversal', 'RSI Divergence', 'Opening Range Breakout', 'Gap & Go', 'Gap Fill', 'PDH/PDL Break', 'Trend Pullback', 'Other'];
const EMOTIONS = ['Calm', 'Confident', 'Hesitant', 'Greedy', 'FOMO', 'Revenge Trade'];

interface FormState {
  date: string;
  symbol: string;
  direction: 'LONG' | 'SHORT';
  setupType: string;
  entryPrice: string;
  exitPrice: string;
  qty: string;
  riskAmt: string;
  emotion: string;
  notes: string;
}

const today = new Date().toISOString().slice(0, 10);

const defaultForm: FormState = {
  date: today,
  symbol: '',
  direction: 'LONG',
  setupType: '',
  entryPrice: '',
  exitPrice: '',
  qty: '',
  riskAmt: '',
  emotion: 'Calm',
  notes: '',
};

function calcStats(trades: Trade[]) {
  if (!trades.length) return { totalPnl: 0, winRate: 0, avgRR: 0, wins: 0, losses: 0 };
  const wins = trades.filter(t => t.pnl > 0);
  const losses = trades.filter(t => t.pnl < 0);
  const totalPnl = trades.reduce((s, t) => s + t.pnl, 0);
  const winRate = (wins.length / trades.length) * 100;
  const avgRR = wins.length > 0 ? wins.reduce((s, t) => s + t.riskReward, 0) / wins.length : 0;
  return { totalPnl, winRate, avgRR, wins: wins.length, losses: losses.length };
}

export default function JournalScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { trades, addTrade, deleteTrade, isLoaded } = useTradesContext();
  const [modalVisible, setModalVisible] = useState(false);
  const [form, setForm] = useState<FormState>(defaultForm);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const isWeb = Platform.OS === 'web';
  const topPad = isWeb ? 67 : insets.top;
  const bottomPad = isWeb ? 34 : 0;

  const setF = (k: keyof FormState, v: string) => setForm(f => ({ ...f, [k]: v }));

  const derivedPnL = () => {
    const entry = parseFloat(form.entryPrice);
    const exit = parseFloat(form.exitPrice);
    const qty = parseFloat(form.qty);
    if (!entry || !exit || !qty) return null;
    const pnl = form.direction === 'LONG' ? (exit - entry) * qty : (entry - exit) * qty;
    const pct = form.direction === 'LONG' ? ((exit - entry) / entry) * 100 : ((entry - exit) / entry) * 100;
    return { pnl: parseFloat(pnl.toFixed(2)), pct: parseFloat(pct.toFixed(2)) };
  };

  const derivedRR = () => {
    const risk = parseFloat(form.riskAmt);
    const d = derivedPnL();
    if (!risk || !d) return null;
    return parseFloat((d.pnl / risk).toFixed(2));
  };

  const handleSubmit = () => {
    if (!form.symbol || !form.entryPrice || !form.exitPrice || !form.qty || !form.setupType) {
      Alert.alert('Missing fields', 'Please fill in symbol, entry, exit, quantity and setup type.');
      return;
    }
    const d = derivedPnL();
    if (!d) return;
    const rr = derivedRR() ?? 0;
    addTrade({
      date: form.date,
      symbol: form.symbol.toUpperCase(),
      direction: form.direction,
      setupType: form.setupType,
      entryPrice: parseFloat(form.entryPrice),
      exitPrice: parseFloat(form.exitPrice),
      qty: parseFloat(form.qty),
      pnl: d.pnl,
      pnlPct: d.pct,
      riskReward: rr,
      emotion: form.emotion,
      notes: form.notes,
    });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setModalVisible(false);
    setForm(defaultForm);
  };

  const handleDelete = (id: string) => {
    Alert.alert('Delete Trade', 'Remove this trade from your journal?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => { deleteTrade(id); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); } },
    ]);
  };

  const stats = calcStats(trades);
  const estimated = derivedPnL();
  const rr = derivedRR();
  const s = makeStyles(colors);

  const renderTrade = ({ item }: { item: Trade }) => {
    const isExpanded = expandedId === item.id;
    const isWin = item.pnl >= 0;
    return (
      <TouchableOpacity style={s.tradeRow} onPress={() => setExpandedId(isExpanded ? null : item.id)} activeOpacity={0.75}>
        <View style={s.tradeMain}>
          <View style={[s.dirBadge, { backgroundColor: isWin ? colors.emerald + '22' : colors.rose + '22', borderColor: isWin ? colors.emerald + '55' : colors.rose + '55' }]}>
            <Text style={[s.dirText, { color: isWin ? colors.emerald : colors.rose }]}>{item.direction}</Text>
          </View>
          <View style={s.tradeInfo}>
            <Text style={s.tradeSymbol}>{item.symbol}</Text>
            <Text style={s.tradeSetup}>{item.setupType}</Text>
          </View>
          <View style={s.tradeRight}>
            <Text style={[s.tradePnl, { color: isWin ? colors.emerald : colors.rose }]}>
              {isWin ? '+' : ''}₹{Math.abs(item.pnl).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </Text>
            <Text style={s.tradeDate}>{item.date.slice(5)}</Text>
          </View>
          <Ionicons name={isExpanded ? 'chevron-up' : 'chevron-down'} size={14} color={colors.mutedForeground} />
        </View>
        {isExpanded && (
          <View style={s.tradeExpanded}>
            <View style={s.expandedGrid}>
              <MiniStat label="Entry" value={`₹${item.entryPrice}`} colors={colors} />
              <MiniStat label="Exit" value={`₹${item.exitPrice}`} colors={colors} />
              <MiniStat label="Qty" value={`${item.qty}`} colors={colors} />
              <MiniStat label="R:R" value={item.riskReward > 0 ? `${item.riskReward}R` : '—'} colors={colors} positive={item.riskReward >= 1} colored />
              <MiniStat label="Mindset" value={item.emotion} colors={colors} highlight={['FOMO', 'Greedy', 'Revenge Trade'].includes(item.emotion)} />
              <MiniStat label="P&L %" value={`${item.pnlPct >= 0 ? '+' : ''}${item.pnlPct}%`} colors={colors} colored positive={item.pnlPct >= 0} />
            </View>
            {item.notes ? <Text style={s.expandedNotes}>{item.notes}</Text> : null}
            <TouchableOpacity style={s.deleteBtn} onPress={() => handleDelete(item.id)}>
              <Feather name="trash-2" size={14} color={colors.rose} />
              <Text style={[s.deleteBtnText, { color: colors.rose }]}>Remove</Text>
            </TouchableOpacity>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <View style={[s.root, { paddingTop: topPad }]}>
      {/* Header */}
      <View style={s.header}>
        <View>
          <Text style={s.headerTitle}>Trade Journal</Text>
          <Text style={s.headerSub}>{trades.length} trades logged</Text>
        </View>
        <TouchableOpacity style={s.addBtn} onPress={() => { setModalVisible(true); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); }} testID="button-log-trade">
          <Ionicons name="add" size={20} color={colors.background} />
        </TouchableOpacity>
      </View>

      {/* Stats Row */}
      <View style={s.statsRow}>
        <StatPill label="P&L" value={`${stats.totalPnl >= 0 ? '+' : ''}₹${Math.abs(stats.totalPnl).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`} positive={stats.totalPnl >= 0} colors={colors} />
        <StatPill label="Win %" value={`${stats.winRate.toFixed(0)}%`} positive={stats.winRate >= 50} colors={colors} />
        <StatPill label="Avg R:R" value={stats.avgRR.toFixed(1)} positive={stats.avgRR >= 1.5} colors={colors} />
        <StatPill label="W/L" value={`${stats.wins}/${stats.losses}`} positive colors={colors} />
      </View>

      {/* Trade List */}
      <FlatList
        data={trades}
        keyExtractor={item => item.id}
        renderItem={renderTrade}
        scrollEnabled={!!trades.length}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[s.list, { paddingBottom: bottomPad + 100 }]}
        ListEmptyComponent={
          <View style={s.emptyState}>
            <Feather name="book-open" size={40} color={colors.mutedForeground} />
            <Text style={s.emptyText}>No trades yet</Text>
            <Text style={s.emptySub}>Tap + to log your first trade</Text>
          </View>
        }
      />

      {/* Add Trade Modal */}
      <Modal visible={modalVisible} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setModalVisible(false)}>
        <View style={[s.modalRoot, { paddingTop: isWeb ? 67 : 20 }]}>
          <View style={s.modalHeader}>
            <Text style={s.modalTitle}>Log Trade</Text>
            <TouchableOpacity onPress={() => setModalVisible(false)}>
              <Ionicons name="close" size={22} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>
          <KeyboardAwareScrollView style={s.modalScroll} contentContainerStyle={s.modalContent} keyboardShouldPersistTaps="handled">

            {/* Date + Symbol */}
            <View style={s.formRow}>
              <View style={s.formField}>
                <Text style={s.formLabel}>DATE</Text>
                <TextInput style={s.input} value={form.date} onChangeText={v => setF('date', v)} placeholderTextColor={colors.mutedForeground} />
              </View>
              <View style={s.formField}>
                <Text style={s.formLabel}>SYMBOL</Text>
                <TextInput style={[s.input, { textTransform: 'uppercase' }]} value={form.symbol} onChangeText={v => setF('symbol', v)} placeholder="RELIANCE" placeholderTextColor={colors.mutedForeground} autoCapitalize="characters" testID="input-symbol" />
              </View>
            </View>

            {/* Direction */}
            <Text style={s.formLabel}>DIRECTION</Text>
            <View style={s.dirRow}>
              {(['LONG', 'SHORT'] as const).map(d => (
                <TouchableOpacity key={d} style={[s.dirOption, { borderColor: form.direction === d ? (d === 'LONG' ? colors.emerald : colors.rose) : colors.border, backgroundColor: form.direction === d ? (d === 'LONG' ? colors.emerald + '22' : colors.rose + '22') : 'transparent' }]} onPress={() => setF('direction', d)}>
                  <Text style={[s.dirOptionText, { color: form.direction === d ? (d === 'LONG' ? colors.emerald : colors.rose) : colors.mutedForeground }]}>{d}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Setup Type */}
            <Text style={s.formLabel}>SETUP TYPE</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.chipRow}>
              {SETUPS.map(setup => (
                <TouchableOpacity key={setup} style={[s.chip, { borderColor: form.setupType === setup ? colors.primary : colors.border, backgroundColor: form.setupType === setup ? colors.primary + '22' : 'transparent' }]} onPress={() => setF('setupType', setup)}>
                  <Text style={[s.chipText, { color: form.setupType === setup ? colors.primary : colors.mutedForeground }]}>{setup}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {/* Entry / Exit / Qty */}
            <View style={s.formRow}>
              <View style={s.formFieldThird}>
                <Text style={s.formLabel}>ENTRY ₹</Text>
                <TextInput style={s.input} value={form.entryPrice} onChangeText={v => setF('entryPrice', v)} keyboardType="decimal-pad" placeholder="0.00" placeholderTextColor={colors.mutedForeground} testID="input-entry" />
              </View>
              <View style={s.formFieldThird}>
                <Text style={s.formLabel}>EXIT ₹</Text>
                <TextInput style={s.input} value={form.exitPrice} onChangeText={v => setF('exitPrice', v)} keyboardType="decimal-pad" placeholder="0.00" placeholderTextColor={colors.mutedForeground} testID="input-exit" />
              </View>
              <View style={s.formFieldThird}>
                <Text style={s.formLabel}>QTY</Text>
                <TextInput style={s.input} value={form.qty} onChangeText={v => setF('qty', v)} keyboardType="decimal-pad" placeholder="0" placeholderTextColor={colors.mutedForeground} testID="input-qty" />
              </View>
            </View>

            {/* Live P&L Preview */}
            {estimated && (
              <View style={[s.pnlPreview, { backgroundColor: estimated.pnl >= 0 ? colors.emerald + '11' : colors.rose + '11', borderColor: estimated.pnl >= 0 ? colors.emerald + '44' : colors.rose + '44' }]}>
                <Text style={s.pnlPreviewLabel}>EST. P&L</Text>
                <Text style={[s.pnlPreviewValue, { color: estimated.pnl >= 0 ? colors.emerald : colors.rose }]}>
                  {estimated.pnl >= 0 ? '+' : ''}₹{estimated.pnl.toLocaleString('en-IN')} ({estimated.pct >= 0 ? '+' : ''}{estimated.pct}%)
                </Text>
              </View>
            )}

            {/* Risk / Emotion */}
            <View style={s.formRow}>
              <View style={s.formField}>
                <Text style={s.formLabel}>RISK ₹ (for R:R)</Text>
                <TextInput style={s.input} value={form.riskAmt} onChangeText={v => setF('riskAmt', v)} keyboardType="decimal-pad" placeholder="Optional" placeholderTextColor={colors.mutedForeground} />
                {rr !== null && <Text style={[s.rrLabel, { color: rr >= 1 ? colors.emerald : colors.rose }]}>R:R = {rr}</Text>}
              </View>
            </View>

            {/* Emotion */}
            <Text style={s.formLabel}>MINDSET</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.chipRow}>
              {EMOTIONS.map(e => (
                <TouchableOpacity key={e} style={[s.chip, { borderColor: form.emotion === e ? colors.amber : colors.border, backgroundColor: form.emotion === e ? colors.amber + '22' : 'transparent' }]} onPress={() => setF('emotion', e)}>
                  <Text style={[s.chipText, { color: form.emotion === e ? colors.amber : colors.mutedForeground }]}>{e}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {/* Notes */}
            <Text style={s.formLabel}>NOTES</Text>
            <TextInput style={[s.input, s.notesInput]} value={form.notes} onChangeText={v => setF('notes', v)} placeholder="What did you observe? What to improve?" placeholderTextColor={colors.mutedForeground} multiline numberOfLines={3} textAlignVertical="top" testID="input-notes" />

            {/* Submit */}
            <TouchableOpacity style={s.submitBtn} onPress={handleSubmit} testID="button-submit">
              <Text style={s.submitText}>Add to Journal</Text>
            </TouchableOpacity>

          </KeyboardAwareScrollView>
        </View>
      </Modal>
    </View>
  );
}

function StatPill({ label, value, positive, colors }: { label: string; value: string; positive: boolean; colors: any }) {
  return (
    <View style={{ alignItems: 'center', flex: 1 }}>
      <Text style={{ fontSize: 9, color: colors.mutedForeground, fontFamily: 'Inter_500Medium', letterSpacing: 0.5, marginBottom: 2 }}>{label}</Text>
      <Text style={{ fontSize: 14, fontFamily: 'Inter_700Bold', color: positive ? colors.emerald : colors.rose }}>{value}</Text>
    </View>
  );
}

function MiniStat({ label, value, colors, colored, positive, highlight }: { label: string; value: string; colors: any; colored?: boolean; positive?: boolean; highlight?: boolean }) {
  return (
    <View style={{ minWidth: '30%' }}>
      <Text style={{ fontSize: 9, color: colors.mutedForeground, fontFamily: 'Inter_500Medium', letterSpacing: 0.5, marginBottom: 2 }}>{label}</Text>
      <Text style={{ fontSize: 12, fontFamily: 'Inter_500Medium', color: colored ? (positive ? colors.emerald : colors.rose) : highlight ? colors.amber : colors.foreground }}>{value}</Text>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.border },
    headerTitle: { fontSize: 22, fontWeight: '700' as const, color: colors.foreground, fontFamily: 'Inter_700Bold' },
    headerSub: { fontSize: 12, color: colors.mutedForeground, marginTop: 1, fontFamily: 'Inter_400Regular' },
    addBtn: { width: 38, height: 38, borderRadius: 10, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
    statsRow: { flexDirection: 'row', paddingVertical: 12, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.card },
    list: { paddingHorizontal: 16, paddingTop: 8 },
    tradeRow: { backgroundColor: colors.card, borderRadius: 10, borderWidth: 1, borderColor: colors.border, marginTop: 8, overflow: 'hidden' },
    tradeMain: { flexDirection: 'row', alignItems: 'center', padding: 12, gap: 10 },
    dirBadge: { paddingHorizontal: 7, paddingVertical: 3, borderRadius: 5, borderWidth: 1 },
    dirText: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 0.5 },
    tradeInfo: { flex: 1 },
    tradeSymbol: { fontSize: 14, fontFamily: 'Inter_700Bold', color: colors.foreground },
    tradeSetup: { fontSize: 11, color: colors.mutedForeground, fontFamily: 'Inter_400Regular', marginTop: 1 },
    tradeRight: { alignItems: 'flex-end', marginRight: 6 },
    tradePnl: { fontSize: 15, fontFamily: 'Inter_700Bold' },
    tradeDate: { fontSize: 10, color: colors.mutedForeground, fontFamily: 'Inter_400Regular', marginTop: 1 },
    tradeExpanded: { paddingHorizontal: 12, paddingBottom: 12, borderTopWidth: 1, borderTopColor: colors.border + '80', paddingTop: 10 },
    expandedGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 8 },
    expandedNotes: { fontSize: 12, color: colors.mutedForeground, fontFamily: 'Inter_400Regular', lineHeight: 18, marginTop: 4, marginBottom: 8 },
    deleteBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, alignSelf: 'flex-start', paddingVertical: 4 },
    deleteBtnText: { fontSize: 12, fontFamily: 'Inter_500Medium' },
    emptyState: { alignItems: 'center', paddingTop: 80, gap: 10 },
    emptyText: { fontSize: 16, fontFamily: 'Inter_600SemiBold', color: colors.foreground },
    emptySub: { fontSize: 13, color: colors.mutedForeground, fontFamily: 'Inter_400Regular' },
    modalRoot: { flex: 1, backgroundColor: colors.background },
    modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: colors.border },
    modalTitle: { fontSize: 18, fontFamily: 'Inter_700Bold', color: colors.foreground },
    modalScroll: { flex: 1 },
    modalContent: { padding: 20, gap: 12, paddingBottom: 60 },
    formRow: { flexDirection: 'row', gap: 10 },
    formField: { flex: 1 },
    formFieldThird: { flex: 1 },
    formLabel: { fontSize: 10, fontFamily: 'Inter_600SemiBold', color: colors.mutedForeground, letterSpacing: 0.8, marginBottom: 5 },
    input: { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14, color: colors.foreground, fontFamily: 'Inter_400Regular' },
    notesInput: { height: 80, paddingTop: 10 },
    dirRow: { flexDirection: 'row', gap: 10, marginBottom: 4 },
    dirOption: { flex: 1, paddingVertical: 10, borderRadius: 8, borderWidth: 1.5, alignItems: 'center' },
    dirOptionText: { fontSize: 13, fontFamily: 'Inter_700Bold', letterSpacing: 0.5 },
    chipRow: { gap: 8, paddingVertical: 4, paddingBottom: 4 },
    chip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, borderWidth: 1 },
    chipText: { fontSize: 12, fontFamily: 'Inter_500Medium' },
    pnlPreview: { borderRadius: 8, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 10, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    pnlPreviewLabel: { fontSize: 10, fontFamily: 'Inter_600SemiBold', color: '#9ca3af', letterSpacing: 0.8 },
    pnlPreviewValue: { fontSize: 15, fontFamily: 'Inter_700Bold' },
    rrLabel: { fontSize: 11, marginTop: 4, fontFamily: 'Inter_500Medium' },
    submitBtn: { backgroundColor: colors.primary, borderRadius: 10, paddingVertical: 14, alignItems: 'center', marginTop: 8 },
    submitText: { fontSize: 15, fontFamily: 'Inter_700Bold', color: colors.background },
  });
}
