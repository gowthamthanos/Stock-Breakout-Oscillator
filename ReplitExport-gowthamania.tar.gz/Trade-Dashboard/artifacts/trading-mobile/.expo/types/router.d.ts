/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string | object = string> {
      hrefInputParams: { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `${'/(tabs)'}` | `/`; params?: Router.UnknownInputParams; } | { pathname: `${'/(tabs)'}/journal` | `/journal`; params?: Router.UnknownInputParams; } | { pathname: `${'/(tabs)'}/options` | `/options`; params?: Router.UnknownInputParams; } | { pathname: `${'/(tabs)'}/stats` | `/stats`; params?: Router.UnknownInputParams; } | { pathname: `/+not-found`, params: Router.UnknownInputParams & {  } };
      hrefOutputParams: { pathname: Router.RelativePathString, params?: Router.UnknownOutputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownOutputParams } | { pathname: `/_sitemap`; params?: Router.UnknownOutputParams; } | { pathname: `${'/(tabs)'}` | `/`; params?: Router.UnknownOutputParams; } | { pathname: `${'/(tabs)'}/journal` | `/journal`; params?: Router.UnknownOutputParams; } | { pathname: `${'/(tabs)'}/options` | `/options`; params?: Router.UnknownOutputParams; } | { pathname: `${'/(tabs)'}/stats` | `/stats`; params?: Router.UnknownOutputParams; } | { pathname: `/+not-found`, params: Router.UnknownOutputParams & {  } };
      href: Router.RelativePathString | Router.ExternalPathString | `/_sitemap${`?${string}` | `#${string}` | ''}` | `${'/(tabs)'}${`?${string}` | `#${string}` | ''}` | `/${`?${string}` | `#${string}` | ''}` | `${'/(tabs)'}/journal${`?${string}` | `#${string}` | ''}` | `/journal${`?${string}` | `#${string}` | ''}` | `${'/(tabs)'}/options${`?${string}` | `#${string}` | ''}` | `/options${`?${string}` | `#${string}` | ''}` | `${'/(tabs)'}/stats${`?${string}` | `#${string}` | ''}` | `/stats${`?${string}` | `#${string}` | ''}` | { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `${'/(tabs)'}` | `/`; params?: Router.UnknownInputParams; } | { pathname: `${'/(tabs)'}/journal` | `/journal`; params?: Router.UnknownInputParams; } | { pathname: `${'/(tabs)'}/options` | `/options`; params?: Router.UnknownInputParams; } | { pathname: `${'/(tabs)'}/stats` | `/stats`; params?: Router.UnknownInputParams; } | `/+not-found${`?${string}` | `#${string}` | ''}` | { pathname: `/+not-found`, params: Router.UnknownInputParams & {  } };
    }
  }
}
