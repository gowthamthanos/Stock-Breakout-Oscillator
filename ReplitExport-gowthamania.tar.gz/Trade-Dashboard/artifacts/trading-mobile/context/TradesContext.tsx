import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Trade {
  id: string;
  date: string;
  symbol: string;
  direction: 'LONG' | 'SHORT';
  setupType: string;
  entryPrice: number;
  exitPrice: number;
  qty: number;
  pnl: number;
  pnlPct: number;
  riskReward: number;
  emotion: string;
  notes: string;
}

interface TradesContextType {
  trades: Trade[];
  addTrade: (trade: Omit<Trade, 'id'>) => void;
  deleteTrade: (id: string) => void;
  isLoaded: boolean;
}

const STORAGE_KEY = 'nse_trade_journal_v1';

const SEED_TRADES: Trade[] = [
  { id: '1', date: '2026-05-24', symbol: 'RELIANCE', direction: 'LONG', setupType: 'VWAP Reclaim', entryPrice: 2845.50, exitPrice: 2878.30, qty: 20, pnl: 656, pnlPct: 1.15, riskReward: 2.4, emotion: 'Calm', notes: 'Clean VWAP reclaim after 10:15 pullback. Strong volume confirmation.' },
  { id: '2', date: '2026-05-24', symbol: 'HDFC BANK', direction: 'SHORT', setupType: 'BB Reversal', entryPrice: 1724.80, exitPrice: 1712.20, qty: 30, pnl: 378, pnlPct: 0.73, riskReward: 1.8, emotion: 'Confident', notes: 'Price rejected upper BB near PDH.' },
  { id: '3', date: '2026-05-23', symbol: 'INFOSYS', direction: 'LONG', setupType: 'Gap & Go', entryPrice: 1562.10, exitPrice: 1548.40, qty: 25, pnl: -342.5, pnlPct: -0.88, riskReward: -0.7, emotion: 'FOMO', notes: 'Chased entry too late. Lesson: wait for confirmation.' },
  { id: '4', date: '2026-05-23', symbol: 'BAJFINANCE', direction: 'LONG', setupType: 'Opening Range Breakout', entryPrice: 6820.00, exitPrice: 6895.50, qty: 10, pnl: 755, pnlPct: 1.11, riskReward: 3.1, emotion: 'Calm', notes: 'Textbook ORB. Held through first pullback.' },
  { id: '5', date: '2026-05-22', symbol: 'SBIN', direction: 'SHORT', setupType: 'PDH/PDL Break', entryPrice: 812.40, exitPrice: 805.10, qty: 50, pnl: 365, pnlPct: 0.90, riskReward: 2.2, emotion: 'Confident', notes: 'PDL breakdown with volume.' },
  { id: '6', date: '2026-05-22', symbol: 'ICICI BANK', direction: 'LONG', setupType: 'VWAP Reclaim', entryPrice: 1298.30, exitPrice: 1321.70, qty: 40, pnl: 936, pnlPct: 1.80, riskReward: 3.5, emotion: 'Calm', notes: 'Perfect setup. Best trade of the week.' },
];

const TradesContext = createContext<TradesContextType>({
  trades: [],
  addTrade: () => {},
  deleteTrade: () => {},
  isLoaded: false,
});

export function TradesProvider({ children }: { children: React.ReactNode }) {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (raw) {
        try { setTrades(JSON.parse(raw)); } catch { setTrades(SEED_TRADES); }
      } else {
        setTrades(SEED_TRADES);
        AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(SEED_TRADES));
      }
      setIsLoaded(true);
    });
  }, []);

  const addTrade = useCallback((trade: Omit<Trade, 'id'>) => {
    const id = Date.now().toString() + Math.random().toString(36).slice(2, 7);
    setTrades(prev => {
      const next = [{ ...trade, id }, ...prev];
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  const deleteTrade = useCallback((id: string) => {
    setTrades(prev => {
      const next = prev.filter(t => t.id !== id);
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  return (
    <TradesContext.Provider value={{ trades, addTrade, deleteTrade, isLoaded }}>
      {children}
    </TradesContext.Provider>
  );
}

export function useTradesContext() {
  return useContext(TradesContext);
}
